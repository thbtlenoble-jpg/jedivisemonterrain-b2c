<template>
    <div id="content" class="ListingStudies">
        <div class="contentLeft justify-center">
            <q-inner-loading :showing="projectIsProjectsClusterLoaded">
                <q-spinner size="3em" :thickness="2" color="primary" />
            </q-inner-loading>
            <q-scroll-area :thumb-style="thumbStyle" :bar-style="scrollBarStyle" class="scrollArea">
                <div class="content">
                    <div class="headerBloc">
                        <div class="informationsPage">
                            <div class="title">{{projectProjectsCluster.count}}
                                {{ projectProjectsCluster.count | pluralize('Etude disponible', 'Etudes disponibles') }}
                            </div>
                            <div class="description">Retrouvez la liste complète de vos études, aperçu et accès aux
                                détails.
                            </div>
                        </div>
                        <div class="form searchingBar row justify-between">
                            <q-input class="searchInput" label="Rechercher une étude" type="search" v-model="search" debounce="500">
                                <template v-slot:append>
                                    <q-icon name="fal fa-search"/>
                                </template>
                            </q-input>
                            <div class="buttonNewProject">
                                <q-btn :to="{name : 'newProject'}" icon="fal fa-layer-plus" class="button medium" color="blue" unelevated label="Ajouter une étude"/>
                            </div>
                        </div>
                    </div>
                    <div class="contentBloc">
                        <div class="studies row" v-if="projectProjectsCluster.projects.length != 0">
                            <!--<div class="projectBloc" v-for="project in projectProjectsCluster.projects" :key="project.id">
                                <card-project v-bind:projectCluster="project"></card-project>
                            </div>-->
                            <div class="projectBloc" v-for="project in projectProjectsCluster.projects" :key="project.id">
                                <card-project v-bind:projectCluster="project"></card-project>
                            </div>
                            <div v-if="limit < projectProjectsCluster.count" class="buttonMoreProjects col-12 justify-center row">
                                <q-btn icon="fal fa-plus" unelevated class="button medium" color="grey" text-color="greyDark" label="Plus d'études" @click="moreProject"/>
                            </div>
                            <div v-else class="noMoreProjects col-12 justify-center row">
                                Aucune autre étude à charger
                            </div>
                        </div>
                        <div class="noStudies" v-else>
                            Aucune étude en cours
                        </div>
                    </div>
                </div>
            </q-scroll-area>
        </div>
        <div class="contentRight">
            <q-scroll-area :thumb-style="thumbStyle" :bar-style="scrollBarStyle" class="scrollArea">
                <div class="content">
                    <div class="title"><i class="fal fa-frown"></i> Etude assignée</div>
                    <p class="empty">
                        Vous n'avez, pour le moment, aucune nouvelle étude qui vous est assigné.
                    </p>
                    <img src="../statics/emptyFolder.png" alt="">
                </div>
            </q-scroll-area>
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../store/index'
    import CardProject from "../../src/components/listingStudiesComponent/cardProject";
    import {debounce} from 'quasar'

    export default {
        name: "ListingStudies",
        data() {
            return {
                isFirstLoading: true,
                limit: 16,
                search: "",
                thumbStyle: {
                    right: '0',
                    borderRadius: '5px',
                    backgroundColor: '#e6ecef',
                    width: '5px',
                    opacity: 1
                },
                scrollBarStyle: {
                    backgroundColor: '#e6ecef',
                    width: '5px',
                    opacity: 0.2,
                    color: '#555'
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectProjectsCluster',
                'projectIsProjectsClusterLoaded',
                'projectTestStudies',
                'projectIsProjectsClusterLoaded'
            ])
        },
        watch : {
            search(){
                this.loadProjectsCluster()
            }
        },
        created() {
            this.init()
        },
        methods: {
            ...Vuex.mapActions([
                'loadProjectsCluster'
            ]),
            moreProject() {
                this.limit += 16
                this.loadProjectsCluster()
            },
            init(){
                this.loadProjectsCluster()
            },
            loadProjectsCluster() {
                var vm = this
                Store.dispatch("loadProjectsCluster", {
                    options: {
                        offset: 0,
                        limit: vm.limit,
                        relations:
                            [
                                "plots",
                                "address",
                                "person",
                                "realEstateAgency",
                                //"goodProperty"
                            ],
                        search: this.search
                    }

                }).then(response => {
                    // console.log(response)
                }, error => {
                })
            }
        },
        components: {
            CardProject
        },
    }

</script>

<style lang="scss">

    @import "../css/app.scss";

    .ListingStudies {

        .contentLeft {

            .headerBloc {

                .searchingBar {
                    padding: 0 20px;

                    .searchInput {
                        width: 225px;
                    }

                    .buttonNewProject {
                        padding-top: 25px;
                    }

                }

            }

            .contentBloc {
                padding-top: 30px;
                position: relative;
                width: 100%;

                .noStudies{
                    padding: 20px 20px 30px;
                    font-size: 14px;
                    text-align: center;
                    font-style: italic;
                    color: $grey02;
                }

                .projectBloc {
                    border-radius: 5px;
                    opacity: 1;
                    width: 25%;
                    padding: 0 20px 40px;
                }

                @media screen and (max-width: 1700px) {

                    .projectBloc {
                        width: 33.33%;
                    }

                }

                @media screen and (max-width: 1370px) {

                    .projectBloc {
                        width: 50%;
                    }

                }

                @media screen and (max-width: 1100px) {

                    .projectBloc {
                        width: 100%;
                    }

                }

                .buttonMoreProjects{
                    padding: 0 20px 30px;
                }

                .noMoreProjects{
                    font-size: 14px;
                    padding: 0 20px 30px;
                    font-style: italic;
                    color: $grey02;
                }

            }

        }

        .contentRight {

            img{
                width: 50%;
            }

        }

    }

</style>
