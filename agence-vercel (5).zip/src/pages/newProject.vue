<template>
    <div id="content" class="newProject">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="contentLeft">
            <div v-if="currentStep == 0" class="step0 column">
                <div class="text-h4 row justify-around title">Initialisation d'une nouvelle étude</div>
                <div class="row justify-around startNewProjectButton">
                    <q-btn unelevated class="button large" color="primary" text-color="white" label="Commencer" @click="nextStep"/>
                </div>
                <div class="row justify-around cancelButton">
                    <q-btn class="greyButton medium" unelevated label="Annuler" @click="cancel"></q-btn>
                </div>

            </div>

            <div v-if="currentStep == 1" class="step1 q-pa-lg column">
                <div class="text-h4 row justify-center titleSearching">
                    <q-btn-toggle
                            v-model="step1.isPlots"
                            class="buttonToggle"
                            spread
                            no-caps
                            rounded
                            unelevated
                            toggle-color="primary"
                            color="#F5F6FA"
                            text-color="black"

                            :options="[
          {label: 'Recherche par adresse', value: false},
          {label: 'Recherche par parcelle', value: true}
        ]"
                    />
                </div>
                <div class="row justify-center inputSearch">
                    <q-input v-if="!step1.isPlots" class="address" v-model="address"
                             label="Entrer l'adresse concernée"/>

                    <q-input v-if="step1.isPlots" class="plotsInput" v-model="commune"
                             label="Entrer la commune concernée"/>
                    <q-input v-if="step1.isPlots" class="plotsInput" v-model="section"
                             label="Entrer la section concernée" hint="Exemple : 000AB">
                    </q-input>
                    <q-input v-if="step1.isPlots" class="plotsInput" v-model="plotNumber"
                             label="Entrer le numéro de parcelle concernée"/>
                </div>
                <div class="row justify-around ">
                    <div class="listAddress " v-if="entries != '' && !addressSelect">
                                <span class="address" v-for="entry in entries" @click="selectAddress(entry)">
                                    <span class="label">{{entry.properties.label}}</span>
                                    <span class="context">{{entry.properties.context}}</span>
                                    <span class="type" v-if="entry.properties.type == 'housenumber'"><i
                                            class="fal fa-home"></i></span>
                                    <span class="type" v-if="entry.properties.type == 'street'"><i
                                            class="fal fa-road"></i></span>
                                </span>
                    </div>
                </div>
                <div class="listAddress " v-if="communeEntries != '' && !communeSelect">
                                <span class="address" v-for="entry in communeEntries" @click="selectCommune(entry)">
                                    <span class="label">{{entry.properties.label}}</span>
                                    <span class="context">{{entry.properties.context}}</span>
                                </span>
                </div>

            </div>

            <div v-if="currentStep == 2" class="step2">
                <q-inner-loading :showing="projectIsPlotsLoaded">
                  <q-spinner size="3em" :thickness="2" color="primary" />
                </q-inner-loading>
                <Map v-bind:entry-select="entrySelect" ref="mapComponent"></Map>
            </div>

            <div v-if="currentStep == 3" class="step3 q-pa-lg column ">
                <div class="goodInSale row q-pa-lg justify-center ">
                    <q-checkbox class="checkStep3" v-model="isInSale"/>
                    <div class="label">Cocher la case si le bien est en vente ?</div>
                </div>
            </div>

            <div v-if="currentStep == 4" class="step4 q-pa-lg justify-center">
                <div class="title">Votre projet a été créé</div>
                <div class="buttonBloc">
                    <q-btn class="button large" color="primary" text-color="white" unelevated label="Liste des projets" @click="goToListProject"/>
                </div>
                <div>
                    <q-btn class="button medium" color="primary" text-color="white" unelevated label="Nouveau projet" @click="resetNewProject"/>
                </div>

            </div>

            <div class="stepperInformation ">
                <div class="arianBloc">
                    <div class="searchingPlot arianPart">
                        <i class="fal fa-map-marker-alt"
                           v-bind:class="{active : currentStep == 1 , 'passed' : currentStep >1}"></i>
                    </div>
                    <div class="borderLeft"></div>
                    <div class="validatingPlots arianPart">
                        <i class="fal fa-square"
                           v-bind:class="{active : currentStep == 2, 'passed' : currentStep >2}"></i>
                    </div>
                    <div class="borderRight"></div>
                    <div class="endInitialisation arianPart">
                        <i class="fal fa-plus" v-bind:class="{active : currentStep >= 3}"></i>
                    </div>
                </div>
                <div class="labelBloc">
                    <div class="label">Recherche du lieu</div>
                    <div class="label">Validation des parcelles</div>
                    <div class="label">Fin de l'initialisation</div>
                </div>
            </div>
        </div>
        <div class="contentRight">
            <div class="address q-pa-lg column" v-if="currentStep >1">
                <div class="icon">
                    <i class="fal fa-map-marker-alt"></i>
                </div>
                <div class="addressInformation">
                    <div class="street">{{this.entrySelect.properties.name}}</div>
                    <div class="city">{{this.entrySelect.properties.citycode}} {{this.entrySelect.properties.city}}
                    </div>
                </div>
            </div>
            <q-scroll-area
                    :thumb-style="barStyle"
                    class="scrollArea"
            >
              <div class="listPlots q-pa-lg" >
                  <div class="plot row q-pa-lg" v-for="plot in projectPlotsSelected">
                      <div class="plotHeader row justify-between  col-12">
                          <div class="libelle">Parcelle</div>
                          <div class="icon"><i class="fal fa-trash-alt fa-1x" @click="deletePlotSelected(plot)"></i></div>
                      </div>
                      <div class="informationPlot row justify-between col-12">
                          <div class="section column ">
                              <div class="label">Section</div>
                              <div class="value">{{plot.section}}</div>
                          </div>
                          <div class="number column ">
                              <div class="label">Muméro</div>
                              <div class="value">{{plot.numero}}</div>
                          </div>
                          <div class="contenance column ">
                              <div class="label">Section</div>
                              <div class="value">{{plot.contenance }} M²</div>
                          </div>
                      </div>
                  </div>
                  <div class="infoInsale" v-if="currentStep == 4 & isInSale">
                    <div class="label"><i class="fal fa-check"></i> Le bien est en vente</div>
                  </div>
              </div>
            </q-scroll-area>


            <div class="stepperAction">

                <div class="row justify-around nextStepBloc">
                    <q-btn v-if="currentStep<3 & currentStep != 0" class="button medium" unelevated
                           color="primary"
                           text-color="white"
                           label="Etape suivante"
                           @click="nextStep"/>
                    <q-btn v-if="currentStep==3" class="button medium" color="primary" text-color="white" unelevated label="Terminer la création"
                           @click="createProject"/>

                </div>
                <div class="row justify-around backStepBloc">
                    <q-btn v-if="currentStep<= 1 & currentStep!=0" class="button medium" unelevated
                           label="Annuler la création"
                           @click="cancel"></q-btn>
                    <q-btn v-if="currentStep > 1 & currentStep!=4" class="button medium" unelevated label="Retour"
                           @click="backStep"></q-btn>
                </div>

            </div>
            <div class="informationGeneralNewProject">
                <div class="row justify-around icon">
                    <i class="fas fa-info-circle fa-2x"></i>
                </div>
                <div class="row justify-around description">
                    <div class="text"> Phase d'initialisation du projet, à la suite de ces étapes vous serez amené à
                        compléter les
                        informations nécessaires à la création du dossier de valorisation
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    import L from "leaflet";
    import "leaflet/dist/leaflet.css";
    import Vuex from 'vuex'
    import Store from '../store/index'

    //import "leaflet-draw/dist/leaflet.draw.css";

    import Map from "../components/newProjectComponent/Map";

    export default {
        name: "newProject",
        data() {
            return {
                currentStep: 1,
                step1: {
                    isPlots: false,

                },
                address: '',
                addressSelect: false,
                addressSelectValide: false,
                communeSelect: false,
                communeSelectValide: false,
                communeEntries : '',
                communeEntrySelect : '',
                entries: '',
                entrySelect: '',
                section: '',
                commune: '',
                plotNumber: '',
                isInSale: false

            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectPlotsSelected', 'projectPlots', 'projectProjectCluster','projectIsPlotsLoaded','projectIsProjectsClusterLoaded'
            ]),
            barStyle(){
              return{
                right: '0',
                borderRadius: '0',
                backgroundColor: '#00B9B4',
                width: '5px',
                opacity: 0.5,
                color: '#00B9B4'
              }
            }
        },
        created() {
            let vm = this
            this.currentStep = 0;
            Store.state.study.values.plotsSelected = []
        },
        watch: {
            address() {
                if (!this.addressSelectValide) {
                    this.loadAPIAddress();
                    this.addressSelect = false;
                    this.entrySelect = ''
                }
                if (this.address == '') {
                    this.entries = ''
                }
                this.addressSelectValide = false
            },
            commune(){
                if (!this.communeSelectValide) {
                    this.loadAPICity();
                    this.communeSelect = false;
                    this.communeEntrySelect = ''
                }
                if (this.commune == '') {
                    this.communeEntries = ''
                }
                this.communeSelectValide = false
            }
        },
        methods: {

            ...Vuex.mapActions([
                'createProject', 'addPlotsToProject', 'addAddressToProject', 'loadPlotsByPlotInfo', "addOrUpdateGoodPropertyToProject"
            ]),

            nextStep() {
                console.log('AYAAAAAAAAAAAAAAa')
                if (this.currentStep == 1) {

                    if (this.step1.isPlots) {
                        if (this.section != '' & this.commune != '' & this.plotNumber != '') {
                            this.loadPlotsByPlotInfo()
                        } else {
                            this.$q.notify({
                                type: 'warning',
                                message: `Vous devez remplir toute les informations pour rechercher une parcelle`
                            })
                        }
                    } else {
                        if (this.entrySelect != '') {
                            this.currentStep += 1
                        } else {
                            this.$q.notify({
                                type: 'warning',
                                message: `Vous devez rechercher et sélectionner une adresse pour continuer`
                            })
                        }
                    }
                } else if (this.currentStep == 2) {
                    if (this.projectPlotsSelected.length != 0) {
                        this.currentStep += 1
                    } else {
                        this.$q.notify({
                            type: 'warning',
                            message: `Vous devez sélectionner une ou des parcelles`
                        })
                    }
                } else {
                    this.currentStep += 1
                }
            },
            backStep() {
                if (this.currentStep == 2 || this.currentStep == 3) {
                    Store.state.study.values.plotsSelected = []
                }
                this.currentStep -= 1

            },
            cancel() {
                this.$router.push({name: 'ListingStudies'})
            },
            loadPlotsByPlotInfo() {
                Store.dispatch("loadPlotsByPlotInfo", {
                    commune: this.communeEntrySelect.properties.citycode,
                    section: this.section,
                    numero: this.plotNumber
                }).then(response => {
                    if (response.status == 200) {
                        return fetch('https://api-adresse.data.gouv.fr/reverse/?lat=' + response.body.lat + '&lon=' + response.body.lon, {method: 'get'}).then((res) => res.json()).then((data) => {
                            this.entrySelect = data.features[0]
                            this.currentStep += 1
                        }).catch((err) => {
                            this.$q.notify({
                                type: 'negative',
                                message: `La parcelle n'a pas été trouvée`
                            })
                        })
                    }
                }, error => {
                    this.$q.notify({
                        type: 'negative',
                        message: `La parcelle n'a pas été trouvée`
                    })
                })
            },
            loadAPIAddress() {
                this.loading = true;
                return fetch('https://api-adresse.data.gouv.fr/search/?q=' + this.address, {method: 'get'}).then((res) => res.json()).then((data) => {
                    this.entries = data.features
                }).catch((err) => console.log(err))
            },
            loadAPICity(){
                return fetch('https://api-adresse.data.gouv.fr/search/?q=' + this.commune +'&type=municipality&autocomplete=1', {method: 'get'}).then((res) => res.json()).then((data) => {
                    this.communeEntries = data.features
                }).catch((err) => console.log(err))
            },
            selectCommune(entry){
                this.commune = entry.properties.postcode + ' ' +  entry.properties.label;
                this.communeSelect = true;
                this.communeSelectValide = true;
                this.communeEntrySelect = entry
            },
            selectAddress(entry) {
                this.address = entry.properties.label;
                this.addressSelect = true;
                this.addressSelectValide = true;
                this.entrySelect = entry
            },

            deletePlotSelected(plot) {
                let vm = this
                this.projectPlots.results.find((element => element == plot)).selected = false
                this.projectPlotsSelected.forEach(function (item, index) {
                    if (item.id == plot.id) {
                        vm.projectPlotsSelected.splice(index, 1)
                    }
                })
                this.$refs.mapComponent.removePlots()
                this.$refs.mapComponent.drawPlots()
            },

            createProject() {

                Store.dispatch("createProject").then(response => {
                   let  vm = this
                    delete this.entrySelect.properties.id
                    Store.dispatch("addAddressToProject", {
                        projectId: this.projectProjectCluster.id,
                        address: this.entrySelect.properties
                    }).then(response => {

                    }, error => {
                    })

                    Store.dispatch("addPlotsToProject", {
                        projectId: this.projectProjectCluster.id,
                        plots: this.projectPlotsSelected
                    }).then(response => {
                        if (response.status == 200) {

                        }
                    }, error => {
                    })

                    Store.dispatch("addOrUpdateGoodPropertyToProject", {
                        projectId: this.projectProjectCluster.id,
                        goodProperty: {
                            isInSale : this.isInSale
                        }
                    }).then(response => {
                        if (response.status == 200) {

                        }
                    }, error => {
                    })

                    this.nextStep()
                }, error => {
                })

            },
            resetNewProject() {
                Store.state.study.values.plotsSelected = []
                Store.state.study.values.plots = []
                this.step1.isPlots = false
                this.address = ''
                this.addressSelect = false
                this.addressSelectValide = false
                this.currentStep = 0
            },
            goToListProject() {
                this.$router.push({name: 'ListingStudies'})
            }
        },

        components: {
            Map
        }
    }
</script>

<style lang="scss">
    @import "../css/app";

    .newProject {
        .contentLeft {
            .step0 {
                position: relative;
                top: 50%;
                margin-top: -95px;

                .title {
                    text-align: center;
                    font: 500 20px/20px Poppins;
                    letter-spacing: 0px;
                    color: #373737;
                    opacity: 1;
                }

                .startNewProjectButton {
                    margin-top: 50px;
                }

                .cancelButton {
                    margin-top: 40px;
                }
            }

            .step1 {
                padding-top: 20%;
                width: 100%;

                .titleSearching {
                    font-size: 16px;

                    .searchLabel {
                        color: $grey04;

                        &.active {
                            font-weight: bold;
                            color: black;
                        }
                    }
                }

                .inputSearch {
                    margin-top: 20px;
                    width: 100%;

                    .address {
                        width: 500px;
                    }

                    .plotsInput {
                        width: 200px;
                        margin: 0 20px;
                    }
                }

                .listAddress {
                    background-color: white;
                    border-top: 0;
                    width: 500px;
                    transition: all .3s ease;
                    box-shadow: 2px 5px 10px rgba(0, 0, 0, 0.1);

                    .address {
                        position: relative;
                        padding: 10px 20px;
                        display: block;
                        transition: all .3s ease;
                        cursor: pointer;

                        .label {
                            display: block;
                            font-size: 14px;
                            color: black;
                            font-weight: 500;
                        }

                        .context {
                            display: block;
                            font-size: 11px;
                            color: $grey02;
                            font-weight: 400;
                        }

                        .type {
                            position: absolute;
                            top: 0;
                            right: 0;
                            color: black;
                            i {
                                padding: 0 20px;
                                position: relative;
                                font-size: 16px;
                                line-height: 72px;
                            }

                        }

                        &:hover {
                            background-color: $grey02;

                            .context{
                                color: white;
                            }
                        }

                    }

                }
            }

            .step2 {
                position: absolute;
                z-index: 1;
                bottom: 0;
                top: 0;
                left: 0;
                right: 0;

            }

            .step3 {
                position: relative;
                top: 40%;
                width: 100%;
                margin-top: -20px;

                .checkStep3 {
                    color: #00B9B4;
                }

                .label {
                    padding-top: 8px;
                    font: 400 13px/20px Poppins;
                    letter-spacing: 0px;
                    color: #373737;
                }
            }

            .step4 {
                padding-top: 20%;
                text-align: center;
                justify-content: space-around;

                .title {
                    text-align: center;
                    font: 500 20px/20px Poppins;
                    letter-spacing: 0px;
                    color: #373737;
                    opacity: 1;
                    margin-bottom: 50px;
                }

                .buttonBloc {
                    margin-bottom: 40px;
                }

            }

            .stepperInformation {
                width: 100%;
                position: absolute;
                bottom: 100px;

                z-index: 2;

                .arianBloc {
                    display: flex;
                    justify-content: center;
                    width: 100%;

                    .arianPart {

                        display: flex;
                        flex-direction: column;
                        justify-content: center;


                        i {
                            padding: 0;
                            width: 24px;
                            text-align: center;
                            line-height: 24px;
                            font-size: 15px;
                            color: #AEAEAE;
                            background-color: #E6ECEF;
                            border-radius: 100px;
                            text-align: center;

                            &.active {
                                background-color: #00B9B4;
                                color: #FFFFFF;
                            }

                            &.passed {
                                background-color: #AEAEAE;
                                color: #FFFFFF;
                            }
                        }

                    }

                    .borderLeft {
                        margin: 12px 10px 0 10px;
                        height: 0px;
                        width: 250px;
                        border-top: solid 1px #D3D3D4;
                    }

                    .borderRight {
                        margin: 12px 10px 0 10px;

                        height: 0px;
                        width: 250px;
                        border-top: solid 1px #D3D3D4;
                    }
                }

                .labelBloc {
                    display: flex;
                    justify-content: center;
                    width: 100%;

                    .label {
                        text-align: center;
                        font: 500 13px/20px Poppins;
                        letter-spacing: 0px;
                        color: #AEAEAE;
                        opacity: 1;
                        margin: 0px 75px;
                        padding-top: 5px;
                    }
                }


            }
        }

        .contentRight {
            .address{
              margin-top : 30px;
                .icon{
                  i{
                    text-align: left;
                    font-size: 20px;
                    letter-spacing: 0px;
                    color: #00B9B4;
                    opacity: 1;
                  }

                }

              .addressInformation{
                  text-align: left;
                  font: 400 12px Poppins;
                  letter-spacing: 0px;
                  color: #373737;
                  opacity: 1;
              }
            }
            .scrollArea{
                position: absolute !important;
                top: 140px !important;
                bottom: 300px !important;
                width: 100% !important;
                  .listPlots {
                      .plot {
                        background: #FFFFFF 0% 0% no-repeat padding-box;
                        border: 1px solid #E6ECEF;
                        border-radius: 5px;
                        opacity: 1;
                        margin: 15px 5px;
                        box-shadow: 2px 5px 10px rgba(0, 0, 0, 0.1);

                        &:hover{
                          box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.1);
                        }
                        .label {
                          font-weight: bolder;
                        }
                    }
                    .infoInsale{
                      label{
                        font: 400 12px/18px Poppins;
                        letter-spacing: 0px;
                        color: #373737;
                        opacity: 1;
                      }
                    }
                }
            }


            .stepperAction {
                position: absolute;
                bottom: 210px;
                width: 100%;

                .nextStepBloc {
                    padding-bottom: 10px;

                    .nextStepButton {
                        padding: 5px
                    }

                }

                .backStepBloc {
                    .backStepButton {
                        font-size: 12px;
                    }
                }
            }

            .informationGeneralNewProject {
                position: absolute;
                bottom: 0;
                padding: 20px;

                .icon {
                    padding: 10px;
                }

                .description {
                    font-style: italic;
                }
            }

        }
    }
</style>
