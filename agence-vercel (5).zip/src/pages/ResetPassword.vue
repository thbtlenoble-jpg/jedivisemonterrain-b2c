<template>
  <div id="resetPasswod">

    <div class="leftDecoration">
      <div class="title">
        <span>ESPACE AGENCE</span>
      </div>
      <div class="imgDecoration"></div>
    </div>
    <div class="loginContent">
      <q-inner-loading :showing="authentificationIsLoginLoading">
        <q-spinner size="3em" :thickness="2" color="primary" />
      </q-inner-loading>
      <div class="contentLeft">
        <div class="logo">
          <img src="../statics/logo-login.png" alt="">
        </div>
        <div class="title">
          <span>Mot de passe oublié ?</span>
        </div>
        <div class="formToFogetPassword" >
          <div class="step3" >
            <q-input class="col-20" v-model="newPassword" :type="isPwd ? 'password' : 'text'" label="Nouveau mot de passe" @keyup.enter="login">
              <template v-slot:append>
                <q-icon :name="isPwd ? 'visibility_off' : 'visibility'" class="cursor-pointer" @click="isPwd = !isPwd" />
              </template>
            </q-input>
            <div class="validateButton">
              <q-btn @click="changePassword" unelevated  label="Valider le changement" class="coloredButton small" />
            </div>

          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../store/index"

    export default {
        name: "ResetPassword",
        data(){
          return{
            isPwd : true,
            newPassword : "",
            code : this.$route.params.code,
          }
        },

        created() {
          this.checkCodeValid()
        },
        computed: {
          ...Vuex.mapGetters([
            'authentificationIsLoginLoading'
          ]),
        },
        methods : {
          ...Vuex.mapActions([
            'checkCodeValid', 'changePassword'
          ]),
          checkCodeValid(){
            Store.dispatch("checkCodeValid", { code: this.code}).then(response => {
                if (response.status == 200) {
                    if(!response.body){
                      this.$q.notify({
                        type: 'negative',
                        message: `Le lien n'est plus valide ou incorrect`
                      })
                      this.$router.push({name : "Login"})
                    }
                } else {
                  this.$q.notify({
                    type: 'negative',
                    message: `Le lien n'est plus valide ou incorrect`
                  })
                  this.$router.push({name : "Login"})
                }
              },
              error => {
                this.$q.notify({
                  type: 'negative',
                  message: `Le lien n'est plus valide ou incorrect`
                })
                this.$router.push({name : "Login"})
              })
          },
         changePassword(){
             Store.dispatch("changePassword", { code: this.code, password : this.newPassword}).then(response => {
                 if (response.status == 201 ) {

                     this.$q.notify({
                       type: 'positive',
                       message: `Votre mot de passe à bien été modifier`
                     })
                     this.$router.push({name : "Login"})

                 } else {
                   this.$q.notify({
                     type: 'negative',
                     message: `Le lien n'est plus valide ou incorrect`
                   })
                   this.$router.push({name : "Login"})
                 }
               },
               error => {
                 this.$q.notify({
                   type: 'negative',
                   message: `Le lien n'est plus valide ou incorrect`
                 })
                 this.$router.push({name : "Login"})
               })
           },

        }
    }
</script>

<style lang="scss">
  #resetPasswod{

    .leftDecoration{
      overflow: hidden;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 600px;
      bottom: 0;
      background: transparent radial-gradient(closest-side at 0% 0%, #E6ECEF 0%, #F5F6FA 100%) 0% 0% no-repeat padding-box;
      opacity: 1;

      .title{
        padding: 48.5px 38px 148.5px 48.5px ;
        span{
          text-align: left;
          font: Bold 20px/28px Poppins;
          letter-spacing: 0px;
          color: #373737;
          opacity: 1;
        }
      }
      .imgDecoration{
        background-image: url("../statics/picto-login.png");
        position: absolute;
        bottom: 0;
        right: 0;
        width:400px;
        height: 400px;
        background-size: 100%;
        ackground-position: center;
        background-repeat: no-repeat;
      }
    }
    .loginContent{
      position: absolute;
      width: 300px;

      right: 30%;
      top: 25%;

      .contentLeft{
        width: 100%;
        float: left;
        .logo{
          text-align: center;
          img{
            width: 60px;
            height: 80px;
          }

        }
        .title{
          width: 100%;
          text-align: center;
          font-weight: 500;
          font-size: 14px/20px;
        }
        .formToFogetPassword{
          .col-20{
            width: 100%;
          }
          .validateButton{
            padding-top: 20px;
            width: 100%;
            text-align: right;
            .cancel{
              margin-right: 20px;
            }
          }
        }
      }
    }
  }
</style>
