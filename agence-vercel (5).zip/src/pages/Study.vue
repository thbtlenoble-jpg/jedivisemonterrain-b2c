<template>
    <div id="content" class="project">
        <div class="contentLeft">
            <!--            <div class="stepper">-->
            <!--                <div class="time">-->
            <!--                    <span class="timeLeft" v-bind:style="timeStyle"-->
            <!--                        ><i class="fal fa-info-circle"></i-->
            <!--                        >{{-->
            <!--                            projectTestStudies[0].id-->
            <!--                                | dateCompareStep(-->
            <!--                                    activeStep.end,-->
            <!--                                    activeStep.creation-->
            <!--                                )-->
            <!--                        }}</span-->
            <!--                    >-->
            <!--                    <span class="bgBar">-->
            <!--                        <span class="bar" v-bind:style="barStyle"></span>-->
            <!--                    </span>-->
            <!--                </div>-->
            <!--                <div class="steps">-->
            <!--                    <div-->
            <!--                        class="step"-->
            <!--                        v-for="(step, index) in projectSteps"-->
            <!--                        :class="{-->
            <!--                            active: activeStep.nb == index + 1,-->
            <!--                            past: activeStep.nb > index + 1,-->
            <!--                        }"-->
            <!--                    >-->
            <!--                        <div class="infos">-->
            <!--                            <i :class="step.icon"></i>-->
            <!--                            {{ step.name }}-->
            <!--                        </div>-->
            <!--                        <div class="bullet">-->
            <!--                            <span class="barLeft"></span>-->
            <!--                            <span class="circle"></span>-->
            <!--                            <span class="barRight"></span>-->
            <!--                        </div>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <div class="actions">
                <q-scroll-area
                    :thumb-style="thumbStyle"
                    :bar-style="scrollBarStyle"
                    class="scrollArea"
                >
                    <div class="content">
                        <div class="headerBloc">
                            <div class="informationsPage">
                                <div class="title">
                                    Détails de l'étude
                                    <span class="ref">
                                        Réf.
                                        {{ projectProjectCluster.id | digit }}
                                    </span>
                                </div>
                                <div class="subTitle">
                                    {{ activeStep.name }}
                                </div>
                                <div class="description">
                                    Suivez et participez à l'étude, cette phase
                                    est constituée de 10 étapes
                                </div>
                            </div>
                        </div>
                        <div class="actors">
                            <span
                                v-for="actor in activeStep.actors"
                                :style="{ backgroundColor: actor.color }"
                            >
                                <q-tooltip
                                    :content-style="{
                                        color: '#ffffff',
                                        backgroundColor: '#373737',
                                    }"
                                    :offset="[10, 10]"
                                    anchor="top middle"
                                    self="bottom middle"
                                    >{{ actor.name }}</q-tooltip
                                >
                            </span>
                        </div>
                        <div class="myActions">
                            <div class="title">Mes actions</div>
                            <div class="listActions">
                                <div
                                    class="action"
                                    v-for="action in activeStep.myActions"
                                >
                                    <div
                                        class="state"
                                        @click="previewAction(action)"
                                    >
                                        <div
                                            class="empty"
                                            v-if="action.state == 'empty'"
                                        ></div>
                                        <div
                                            class="init"
                                            v-if="action.state == 'init'"
                                        >
                                            ...
                                        </div>
                                        <div
                                            class="finish"
                                            v-if="action.state == 'finish'"
                                        >
                                            <i class="fal fa-check"></i>
                                        </div>
                                        <div
                                            class="lock"
                                            v-if="action.state == 'lock'"
                                        >
                                            <i class="fal fa-lock"></i>
                                        </div>
                                    </div>
                                    <div class="name">
                                        <span @click="previewAction(action)">{{
                                            action.name
                                        }}</span>
                                        <div class="edit">
                                            <q-btn
                                                class="button small"
                                                unelevated
                                                color="white"
                                                text-color="light"
                                                label="Aperçu"
                                                @click="previewAction(action)"
                                            />
                                            <q-btn
                                                class="button small round margin right"
                                                unelevated
                                                color="grey"
                                                text-color="dark"
                                                icon="fal fa-edit"
                                                @click="editingAction(action)"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="theirActions" v-if="activeStep.theirActions.length > 0">
                            <div class="title">Actions des autres acteurs</div>
                            <div class="listActions">
                                <div
                                    class="action"
                                    v-for="action in activeStep.theirActions"
                                >
                                    <div class="state">
                                        <div
                                            class="empty"
                                            v-if="action.state == 'empty'"
                                        ></div>
                                        <div
                                            class="init"
                                            v-if="action.state == 'init'"
                                        >
                                            ...
                                        </div>
                                        <div
                                            class="finish"
                                            v-if="action.state == 'finish'"
                                        >
                                            <i class="fal fa-check"></i>
                                        </div>
                                        <div
                                            class="lock"
                                            v-if="action.state == 'lock'"
                                        >
                                            <i class="fal fa-lock"></i>
                                        </div>
                                    </div>
                                    <div
                                        class="name"
                                        :class="{
                                            lock: action.state == 'lock',
                                        }"
                                    >
                                        {{ action.name }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </q-scroll-area>
            </div>
            <div class="map">
                <div id="map"></div>
                <span
                    class="buttonMap button3d"
                    @click="disable3D()"
                    :class="{ active: mapValues.map3d }"
                    >3D</span
                >
                <!--                <span class="buttonMap buttonLayers">-->
                <!--                    <i class="fal fa-layer-group"></i>-->
                <!--                </span>-->
            </div>
            <div class="preview" :class="{ active: currentTabPreview }">
                <q-scroll-area
                    :thumb-style="thumbStyle"
                    :bar-style="scrollBarStyle"
                    class="scrollArea"
                >
                    <div class="content">
                        <component
                            v-on:returnAction="returnActionStudy"
                            v-bind:is="currentTabPreview"
                            class="tab"
                            v-bind:valuesPreview="currentTabValues"
                            v-bind:projectId="projectProjectCluster.id"
                            v-bind:state="currentTabState"
                        ></component>
                    </div>
                </q-scroll-area>
            </div>
            <div class="editing" :class="{ active: currentTabEditing }">
                <q-scroll-area
                    :thumb-style="thumbStyle"
                    :bar-style="scrollBarStyle"
                    class="scrollArea"
                >
                    <div class="content">
                        <component
                            v-on:returnAction="returnActionStudy"
                            v-bind:is="currentTabEditing"
                            class="tab"
                            v-bind:valuesEditing="currentTabValues"
                            v-bind:projectId="projectProjectCluster.id"
                        ></component>
                    </div>
                </q-scroll-area>
            </div>
        </div>
        <div class="contentRight">
            <siteBarRight
                v-bind:projectCluster="projectProjectCluster"
            ></siteBarRight>
        </div>
    </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../store/index";
    import newFilter from "../utils/filters.js";
    import config from "../utils/config.js";

    import mapboxgl from "mapbox-gl";

    import siteBarRight from "../components/study/general/theSideBarRight";

    //Infos études

    // Import des composants d'aperçus
    import previewSector from "../components/study/studyInformations/sector/sectorPreview";
    import previewMarket from "../components/study/studyInformations/market/marketPreview";
    import previewProgramme from "../components/study/studyInformations/programme/programmePreview";
    import previewFiles from "../components/study/studyInformations/files/filesPreview";
    import previewOwners from "../components/study/studyInformations/owners/ownersPreview";
    import previewNotary from "../components/study/studyInformations/notary/notaryPreview";
    import previewGoodInformation from "../components/study/studyInformations/goodInformation/goodInformationPreview";
    import previewSalesInformation from "../components/study/studyInformations/salesInformation/salesInformationPreview";

    // Import des composants d'éditions
    import editingSector from "../components/study/studyInformations/sector/sectorEditing";
    import editingMarket from "../components/study/studyInformations/market/marketEditing";
    import editingProgramme from "../components/study/studyInformations/programme/programmeEditing";
    import editingFiles from "../components/study/studyInformations/files/filesEditing";
    import editingOwners from "../components/study/studyInformations/owners/ownersEditing";
    import editingNotary from "../components/study/studyInformations/notary/notaryEditing";
    import editingGoodInformation from "../components/study/studyInformations/goodInformation/goodInformationEditing";
    import editingSalesInformation from "../components/study/studyInformations/salesInformation/salesInformationEditing";

    //Estimations des lots

    import previewPlotsEstimation from "../components/study/plotsEstimation/plotsEstimationPreview";
    import editingPlotsEstimation from "../components/study/plotsEstimation/plotsEstimationEditing";

    //Constructibilité
    import previewConstructibility from "../components/study/constructibility/constructibilityPreview";
    import editingConstructibility from "../components/study/constructibility/constructibilityEditing";

    export default {
        name: "Project",
        data() {
            return {
                projectId: this.$route.params.id,
                activeStep: "",
                map: {},
                mapValues: {
                    accessToken:
                        process.env.MAPBOX_TOKEN || "",
                    style: "mapbox://styles/mapbox/dark-v10",
                    center: [5.6831654, 45.0956594],
                    zoom: 18,
                    map3d: true,
                },
                layers: [
                    {
                        name: "satellite",
                        values: "mapbox://styles/mapbox/satellite-streets-v11",
                    },
                    {
                        name: "street",
                        values: "mapbox://styles/mapbox/streets-v11",
                    },
                    { name: "Dark", values: "mapbox://styles/mapbox/dark-v10" },
                ],
                isEditing: false,
                currentTabPreview: false,
                currentTabEditing: false,
                currentTabValues: "",
                currentTabState: "",
                hoveredStateId: null,
                thumbStyle: {
                    right: "0",
                    borderRadius: "5px",
                    backgroundColor: "#e6ecef",
                    width: "5px",
                    opacity: 1,
                },
                scrollBarStyle: {
                    backgroundColor: "#e6ecef",
                    width: "5px",
                    opacity: 0.2,
                    color: "#555",
                },
            };
        },
        computed: {
            ...Vuex.mapGetters([
                "projectTestStudies",
                "projectBuilder",
                "projectSteps",
                "projectProjectCluster",
            ]),
            barStyle: function () {
                let percent = this.valuePercentStep(
                    this.activeStep.end,
                    this.activeStep.creation
                );
                let color = "";
                if (percent < 51) {
                    color = config.COLOR_GREEN;
                } else if (percent < 76) {
                    color = config.COLOR_ORANGE;
                } else {
                    color = config.COLOR_RED;
                }
                return {
                    width: percent + "%",
                    backgroundColor: color,
                };
            },
            timeStyle: function () {
                let percent = this.valuePercentStep(
                    this.activeStep.end,
                    this.activeStep.creation
                );
                let color = "";
                if (percent < 51) {
                    color = config.COLOR_GREEN;
                } else if (percent < 76) {
                    color = config.COLOR_ORANGE;
                } else {
                    color = config.COLOR_RED;
                }
                return {
                    backgroundColor: color,
                };
            },
        },
        created() {
            this.activeStep = this.projectTestStudies[0].steps[
                this.projectTestStudies[0].steps.length - 1
            ];
        },
        mounted() {
            this.getProjectCluster();
        },
        methods: {
            ...Vuex.mapActions(["loadProjectCluster"]),

            getProjectCluster() {
                Store.dispatch("loadProjectCluster", {
                    projectId: this.projectId,
                    relations: [
                        "plots",
                        "address",
                        "person",
                        "realEstateAgency",
                    ],
                }).then(
                    (response) => {
                        this.createMap();
                    },
                    (error) => {}
                );
            },

            editDetailsProject(componentToEdit, type) {
                this.currentTab = componentToEdit;
                this.isEditing = type;
            },
            createMap() {
                let vm = this;

                mapboxgl.accessToken = this.mapValues.accessToken;
                this.map = new mapboxgl.Map({
                    container: "map",
                    style: this.mapValues.style,
                    zoom: this.mapValues.zoom,
                    center: [
                        this.projectProjectCluster.plots[0].lon,
                        this.projectProjectCluster.plots[0].lat,
                    ],
                    pitch: 45,
                    bearing: -17.6,
                    antialias: true,
                });

                this.map.addControl(new mapboxgl.NavigationControl());

                this.map.on("load", function () {
                    // Insert the layer beneath any symbol layer.
                    var layers = vm.map.getStyle().layers;

                    var labelLayerId;
                    for (var i = 0; i < layers.length; i++) {
                        if (
                            layers[i].type === "symbol" &&
                            layers[i].layout["text-field"]
                        ) {
                            labelLayerId = layers[i].id;
                            break;
                        }
                    }

                    // Ajout de la parcelle de l'étude
                    vm.projectProjectCluster.plots.forEach((plot, i) => {
                        vm.map.addSource("plot" + i, {
                            type: "geojson",
                            data: {
                                type: "Feature",
                                geometry: JSON.parse(plot.geometry),
                            },
                        });
                        vm.map.addLayer({
                            id: "background" + i,
                            type: "fill",
                            source: "plot" + i,
                            layout: {},
                            paint: {
                                "fill-color": "#FFE225",
                                "fill-opacity": [
                                    "case",
                                    [
                                        "boolean",
                                        ["feature-state", "hover"],
                                        false,
                                    ],
                                    1,
                                    0.5,
                                ],
                            },
                        });
                        vm.map.addLayer({
                            id: "border" + i,
                            type: "line",
                            source: "plot" + i,
                            layout: {},
                            paint: {
                                "line-color": "#FFE225",
                                "line-width": 5,
                            },
                        });

                        // vm.map.on('mousemove', 'background' + i, function(e) {
                        //     if (e.features.length > 0) {
                        //         console.log(e.features)
                        //         if (vm.hoveredStateId) {
                        //             vm.map.setFeatureState(
                        //                 { source: "plot" + i, id: vm.hoveredStateId },
                        //                 { hover: false }
                        //             );
                        //         }
                        //         vm.hoveredStateId = "background" + i;
                        //
                        //         vm.map.setFeatureState(
                        //             { source: "plot" + i, id: vm.hoveredStateId },
                        //             { hover: true }
                        //         );
                        //     }
                        // });

                        // vm.map.on('click', 'background' + i, function(e) {
                        //     console.log('AYAOIR')
                        // });
                        //
                        // vm.map.on('mouseenter',  'background' + i, function() {
                        //     vm.map.getCanvas().style.cursor = 'pointer';
                        // });
                        //
                        // vm.map.on('mouseleave',  'background' + i, function() {
                        //     vm.map.getCanvas().style.cursor = '';
                        // });
                    });

                    // Ajout des batiment 3D
                    vm.map.addLayer(
                        {
                            id: "3d-buildings",
                            source: "composite",
                            layout: {
                                visibility: "visible",
                            },
                            "source-layer": "building",
                            filter: ["==", "extrude", "true"],
                            type: "fill-extrusion",
                            minzoom: 15,
                            paint: {
                                "fill-extrusion-color": "#333",
                                "fill-extrusion-height": [
                                    "interpolate",
                                    ["linear"],
                                    ["zoom"],
                                    15,
                                    0,
                                    15.05,
                                    ["get", "height"],
                                ],
                                "fill-extrusion-base": [
                                    "interpolate",
                                    ["linear"],
                                    ["zoom"],
                                    15,
                                    0,
                                    15.05,
                                    ["get", "min_height"],
                                ],
                                "fill-extrusion-opacity": 1,
                            },
                        },
                        labelLayerId
                    );
                });
            },
            disable3D(e) {
                let visibility = this.map.style.getLayer("3d-buildings")
                    .visibility;
                if (visibility === "visible") {
                    this.map.setLayoutProperty(
                        "3d-buildings",
                        "visibility",
                        "none"
                    );
                    this.mapValues.map3d = false;
                } else {
                    this.map.setLayoutProperty(
                        "3d-buildings",
                        "visibility",
                        "visible"
                    );
                    this.mapValues.map3d = true;
                }
            },
            changeLayers(e) {},
            valuePercentStep(end, creation) {
                return newFilter.percentStep(1, end, creation);
            },
            previewAction(action) {
                if (this.currentTabEditing) {
                    this.$emit("send-notity", [
                        "warning",
                        "Vous êtes en phase d'édition, terminer ou annuler pour ouvrir l'aperçu d'une action.",
                    ]);
                } else {
                    this.currentTabPreview = "preview-" + action.type;
                    this.currentTabValues = action.values;
                    this.currentTabState = action.state;
                }
            },
            editingAction(action) {
                if (this.currentTabEditing) {
                    this.$emit("send-notity", [
                        "warning",
                        "Vous êtes en phase d'édition, terminer ou annuler pour ouvrir l'édition d'une action.",
                    ]);
                } else {
                    this.currentTabPreview = false;
                    this.currentTabEditing = "editing-" + action.type;
                    this.currentTabValues = action.values;
                }
            },
            returnActionStudy(action) {
                if (action[0] == "close") {
                    this.currentTabPreview = false;
                    this.currentTabEditing = false;
                    this.currentTabValues = "";
                    this.currentTabState = "";
                } else if (action[0] == "endAndClose") {
                    this.currentTabEditing = false;
                    // TODO enregistrer en base les modifications de this.currentTabValues
                    this.currentTabValues = "";
                    this.currentTabState = "";
                } else {
                    this.currentTabPreview = false;
                    this.currentTabEditing = "editing-" + action[0];
                    this.currentTabValues = action[1];
                }
            },
        },
        components: {
            siteBarRight,
            //infos études
            previewSector,
            previewMarket,
            previewProgramme,
            previewFiles,
            previewOwners,
            previewNotary,
            previewGoodInformation,
            previewSalesInformation,
            editingSector,
            editingMarket,
            editingProgramme,
            editingFiles,
            editingOwners,
            editingNotary,
            editingGoodInformation,
            editingSalesInformation,

            //Estimations des lots
            previewPlotsEstimation,
            editingPlotsEstimation,

            //Constructibilité
            previewConstructibility,
            editingConstructibility
        },
    };
</script>

<style lang="scss">
    @import "../css/app";

    .project {
        .stepper {
            position: absolute;
            height: 80px;
            left: 0;
            bottom: 0;
            right: 0;
            background-color: $grey05;
            z-index: 11;
            transition: all 0.2s ease;
            box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.03);

            &:hover {
                height: 156px;

                .time {
                    .timeLeft {
                        left: 10px;
                    }
                }

                .steps {
                    .step {
                        font-size: 8px;
                        line-height: 12px;

                        .infos {
                            padding: 0 0 10px 0;

                            i {
                                padding: 0 0 10px;
                                font-size: 28px;
                                line-height: 35px;
                            }
                        }

                        &.active {
                            .infos {
                                color: $grey00;

                                i {
                                    color: $blue00;
                                    font-size: 38px;
                                }
                            }
                        }
                    }
                }
            }

            .time {
                .timeLeft {
                    display: block;
                    font-size: 11px;
                    height: 25px;
                    border-radius: 25px;
                    line-height: 25px;
                    color: white;
                    box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.03);
                    text-align: right;
                    padding: 0 10px 5px;
                    position: absolute;
                    left: -250px;
                    top: -35px;
                    transition: all 0.2s ease;

                    i {
                        padding: 0 7px 0 0;
                        font-size: 16px;
                        line-height: 25px;
                        float: left;
                    }
                }

                .bgBar {
                    display: block;
                    height: 5px;
                    background-color: $grey03;

                    .bar {
                        display: block;
                        height: 5px;
                        float: left;
                        background-color: $grey02;
                        max-width: 100%;
                    }
                }
            }

            .steps {
                padding: 22px 50px 30px 50px;

                .step {
                    width: 10%;
                    text-align: center;
                    float: left;
                    font-size: 0px;
                    line-height: 0px;
                    position: relative;

                    .infos {
                        padding: 0;
                        transition: all 0.2s ease;
                        color: $grey03;

                        i {
                            display: block;
                            font-size: 0px;
                            line-height: 0px;
                            padding: 0;
                            transition: all 0.2s ease;
                        }
                    }

                    .bullet {
                        .barLeft {
                            float: left;
                            display: block;
                            height: 1px;
                            background-color: $grey03;
                            width: 50%;
                            margin: 17px 0 0 0;
                        }

                        .circle {
                            position: absolute;
                            left: 50%;
                            margin: 0 0 0 -17px;
                            display: block;
                            width: 14px;
                            height: 14px;
                            background-color: $grey03;
                            border: 10px solid $grey05;
                            box-sizing: content-box;
                            border-radius: 30px;
                        }

                        .barRight {
                            float: left;
                            display: block;
                            height: 1px;
                            background-color: $grey03;
                            width: 50%;
                            margin: 17px 0 0 0;
                        }
                    }

                    &:first-child {
                        .bullet {
                            .barLeft {
                                display: none;
                            }

                            .circle {
                                float: right;
                            }

                            .barRight {
                                float: right;
                            }
                        }
                    }

                    &:last-child {
                        .bullet {
                            .barRight {
                                display: none;
                            }
                        }
                    }

                    &.past {
                        .bullet {
                            .circle {
                                background-color: $green;
                            }
                        }
                    }

                    &.active {
                        .bullet {
                            .circle {
                                background-color: $blue00;
                            }
                        }
                    }
                }
            }
        }

        .actions {
            position: absolute;
            box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.03);
            background-color: $grey05;
            z-index: 10;
            top: 0;
            left: 0;
            bottom: 0px;
            width: 41%;

            .actors {
                text-align: right;
                padding: 0 20px;
                margin: 50px 0 0 0;
                width: 100%;

                span {
                    display: inline-block;
                    width: 30px;
                    height: 30px;
                    margin: 0 0 0 20px;
                    cursor: pointer;
                    border-radius: 15px;
                }
            }

            .theirActions,
            .myActions {
                background-color: white;
                margin: 50px 20px;
                border-radius: 5px;
                padding: 35px 40px 30px;
                box-shadow: 0px 5px 15px #0000000d;

                .title {
                    font-size: 13px;
                    line-height: 20px;
                    font-weight: 600;
                    margin: 0 0 10px 0;
                }

                .listActions {
                    .action {
                        overflow: hidden;
                        position: relative;

                        &:hover {
                            .name {
                                .edit {
                                    opacity: 1;
                                }
                            }
                        }

                        .state {
                            float: left;

                            div {
                                margin: 6px 20px 11px 0;
                                width: 24px;
                                height: 24px;
                                border: 2px solid $grey03;
                                border-radius: 12px;
                                text-align: center;
                                font-size: 16px;
                            }

                            .empty {
                            }

                            .init {
                                line-height: 9px;
                                font-size: 20px;
                                color: $grey03;
                            }

                            .finish {
                                color: white;
                                background-color: $green00;
                                border: 2px solid $green00;
                                border-radius: 12px;
                                line-height: 24px;
                            }

                            .lock {
                                font-size: 14px;
                                line-height: 21px;
                                background-color: $grey03;
                                border-color: $grey03;
                            }
                        }

                        .name {
                            font-size: 12px;
                            line-height: 18px;
                            padding: 8px 0 0 0;
                            transition: all 0.2s ease;

                            &.lock {
                                color: $grey02;
                                font-style: italic;
                            }

                            .edit {
                                display: inline-block;
                                float: right;
                                position: absolute;
                                right: 0;
                                top: 0;
                                opacity: 0;
                                transition: all 0.2s ease;
                            }
                        }
                    }
                }
            }

            .myActions {
                .listActions {
                    .action {
                        .state {
                            cursor: pointer;
                        }

                        .name {
                            span {
                                cursor: pointer;
                            }
                        }
                    }
                }
            }
        }

        .preview {
            position: absolute;
            left: calc(41% - 300px);
            width: 300px;
            top: 0;
            box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.03);
            bottom: 0px;
            background-color: white;
            transition: all 0.2s ease;

            &.active {
                left: 41%;

                .content {
                    opacity: 1;
                }
            }

            .content {
                opacity: 0;
                transition: all 0.2s ease;
                width: 100% !important;
                padding: 0 40px;

                .link {
                    overflow: hidden;

                    .button {
                        display: block;
                        margin: 0 0 20px 0;
                    }
                }

                .headerPreview {
                    margin: 20px 0 30px 0;
                    font-size: 16px;
                    line-height: 20px;
                    font-weight: 600;

                    span {
                        font-size: 10px;
                        line-height: 16px;
                        font-weight: 400;
                        color: $grey02;
                        display: block;
                    }
                }

                .bloc {
                    margin: 0 0 20px 0;

                    .answer {
                        font-size: 12px;
                        line-height: 18px;
                        margin: 0 0 10px 0;
                        color: $grey02;

                        span {
                            color: $blue;
                            font-size: 14px;
                            font-weight: 600;
                        }
                    }

                    .response {
                        font-size: 13px;
                        line-height: 20px;
                        padding: 0 0 10px 0;
                        font-weight: 600;

                        span {
                            display: block;
                            color: $grey02;
                            font-weight: 400;
                            line-height: 16px;
                            font-size: 11px;

                            &.regular {
                                color: $grey00;
                                font-size: 13px;
                                line-height: 20px;
                                padding: 0 0 2px 0;
                            }

                            &.grey{
                                color: $grey01;
                            }

                            &.date {
                                font-size: 9px;
                                padding: 3px 0 0 0;
                            }
                        }

                        .arrow {
                            font-size: 13px;
                            line-height: 20px;
                            font-weight: 600;

                            &.finalPrice{
                                font-size: 15px;
                                line-height: 20px;
                                font-weight: 500;
                                i {
                                    color: $blue01;
                                }
                            }

                            i {
                                font-size: 16px;
                                float: left;
                                color: $grey04;
                                line-height: 20px;
                                padding: 0 10px 0 0 !important;

                                &.yes,
                                &.no {
                                    color: $grey03;
                                }
                            }

                            span {
                                display: inline !important;
                            }

                            .sub {
                                .red {
                                    color: $red;
                                }

                                span {
                                    display: inline !important;
                                }

                                div {
                                    display: inline;
                                }

                                .table {
                                    display: table;
                                }
                            }
                        }

                        .files {
                            i {
                                float: left;
                                font-size: 16px;
                                color: $grey03;
                                padding: 3px 10px 0 0;
                            }

                            .name {
                                display: table;

                                a {
                                    font-weight: 600;
                                }

                                span {
                                    font-size: 9px;
                                    color: $grey03;
                                }
                            }
                        }
                    }

                    .empty {
                        font-size: 13px;
                        line-height: 20px;
                        color: $grey01;
                        font-weight: 500;

                        i {
                            font-size: 16px;
                            float: left;
                            line-height: 20px;
                            color: $red;
                            padding: 0 10px 0 0;

                            &.grey {
                                color: $grey03;
                            }
                        }
                    }
                }

                .inquire {
                    color: $grey04;
                    font-size: 16px;
                    line-height: 20px;
                    font-weight: 400;

                    i {
                        font-size: 30px;
                        line-height: 39px;
                        display: block;
                        padding: 0 0 10px 0;
                    }
                }
            }
        }

        .editing {
            position: absolute;
            left: calc(41% - 59%);
            width: 59%;
            top: 0;
            box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.03);
            bottom: 0px;
            background-color: white;
            border-right: 1px solid $grey05;
            transition: all 0.2s ease;

            &.active {
                left: 41%;

                .content {
                    opacity: 1;
                }
            }

            .content {
                opacity: 0;
                transition: all 0.2s ease;
                width: 100% !important;
                padding: 10% 40px 0;

                .link {
                    overflow: hidden;
                    padding: 0 15px;
                    margin: 0;

                    .button {
                        display: block;
                        margin: 0 0 20px 0;
                    }
                }

                .headerEditing,
                .headerPreview {
                    margin: 20px 0 30px 0;
                    font-size: 16px;
                    line-height: 20px;
                    font-weight: 600;

                    span {
                        font-size: 10px;
                        line-height: 16px;
                        font-weight: 400;
                        color: $grey02;
                        display: block;
                    }
                }

                .headerEditing {
                    padding: 0 15px;

                    .stepAction {
                        display: inline-block;
                        font-size: 11px;
                        color: $grey02;
                        margin: 0 0 0 10px;
                        font-weight: 400;

                        span {
                            display: inline-block;
                            font-size: 11px;
                            color: $blue00;
                            font-weight: 600;
                        }
                    }
                }

                .form {
                    margin: 0 0 20px;

                    .boxed {
                        width: 65%;
                        padding: 20px 0;
                        margin: 0 auto;
                    }

                    .answer {
                        font-size: 12px;
                        line-height: 18px;
                        margin: 0 0 10px 0;
                        color: $grey02;
                        padding: 0 15px;
                    }

                    .listBlocs {
                        overflow: hidden;
                        padding: 20px 0 0 0;
                        display: flex;
                        flex-direction: row;
                        flex-wrap: nowrap;
                        justify-content: stretch;

                        .bloc {
                            padding: 0 15px;
                            text-align: center;
                            flex: 1;
                            margin: 0 0 20px 0;

                            .conteneur {
                                height: 130px;
                                background-color: #ffffff;
                                box-shadow: 0px 5px 15px #0000000d;
                                border: 1px solid $grey05;
                                padding: 10px;
                                border-radius: 5px;
                                display: flex;
                                flex-direction: column;
                                justify-content: center;
                                transition: all 0.2s ease;
                                cursor: pointer;

                                &.active {
                                    box-shadow: none;
                                    border: 1px solid $blue02;

                                    span {
                                        color: $blue;

                                        span {
                                            color: $grey02;
                                        }
                                    }
                                }

                                &:hover {
                                    box-shadow: none;
                                }

                                span {
                                    font-size: 16px;
                                    font-weight: 600;
                                    line-height: 20px;
                                    transition: all 0.2s ease;

                                    span {
                                        font-size: 11px;
                                        padding: 5px 0 0 0;
                                        line-height: 14px;
                                        color: $grey02;
                                        font-weight: 400;
                                        display: block;
                                    }
                                }
                            }

                            @media screen and (max-width: 1600px) {
                                .conteneur {
                                    height: 110px;

                                    span {
                                        font-size: 15px;
                                        line-height: 18px;

                                        span {
                                            font-size: 10px;
                                        }
                                    }
                                }
                            }

                            @media screen and (max-width: 1400px) {
                                .conteneur {
                                    height: 100px;

                                    span {
                                        font-size: 12px;
                                        line-height: 17px;

                                        span {
                                            font-size: 9px;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    .slider {
                        .title {
                            font-size: 13px;
                            text-align: center;
                        }
                    }

                    .input {
                        padding: 0 15px 20px;
                    }

                    .subTitle {
                        font-weight: 500;
                        margin: 20px 0 0 0;
                    }
                }

                .bloc {
                    margin: 0 0 30px 0;

                    .answer {
                        font-size: 12px;
                        line-height: 18px;
                        margin: 0 0 10px 0;
                        color: $grey02;
                    }

                    .response {
                        font-size: 13px;
                        line-height: 20px;
                        font-weight: 600;

                        span {
                            display: block;
                            color: $grey02;
                            font-weight: 400;
                            line-height: 16px;
                            font-size: 11px;
                        }
                    }
                }

                @media screen and (max-width: 1400px) {
                    .headerEditing {
                        padding: 0 10px;
                    }

                    .link {
                        padding: 0 10px;
                    }

                    .form {
                        .answer {
                            padding: 0 10px;
                        }

                        .listBlocs {
                            .bloc {
                                padding: 0 10px;
                            }
                        }
                    }
                }
            }
        }

        .map {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            width: 59%;
            background-color: $grey04;

            #map {
                position: absolute;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
            }

            .button3d {
                position: absolute;
                top: 110px;
                right: 10px;
            }

            .buttonLayers {
                position: absolute;
                top: 150px;
                right: 10px;
            }

            .buttonMap {
                text-align: center;
                line-height: 30px;
                font-weight: 500;
                font-size: 14px;
                display: inline-block;
                width: 30px;
                height: 30px;
                background-color: white;
                border-radius: 5px;
                cursor: pointer;
                box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1);
                transition: all 0.2s ease;

                &:hover {
                    background-color: $grey04;
                }

                &.active {
                    background-color: $yellow;
                }
            }
        }
    }
</style>
