<template>
    <div id="login">
        <div class="leftDecoration">
            <div class="title">
                {{spaceName}}
            </div>
            <span class="infos">
                {{description}}
            </span>
            <div class="imgDecoration"></div>
        </div>
        <div class="loginContent">
            <q-inner-loading :showing="authentificationIsLoginLoading">
                <q-spinner size="3em" :thickness="2" color="primary" />
            </q-inner-loading>
            <div class="contentLeft">
                <div class="logo">
                    <img src="../statics/logo-login.png" alt="">
                </div>
                <div class="form" v-if="!hasForgetPassword">
                    <div class="input-col1">
                        <span><q-input v-model="mail" label="Votre adresse e-mail" @keyup.enter="login"/></span>
                    </div>
                    <div class="input-col1">
                        <q-input v-model="password" :type="isPwd ? 'password' : 'text'" label="Votre mot de passe" @keyup.enter="login">
                            <template v-slot:append>
                                <q-icon :name="isPwd ? 'fal fa-eye-slash' : 'fal fa-eye'" class="cursor-pointer" @click="isPwd = !isPwd" />
                            </template>
                        </q-input>
                    </div>
                    <div v-if="authFailed"> Le login ou le mot de passe est incorrect</div>
                    <div class="validateButton right">
                        <q-btn @click="login" unelevated class="button small right" color="blue" text-color="white" label="Entrer" />
                    </div>
                    <div class="bottomSection">
                        <a class="forgotPassword" @click="changeHasForgetPassword(true)">
                            Mot de passe oublié
                        </a>
                        <div class="signUp" v-if="1 == 0">
                            <span class="signUpTextDescription">Pas de compte ? </span> <a>S'inscrire</a>
                        </div>
                    </div>
                </div>
                <div class="form" v-if="hasForgetPassword">
                    <div class="title">
                        Mot de passe oublié ?
                    </div>
                    <div class="step1" v-if="stepForgetPassword == 1">
                        <div class="input-col1">
                            <q-input v-model="mail" label="Votre adresse e-mail" @keyup.enter="login"/>
                        </div>
                        <div class="validateButton row justify-end">
                            <q-btn @click="changeHasForgetPassword(false)" unelevated class="button small right" label="Annuler"  />
                            <q-btn @click="sendMailToResetPassword" unelevated class="button small right margin" color="blue" text-color="white" label="Envoyer ma demande"  />
                        </div>
                        <div class="bottomSection">
                            <div class="signUp">
                                <span class="signUpTextDescription">Vous avez un compte ? </span> <a @click="changeHasForgetPassword(false)">Se connecter</a>
                            </div>
                        </div>
                    </div>
                    <div class="step2" v-if="stepForgetPassword == 2">
                        <div class="input-col1">
                            <q-input v-model="checkCode" label="Code de renouvellement" @keyup.enter="login"/>
                        </div>
                        <div class="validateButton row justify-end">
                          <q-btn @click="changeHasForgetPassword(false)" unelevated class="greyButton medium cancel" label="Annuler"  />
                          <q-btn @click="changeStepForgetPassword(2)" unelevated class="coloredButton small" label="Valider le code"  />
                        </div>
                    </div>
                    <div class="step3" v-if="stepForgetPassword == 3">
                        <q-input v-model="newPassword" :type="isPwd ? 'password' : 'text'" label="Nouveau mot de passe" @keyup.enter="login">
                            <template v-slot:append>
                                <q-icon :name="isPwd ? 'visibility_off' : 'visibility'" class="cursor-pointer" @click="isPwd = !isPwd" />
                            </template>
                        </q-input>
                        <div class="validateButton">
                            <q-btn @click="changeHasForgetPassword(false)" push rounded unelevated color="primary" size="md" label="Valider le changement" class="right" />
                        </div>
                    </div>
                </div>
                <div class="copyright">
                    Développé avec <i class="fal fa-heart"></i> à Grenoble
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vuex from 'vuex'
    import Store from '../store/index'

    export default {
        name: "Login",
        data(){
            return {
                authFailed : false,
                mail : '',
                password : '',
                isPwd : true,
                checkCode : '',
                newPassword : '',
                hasForgetPassword : false,
                stepForgetPassword : 1,
                spaceName : '',
                description: '',
                urlPicto : ''
            }
        },
        created(){
            var fullPath = window.location.href
            if(fullPath.match('agence') != null){
                this.spaceName = 'ESPACE AGENCE'
                this.description = 'Accéder à votre espace agence dédié, et profiter de nombreuses fonctionnalités de valorisation foncière.'
                this.urlPicto = '../statics/picto-login.png'
            }else if(fullPath.match('geometre') != null){
                this.spaceName = 'ESPACE GÉOMÈTRE'
                this.description = 'Accéder à votre espace géomètre dédié, et profiter de nombreuses fonctionnalités de valorisation foncière.'
                this.urlPicto = '../statics/picto-login.png'
            }else{
                this.spaceName = 'ESPACE PARTENAIRE'
                this.description = 'Accéder à votre espace géomètre dédié, et profiter de nombreuses fonctionnalités de valorisation foncière.'
                this.urlPicto = '../statics/picto-login.png'
            }


        },
        computed:{
          ...Vuex.mapGetters(['authentificationIsLoginLoading'])
        },
        methods :{
            ...Vuex.mapActions([
                'login','getProfile','getResetPassword'
            ]),
            login() {
                Store.dispatch("login", { mail: this.mail, password: this.password }).then(response => {
                    if (response.status == 201) {
                        let token = response.body.access_token;
                        if (token != "" && token != undefined) {
                            localStorage.setItem('jwt', token)
                            this.goToDashboard()
                        }
                    } else {
                        this.authFailed = true;
                    }
                }, error => {
                    this.authFailed = true;
                })
            },
            goToDashboard(){
                this.$router.push({ name: "ListingStudies" })
            },
            changeStepForgetPassword(step){
                this.stepForgetPassword = step
            },
            changeHasForgetPassword(type){
                this.hasForgetPassword = type
                if (type){
                    this.stepForgetPassword = 1
                }
            },
            sendMailToResetPassword(){
                if(this.mail != ''){
                    Store.dispatch("getResetPassword", { mail: this.mail}).then(response => {
                        this.$emit('send-notity', ['positive', 'Un mail vient de vous être envoyé, suivez les instructions pour changer votre mot de passe.'])
                    }, error => {
                        if (error.status == 404) {
                            this.$emit('send-notity', ['warning', 'Votre adresse mail n\'existe pas'])
                        } else {
                            this.$emit('send-notity', ['negative', 'Format d\'adresse e-mail invalide'])
                        }
                    })
                } else {
                    this.$emit('send-notity', ['warning', 'Le champ adresse e-mail ne peut être vide'])
                }
            }
        }
    }
</script>

<style lang="scss">

    @import "../css/app.scss";

    #login{

        .leftDecoration{
            overflow: hidden;
            position: absolute;
            top: 0px;
            left: 0px;
            width: 30%;
            bottom: 0;
            background: transparent radial-gradient(closest-side at 0% 0%, #E6ECEF 0%, #F5F6FA 100%) 0% 0% no-repeat padding-box;
            opacity: 1;

            .title{
                padding: 48.5px 38px 15px 48.5px ;
                text-align: left;
                font: Bold 20px/28px Poppins;
            }

            .infos{
                font-size: 10px;
                line-height: 16px;
                margin: 0 0 0 50px;
                display: block;
                width: 60%;
                color: $grey02;
            }

            .imgDecoration{
                background-image: url("../statics/picto-login.png");
                position: absolute;
                bottom: 0;
                right: 0;
                width: 100%;
                height: 100%;
                background-size: 100%;
                background-position: bottom;
                pointer-events: none;
                background-repeat: no-repeat;
            }

        }

        .loginContent{
            position: absolute;
            left: 30%;
            right: 0;
            bottom: 0;
            top: 0;

            .contentLeft{
                width: 300px;
                margin: 200px auto 0;

                .logo{
                    text-align: center;
                    margin: 0 0 40px 0;

                    img{
                        width: 25%;
                    }

                }

                .title{
                    width: 100%;
                    text-align: left;
                    font-weight: 500;
                    line-height: 20px;
                    font-size: 14px;
                    margin: 0;
                }

                .form{

                    .bottomSection{
                        margin-top: 40px;
                        overflow: hidden;

                        .forgotPassword{
                            cursor: pointer;
                            text-decoration: underline;
                            opacity: 1;
                        }

                        .signUp{
                            padding: 15px 0 0;
                        }

                    }

                }

                .copyright{
                    position: absolute;
                    bottom: 60px;
                    font-size: 12px;
                    color: $grey02;
                    width: 100%;
                    left: 0;
                    text-align: center;
                }

            }

        }

    }

</style>
