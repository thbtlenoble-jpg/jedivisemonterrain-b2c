<template>
    <div id="content" class="dashboard">
        <div class="contentLeft">
            <div class="headerBloc">
                <div class="title">
                    <span>Tableau de bord</span>
                </div>
                <div class="blocAction">
                    <q-btn class="buttonAction" color="white" text-color="black" label="Nouveau Projet"/>
                    <q-btn class="buttonAction" color="white" text-color="black" label="Ajouter un agent commercial"/>
                </div>
            </div>
            <div class="bodyBloc">
                <div class="projectOverviewListing">
                    <div class="projectOverview">
                        <div class="pourcent">
                            <q-linear-progress size="20px" :value="progress" color="accent">
                                <div class="absolute-full flex flex-center">
                                    <q-badge color="white" text-color="black" :label="progressLabel"/>
                                </div>
                            </q-linear-progress>
                        </div>
                        <div class="infoProject">
                            <div class="ref">
                                <i class="fas fa-circle"></i>
                                <span>Réf. 58878</span>
                            </div>
                            <div class="address">
                                <i class="fad fa-map-marker-alt"></i>
                                <div class="streetAddress">
                                    <span>16 Rue de la Ganterie</span>
                                </div>
                                <div class="city">
                                    <span>38760 VARCHES-ALLIERES-ET-RISSET</span>
                                </div>
                            </div>
                            <div class="contenance">
                                <span>Total de 1 523m²</span>
                            </div>
                            <div class="handleBy">
                                <span>Traité par Séverine</span>
                            </div>
                        </div>
                        <div class="step">
                            <span class="title">Etape en cours</span>
                            <span class="stepInfo">Informations projet</span>
                        </div>
                        <div class="status">
                            <div class="statusInfo">
                                <i class="fas fa-server"></i>
                                <span>Des actions sont requises</span>
                            </div>
                            <div class="actionList">
                                <ul>
                                    <li>Compléter les informations</li>
                                    <li>Ajouter les informations vendeurs</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="projectOverview">
                        <div class="pourcent">
                            <q-linear-progress size="20px" :value="progress" color="accent">
                                <div class="absolute-full flex flex-center">
                                    <q-badge color="white" text-color="black" :label="progressLabel"/>
                                </div>
                            </q-linear-progress>
                        </div>
                        <div class="infoProject">
                            <div class="ref">
                                <i class="fas fa-circle"></i>
                                <span>Réf. 58878</span>
                            </div>
                            <div class="address">
                                <i class="fad fa-map-marker-alt"></i>
                                <div class="streetAddress">
                                    <span>16 Rue de la Ganterie</span>
                                </div>
                                <div class="city">
                                    <span>38760 VARCHES-ALLIERES-ET-RISSET</span>
                                </div>
                            </div>
                            <div class="contenance">
                                <span>Total de 1 523m²</span>
                            </div>
                            <div class="handleBy">
                                <span>Traité par Séverine</span>
                            </div>
                        </div>
                        <div class="step">
                            <span class="title">Etape en cours</span>
                            <span class="stepInfo">Informations projet</span>
                        </div>
                        <div class="status">
                            <div class="statusInfo">
                                <i class="fas fa-server"></i>
                                <span>Des actions sont requises</span>
                            </div>
                            <div class="actionList">
                                <ul>
                                    <li>Compléter les informations</li>
                                    <li>Ajouter les informations vendeurs</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="statBloc">

                    <div class="graphStat">
                        <img src="../assets/graph.jpg" alt="Ouai ouai">
                    </div>

                    <div class="bottomStatbloc">

                        <div class="agentCoBloc">

                            <div class="infoGeneralAgentCo">

                                <div class="infoAgentCo">
                                    <div class="profilePicture"></div>
                                    <div class="personalInfo">
                                        <span class="name">Florent Potignon</span>
                                        <span class="job">Agent commercial</span>
                                    </div>
                                </div>

                                <div class="statProjectGestion">
                                    <span>6 Projets en gestion pour un total de 17 587 m²</span>
                                </div>

                                <div class="lastAddProject">
                                    <span>Dernier projet ajouté le 17 Janvier 2020</span>
                                </div>
                            </div>
                            <div class="projectAdded">
                                <span> 18 projets ajoutés au total</span>
                            </div>
                            <div class="statusProjects">
                                <div class="inProgress cell">
                                    <span>6 En cours</span>
                                </div>
                                <div class="achieved cell">
                                    <span>3 Terminés</span>
                                </div>
                                <div class="closed cell">
                                    <span>9 Archivés</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="supportBloc">
                            <div class="logo">
                                <i class="fas fa-question-circle"></i>
                            </div>
                            <div class="title">
                                <span>Support</span>
                            </div>
                            <div class="question">
                                <span>Une question ?</span>
                            </div>
                            <div class="text">
                                Vous pouvez-nous joindre de 9h à 12h et de 14h à 18h au 04 76 00 00 00
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="contentRight">
                <div class="statContentRight">
                    <div class="projectInProgress statContentRightBloc">
                        <div class="icon">
                            <i class="fas fa-hourglass"></i>
                        </div>
                        <div class="contentBloc">

                            <div class="numberProject">
                                <span>8</span>
                            </div>

                            <div class="description">
                                <span>projets en attente</span>
                            </div>

                        </div>

                    </div>
                    <div class="projectInWaiting statContentRightBloc">
                        <div class="icon">
                            <i class="fas fa-server"></i>
                        </div>
                        <div class="contentBloc">
                        <div class="numberProject">
                            <span>3</span>
                        </div>
                        <div class="description">
                            <span>projets en attente d'action</span>
                        </div>
                        </div>
                    </div>
                    <div class="projectInProgressOnParterns statContentRightBloc">

                        <div class="icon">
                            <i class="fas fa-cog"></i>
                        </div>

                        <div class="contentBloc">

                            <div class="numberProject">
                                <span>6</span>
                            </div>

                            <div class="description">
                                <span>projets en cours chez un partenaire</span>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="lastActionContentRight">
                    <div class="title">
                        <span>Dernières actions réalisées</span>
                    </div>

                    <div class="listLastActions">
                        <div class="lastActionsBloc">
                            <div class="icon">
                                <i class="fas fa-plus"></i>
                            </div>
                            <div class="lastActionsBody">
                                <div class="actionsType">
                                    <span>Ajout d'informations (Réf. 785858)</span>
                                </div>
                                <div class="date">
                                    <span>20 février 2020 à 10h41 par Mickael</span>
                                </div>
                            </div>
                        </div>

                        <div class="lastActionsBloc">
                            <div class="icon">
                                <i class="fas fa-edit"></i>
                            </div>
                            <div class="lastActionsBody">
                                <div class="actionsType">
                                    <span>Modification d'un vendeur (Réf. 785858)</span>
                                </div>
                                <div class="date">
                                    <span>20 février 2020 à 10h41 par Mickael</span>
                                </div>
                            </div>
                        </div>

                        <div class="lastActionsBloc">
                            <div class="icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="lastActionsBody">
                                <div class="actionsType">
                                    <span>Modification d'un vendeur (Réf. 785858)</span>
                                </div>
                                <div class="date">
                                    <span>20 février 2020 à 10h41 par Mickael</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Dashboard",
        data() {
            return {
                progress: 0.15,
                progressLabel: '15%'
            }
        }
    }
</script>

<style lang="scss">
    .dashboard {
        .contentLeft{
            .headerBloc {
                padding-left: 100px;
                padding-top: 40px;
                padding-bottom: 40px;
                float: left;
                width: 100%;

                span {
                    font-weight: bolder;
                    font-size: 18px;
                }

                .blocAction {
                    padding-top: 20px;

                    .buttonAction {
                        margin-right: 50px;
                        padding: 10px;
                        width: 200px;
                        height: 80px;
                    }
                }
            }
            .bodyBloc{

                float: left;
                width: 100%;

                .projectOverviewListing{

                    float: left;
                    width: 50%;
                    padding: 0 50px;

                    .projectOverview{
                        border: black 2px solid;
                        width: 45%;
                        float: left;

                        &:nth-child(2n+1){
                            margin-right: 5%;
                        }

                        &:nth-child(2n+2){
                            margin-left: 5%;
                        }

                        .pourcent{
                            float: left;
                            width: 100%;
                        }
                        .infoProject{
                            float: left;
                            width: 100%;
                            padding: 10px 20px;

                            .ref{
                                float: left;
                                width: 100%;
                                i{
                                    font-size: 18px;
                                    float: left;

                                }
                                span{
                                    padding: 10px;
                                }
                            }

                            .address{
                                float: left;
                                padding-top: 10px;
                                width: 100%;

                                i{
                                    font-size: 18px;
                                    float: left;
                                    padding-left: 2px;

                                }

                                .streetAddress{
                                    float: left;
                                    padding-left: 10px;
                                }

                                .city{
                                    float: left;
                                    width: 100%;
                                    padding-left: 27px;
                                }

                            }

                            .contenance{
                                float: left;
                                width: 100%;
                                padding-top: 15px;
                                text-align: center;

                                span{
                                    color: darkgrey;
                                    font-weight: bolder;
                                }
                            }

                            .handleBy{
                                float: left;
                                width: 100%;
                                text-align: center;
                                padding-bottom: 15px;
                                span{
                                    color: lightgray;
                                    font-size: 12px;
                                }
                            }

                        }
                        .step{
                            float: left;
                            width: 100%;
                            padding: 10px 10px 10px 25px;
                            border-top: solid black 2px;
                            border-bottom: solid black 2px;
                            background-color: white;
                            span{
                                display: block;
                            }
                            .title{
                                color: gray;

                            }
                            .stepInfo{
                                font-size: 16px;
                                font-weight: bolder;
                            }
                        }

                        .status{
                            float: left;
                            width: 100%;

                            .statusInfo{
                                float: left;
                                width: 100%;
                                text-align: center;
                                i{
                                    padding-top: 20px;
                                    font-size: 30px;
                                }
                                span{
                                    display: block;
                                }
                            }

                            .actionList{
                                float: left;
                                width: 100%;
                                padding-bottom: 10px;

                                ul{
                                    float: left;
                                    width: 100%;

                                    li{
                                        list-style: decimal;
                                    }
                                }
                            }
                        }

                    }
                }

                .statBloc{
                    float : left;
                    width: 50%;

                    padding: 20px;
                    .graphStat{
                        text-align: center;

                        img{
                            width: 100%;
                        }
                    }
                    .bottomStatbloc{
                        float: left;
                        width: 100%;


                        .agentCoBloc{


                            float: left;
                            width: 45%;
                            height: 240px;
                            border: black solid 2px;
                            border-collapse: collapse;

                            .infoGeneralAgentCo{
                                padding: 20px 20px 10px 20px;
                                float: left;
                                width: 100%;
                                text-align: center;

                                .infoAgentCo{
                                    float: left;
                                    width: 100%;

                                    .profilePicture{
                                        margin-left: 10px;
                                        float: left;
                                        height: 40px;
                                        width: 40px;
                                        border-radius: 100%;
                                        background-color: black;

                                    }
                                    .personalInfo{
                                        float: left;
                                        padding-left: 10px;

                                        span{
                                            display: block;
                                        }
                                        .name{
                                            font-weight: bolder;
                                            font-size: 16px;
                                            padding-left: 2px ;
                                        }
                                        .job{

                                        }
                                    }
                                }

                                .statProjectGestion{
                                    text-align: left;
                                    float: left;
                                    width: 100%;
                                    padding: 10px 20px 5px 20px;
                                    font-weight: bolder;
                                }

                                .lastAddProject{
                                    float: left;
                                    width: 100%;
                                    padding: 5px 20px;
                                    text-align: left;
                                    font-size: 12px;
                                    font-weight: bolder;
                                    color: gray;
                                }

                            }

                            .projectAdded{
                                float: left;
                                width: 100%;
                                text-align: center;
                                padding: 10px 5px;
                                border-top: black solid 2px ;
                                border-bottom: black solid 2px ;
                            }

                            .statusProjects{
                                float: left;
                                width: 100%;

                                .cell{
                                    float: left;
                                    width: 33.33%;
                                    text-align: center;
                                    padding: 5px;
                                }

                                .inProgress{
                                    background-color: orange;
                                }

                                .achieved{
                                    background-color: green;
                                    border-left: black solid 2px ;
                                    border-right: black solid 2px ;
                                }

                                .closed{
                                    background-color: lightgray;
                                }

                            }
                        }

                        .supportBloc{
                            float: right;
                            width: 45%;
                            height: 240px;
                            height: 240px;
                            text-align: center;
                            border: black solid 2px;

                            .logo{
                                float: left;
                                width: 100%;
                                padding: 20px;

                                i{
                                    font-size: 50px;
                                }
                            }

                            .title{
                                float: left;
                                width: 100%;
                                font-size: 12px;
                                padding: 10px;
                            }

                            .question{
                                font-weight: bolder;
                            }

                            .text{
                                font-weight: bolder;
                                padding: 0 30px;
                            }
                        }
                    }
                }
            }
        }

        .contentRight{
            .statContentRight{
                float: left;
                width: 100%;
                margin-top: 50%;
                padding-left: 10%;
                padding-right: 10%;
                .statContentRightBloc{
                    float: left;
                    margin-top: 10%;
                    width: 100%;
                    padding: 10px;
                    border: black solid 2px;

                    .icon{
                        width: 20%;
                        float: left;
                        padding-top: 10px;
                        i{
                            font-size: 30px;
                        }
                    }

                    .contentBloc{
                        float: left;
                        width: 80%;
                        .numberProject{
                            font-weight: bolder;
                            font-size: 20px;
                        }
                        .description{
                            font-weight: bolder;
                        }
                    }
                }
            }

            .lastActionContentRight{
                float: left;
                width: 100%;
                padding-left: 10%;
                .title{
                    float: left ;
                    width: 100%;
                    padding: 20px 0 5px 0 ;

                }

                .lastActionsBloc{
                    float: left;
                    width: 100%;
                    padding: 10px 0;
                    .icon{
                        padding-top: 5px;
                        float: left;
                        i{
                            font-size: 20px;
                        }
                    }

                    .lastActionsBody{
                        float: left;
                        padding-left: 10px;
                        font-size: 12px;
                        .actionsType{
                            font-weight: bold;
                        }
                    }
                }
            }
        }


    }
</style>