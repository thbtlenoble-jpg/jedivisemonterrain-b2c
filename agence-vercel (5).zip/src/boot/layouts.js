import Vue from 'vue'

import Default from "../layouts/Default.vue"
import Empty from "../layouts/Empty.vue"

Vue.component('Default-layout', Default);
Vue.component('Empty-layout', Empty);

export default ({ app }) => {
    app.Default = Default,
    app.Empty = Empty
}
