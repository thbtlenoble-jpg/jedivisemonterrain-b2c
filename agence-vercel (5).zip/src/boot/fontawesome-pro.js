import Vue from 'vue'
import { library } from '@fortawesome/fontawesome-svg-core'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import {
  faHome, faList, faPlus, faTimes, faCheck, faBars, faEdit,
  faTrash, faUser, faUsers, faBuilding, faFile, faFileAlt,
  faSearch, faChevronRight, faChevronLeft, faChevronDown,
  faChevronUp, faArrowLeft, faArrowRight, faCog, faSignOutAlt,
  faMapMarkerAlt, faSave, faEye, faDownload, faUpload,
  faSpinner, faExclamationTriangle, faInfo, faInfoCircle,
  faCheckCircle, faTimesCircle, faPencilAlt, faEllipsisV,
  faFilter, faSort, faSortUp, faSortDown, faThLarge, faThList,
  faFolder, faFolderOpen, faLock, faUnlock, faEnvelope, faPhone,
  faCalendar, faCalendarAlt, faClock, faBriefcase, faMapMarker,
  faRuler, faRulerCombined, faLayerGroup, faMap, faDraftingCompass
} from '@fortawesome/free-solid-svg-icons'

library.add(
  faHome, faList, faPlus, faTimes, faCheck, faBars, faEdit,
  faTrash, faUser, faUsers, faBuilding, faFile, faFileAlt,
  faSearch, faChevronRight, faChevronLeft, faChevronDown,
  faChevronUp, faArrowLeft, faArrowRight, faCog, faSignOutAlt,
  faMapMarkerAlt, faSave, faEye, faDownload, faUpload,
  faSpinner, faExclamationTriangle, faInfo, faInfoCircle,
  faCheckCircle, faTimesCircle, faPencilAlt, faEllipsisV,
  faFilter, faSort, faSortUp, faSortDown, faThLarge, faThList,
  faFolder, faFolderOpen, faLock, faUnlock, faEnvelope, faPhone,
  faCalendar, faCalendarAlt, faClock, faBriefcase, faMapMarker,
  faRuler, faRulerCombined, faLayerGroup, faMap, faDraftingCompass
)

Vue.component('font-awesome-icon', FontAwesomeIcon)
