<template>
    <div>
        <the-side-nav-bar></the-side-nav-bar>
    <slot/>
    </div>
</template>

<script>
    import theSideNavBar from "../components/layoutsComponent/theSideNavBar";

    export default {
        components: {
            theSideNavBar,

        }
    }
</script>

<style scoped>

</style>
