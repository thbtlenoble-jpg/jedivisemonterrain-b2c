let config = {
    API : "https://api-altalis.fr/2.0/",
    APIDEV : "https://dev.api-altalis.fr/2.0/",
    APIBETA : "https://beta.api-altalis.fr/2.0/",
    APILOCAL : "http://localhost:3000/2.0/",
    AUTHURL : "auth/check",
    APIYOHAN : "https://api-altalis.yohangastoud.fr/2.0/",

    COLOR_RED : "#E85D00",
    COLOR_RED_LIGHT  : "#FFD4BE",
    COLOR_ORANGE : "#FF9820",
    COLOR_ORANGE_LIGHT : "#FFECD5",
    COLOR_GREEN : "#68B649",
    COLOR_GREEN_LIGHT : "#E8F4E4"
}

export default config
