import { date } from 'quasar'

// Récupération de tous les référentiel pour une action donnée
function getAllReferentialAction(action, referential) {
    let values = []
    referential.forEach((item, i) => {
        if(item.type == action){
            values.push(item)
        }
    })
    return values
}

// Récupération du pays
function getCountry(id, country) {
    let values = []
    country.forEach((item, i) => {
        if(item.id == id){
            values = item
        }
    })
    return values
}

function verifAllValuesEmpty(values, initValues){
    let inquire = false
    let i = 0
    for(i in values) {
        if(values[i] != initValues[i]){
            inquire = true
            break
        }
    }
    return inquire
}

function dateConverter(action, value) {

    if(action == 'decode'){
        let timeStamp = Date.parse(value)
        return date.formatDate(timeStamp, 'DD/MM/YYYY')
    } else {
        let newDate = value.substr(6) + '-' + value.substr(3, 2) + '-' + value.substr(0, 2)
        let timeStamp = Date.parse(newDate)
        return date.formatDate(timeStamp, 'YYYY-MM-DDTHH:mm:ss.SSSZ')
    }
}

function getFileFormat(value) {
    let splitChain = value.split('.')
    let type = splitChain[splitChain.length -1]
    if (type == 'jpg' || type == "jpeg" || type == "png" || type == "jfif" ){
        return "img"
    }else if(type == "pdf"){
        return "pdf"
    }else if(type == "doc"){
        return "doc"
    }else{
        return "file"
    }

}

const newFunction = {
    getAllReferentialAction,
    getCountry,
    verifAllValuesEmpty,
    dateConverter,
    getFileFormat
}

export default newFunction
