import Vue from 'vue'
import { date } from 'quasar'

const DAYS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi']
const DAYS_SHORT = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
const MONTH = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
const MONTH_SHORT = ['Jan', 'Fév', 'Mars', 'Avr', 'Mai', 'Juin', 'Jui', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc']

// Formatage d'une date
let dateFormat = Vue.filter('dateFormat', function (value, type) {
    // Timestamp de la date
    let timeStamp = Date.parse(value)

    // Type 1 : Le 9 Jan 2020
    // Type 2 : Le 9 Jan 2020 à 13h05
    if(type == 'type1'){
        return date.formatDate(timeStamp, 'D MMM YYYY', { days: DAYS, daysShort: DAYS_SHORT, months: MONTH, monthsShort: MONTH_SHORT })
    } else {
        return date.formatDate(timeStamp, 'D MMM YYYY à H:mm', { days: DAYS, daysShort: DAYS_SHORT, months: MONTH, monthsShort: MONTH_SHORT })
    }
})

// Formatage des prix sans virgule
let formatPriceInteger = Vue.filter('formatPriceInteger', function (value) {
    if (value != null){
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")
    }

})

let formatIntegerMetrix = Vue.filter('formatIntegerMetrix', function (value) {
    if (value != null){
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ' m²'
    }

})

// Formatage des prix avec 2 chiffres après la virgule
let formatPriceFloat = Vue.filter('formatPriceFloat', function (value) {
    let val = (value/1).toFixed(2).replace(' ', ',')
    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")
})

// Mettre au pluriel des éléments
let pluralize = Vue.filter('pluralize', function (value, arg1, arg2) {
    if(value <= 1){
        return arg1
    } else {
        return arg2
    }
})

// Formatage de la référence des dossiers
let digit = Vue.filter('digit', function (value) {
    if(value < 10){
        return '00000' + value
    } else if(value < 100) {
        return '0000' + value
    } else if(value < 1000) {
        return '000' + value
    } else if(value < 10000) {
        return '00' + value
    } else if(value < 100000) {
        return '0' + value
    } else {
        return value
    }
})

// Comparaison de deux date et retour du restant
let dateCompareStep = Vue.filter('dateCompareStep', function (value, date1, date2) {
    // Date actuel
    let now = Date.now()

    // Timestamp de la date de fin
    let endTimeStamp = Date.parse(date1)

    // Calcul du restant
    let diff = Math.round((endTimeStamp - now) / 1000)

    // Formatage de l'affichage
    if(diff > 0){
        let nbDays = Math.floor(diff / 60 / 60 / 24)
        let nbHours = Math.floor(diff / 60 / 60 - nbDays * 24)
        let valueJr = 'jr'
        if(nbDays > 1) { valueJr = 'jrs' }
        let valueHour = 'hr'
        if(nbHours > 1) { valueHour = 'hrs' }
        if(nbDays > 0 && nbHours > 0){
            return nbDays + ' ' + valueJr + ' et ' + nbHours + ' ' + valueHour + ' restant'
        } else if (nbDays > 0 && nbHours == 0){
            return nbDays + ' ' + valueJr + ' restant'
        } else {
            return nbHours + ' ' + valueHour + ' restant'
        }
    } else {
        diff = diff * -1
        let nbDays = Math.floor(diff / 60 / 60 / 24)
        let nbHours = Math.floor(diff / 60 / 60 - nbDays * 24)
        let valueJr = 'jr'
        if(nbDays > 1) { valueJr = 'jrs' }
        let valueHour = 'hr'
        if(nbHours > 1) { valueHour = 'hrs' }
        if(nbDays > 0 && nbHours > 0){
            return 'Delai dépassé de ' + nbDays + ' ' + valueJr + ' et ' + nbHours + ' ' + valueHour
        } else if (nbDays > 0 && nbHours == 0){
            return 'Delai dépassé de ' + nbDays + ' ' + valueJr
        } else {
            return 'Delai dépassé de ' + nbHours + ' ' + valueHour
        }
    }
})

// Renvoi du pourcentage restant
let percentStep = Vue.filter('percentStep', function (value, date1, date2) {
    // Date actuel
    let now = Date.now()

    // Timestamp de la date de fin et la date du début
    let endTimeStamp = Date.parse(date1)
    let initTimeStamp = Date.parse(date2)

    // Calcul de la différence
    let total = Math.round((endTimeStamp - initTimeStamp) / 1000)
    let remaining = Math.round((endTimeStamp - now) / 1000)

    // Envoi du pourcentage restant
    return Math.round(100 - 100 / total * remaining)
})

// Nombre de jour d'une étape
let timeTotalStep = Vue.filter('timeTotalStep', function (value, date1, date2) {
    // Timestamp de la date de fin et la date du début
    let endTimeStamp = Date.parse(date1)
    let initTimeStamp = Date.parse(date2)

    // Envoi du pourcentage restant
    return Math.round((endTimeStamp - initTimeStamp) / 1000 / 60 / 60 / 24)
})

// Récupération de l'information de référence pour une clé
let getReferential = Vue.filter('getReferential', function (key, referential) {
    let values = false
    referential.forEach((item, i) => {
        if(item.id == key){
            values = item
        }
    })
    return values
})

let addressFormat = Vue.filter('addressFormat', function (address,type) {
    if(type == "type1"){
        if(address.type == 'housenumber'){
            return address.housenumber + ' ' + address.street + "<br>" + address.postcode + ' ' + address.city
        }
        else if(address.type == 'street' || address.type == 'locality'){
            return  address.name + '<br>' + address.postcode + ' ' + address.city
        }else{
            return address.city + ' ' + address.postcode
        }
    }else{
        if(address.type == 'housenumber'){
            return address.housenumber + ' ' + address.street + ' ' + address.postcode + ' ' + address.city
        }
        else if(address.type == 'street' || address.type == 'locality'){
            return  address.name + ' ' + address.postcode + ' ' + address.city
        }else{
            return address.city + ' ' + address.postcode
        }
    }

})



const newFilter = {
    dateFormat,
    formatPriceInteger,
    formatPriceFloat,
    pluralize,
    digit,
    dateCompareStep,
    percentStep,
    timeTotalStep,
    getReferential,
    addressFormat,
    formatIntegerMetrix
}

export default newFilter
