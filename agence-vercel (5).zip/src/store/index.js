import Vue from 'vue'
import Vuex from 'vuex'
import config from "../../src/utils/config";
import study from "src/store/modules/study";
import authentification from "src/store/modules/authentification";
import referential from "src/store/modules/referential";
import person from "src/store/modules/person";
import realEstateAgency from "src/store/modules/realEstateAgency";
// import example from './modules-example'

Vue.use(Vuex);

Vue.http.options.root = config.APILOCAL

Vue.http.interceptors.push((request, next) => {
  // console.log("Store/index.js::interceptor");
  if (localStorage.getItem('jwt')) {
    request.headers.set('Authorization', "bearer " + localStorage.jwt)
  }
  next((response) => {
    // test mauvais token ou token expiré ici
    //
    //     //let token = response.body.data.token
    //     //if ((response.headers.get('Authorization') != '') && (response.headers.get('Authorization') != undefined)) {
    //     //localStorage.setItem('jwt', auth)
    //     //localStorage.removeItem('auth_token');
    //     //router.push({ name: 'login'});
    //     //  }
  })
})
/*
 * If not building with SSR mode, you can
 * directly export the Store instantiation;
 *
 * The function below can be async too; either use
 * async/await or return a Promise which resolves
 * with the Store instance.
 */

export default new Vuex.Store({
  actions: {},
  getters: {},
  modules: {
    study,
    authentification,
    referential,
    person,
    realEstateAgency
  }

})
