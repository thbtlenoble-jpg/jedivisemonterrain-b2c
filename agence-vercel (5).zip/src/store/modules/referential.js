import VueResource from "vue-resource"
import Vue from 'vue'

const REFERENTIAL_URL = "referential"
const REFERENTIAL_VALUE_URL = "referentialValue"


Vue.use(VueResource);

const state = {
    values : {
        isReferentialLoading : false
    }
};

const getters = {
    referentialIsReferentialLoading : state => state.values.isReferentialLoading
};

const actions = {
    getReferentialValues({commit, state}, data) {
        commit('IS_REFERENTIAL_LOADING',true)
        return new Promise((resolve, reject) => {
            Vue.http.get(Vue.http.options.root + REFERENTIAL_URL  + '/' + data.referentialId + '/' + REFERENTIAL_VALUE_URL).then(response => {
                resolve(response)
                commit('IS_REFERENTIAL_LOADING',false)
            },response => {
                reject()})
                commit('IS_REFERENTIAL_LOADING',false)
        })
    }

};

const mutations = {
    'IS_REFERENTIAL_LOADING'(state,data){
        state.values.isReferentialLoading = data
    }
};

export default {
    state,
    getters,
    actions,
    mutations
}
