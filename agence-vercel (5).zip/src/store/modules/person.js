import VueResource from "vue-resource"
import Vue from 'vue'


const PERSONS_URL = "persons"
const EMAIL_URL = "email"


Vue.use(VueResource);

const state = {
    values : {
        isPersonLoading : false,
        isChangeRoute: false
    }
};

const getters = {
    personIsPersonLoading : state => state.values.isPersonLoading
};

const actions = {
    getPersonByEmail({commit,state},data){
        commit('LOAD_IS_PERSON_LOADING', true)
        return new Promise((resolve, reject) => {
            Vue.http.get(Vue.http.options.root + PERSONS_URL + '/' + EMAIL_URL + '/' + data.email).then(response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                resolve(response)
            }, response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                reject(response)
            })
        })
    },
    updatePersonByPersonId({commit,state},data){
        commit('LOAD_IS_PERSON_LOADING', true)
        return new Promise((resolve, reject) => {
            Vue.http.put(Vue.http.options.root + PERSONS_URL + '/'+ data.person.id, data.person).then(response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                resolve(response)
            }, response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                reject(response)
            })
        })
    },
    getPersonById({commit,state},data){
        commit('LOAD_IS_PERSON_LOADING', true)
        return new Promise((resolve, reject) => {
            Vue.http.get(Vue.http.options.root + PERSONS_URL + '/' + data.personId).then(response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                resolve(response)
            }, response => {
                commit('LOAD_IS_PERSON_LOADING', false)
                reject(response)
            })
        })
    }

};

const mutations = {
    LOAD_IS_PERSON_LOADING(state,data){
        state.values.isPersonLoading = data
    }
};

export default {
    state,
    getters,
    actions,
    mutations
}
