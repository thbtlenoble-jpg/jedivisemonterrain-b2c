import VueResource from "vue-resource"
import Vue from 'vue'


const REA_URL = "realEstateAgencies"



Vue.use(VueResource);

const state = {
    values : {
        isReaLoading : false,
    }
};

const getters = {
    realEstateAgencyIsReaLoading : state => state.values.isReaLoading
};

const actions = {
    getOneRealEstateAgencyById({commit,state},data){
        commit('LOAD_IS_REA_LOADING', true)
        console.log(data.reaId)
        return new Promise((resolve, reject) => {
            Vue.http.get(Vue.http.options.root + REA_URL + '/' + data.reaId ).then(response => {
                commit('LOAD_IS_REA_LOADING', false)
                resolve(response)
            }, response => {
                commit('LOAD_IS_REA_LOADING', false)
                reject(response)
            })
        })
    }
};

const mutations = {
    LOAD_IS_REA_LOADING(state,data){
        state.values.isReaLoading = data
    }
};

export default {
    state,
    getters,
    actions,
    mutations
}
