import VueResource from "vue-resource";
import Vue from "vue";

import config from "../../Utils/config.js"
const SERVER_URL = config.API;
const PLOTS_URL = "plots";
const SEARCH_URL = "search";
const COORDINATES_URL = "coordinates";
const COMMUNE_URL = "commune=";
const SECTION_URL = "section=";
const NUMERO_URL = "numero=";
const LAT_URL = "lat=";
const LON_URL = "lon=";
const PROJECTS_URL = "projects";
const ADDRESS_URL = "address";
const NEW_URL = "new";
const GOOD_PROPERTIES_URL = "goodProperties";
const SALE_PROPERTIES_URL = "saleProperties";
const EXISTING_BUILDING_PROPERTY_URL = "existingBuildingProperties";
const PROJECT_CLUSTER_URL = "projectCluster";
const NOTARIES_URL = "notaries";
const PERSONS_URL = "persons";
const EMAIL_URL = "email";
const SECTOR_URL = "sectors";
const MARKET_URL = "markets";
const PROGRAMS_URL = "programs";
const PERSON_ID_URL = "personId";
const PARTNER_TYPE_URL = "partnerType";
const OFFSET_URL = "offset=";
const LIMIT_URL = "limit=";
const PROJECTS_PERSONS_URL = "projectsPersons";
const FILES_URL = "files"
const TYPES_URL = "types"
Vue.use(VueResource);

const state = {
    values: {
        plots: {},
        isPlotsLoaded: false,
        plotsSelected: [],
        projectCluster: {},
        projectsCluster: {},
        isProjectsClusterLoaded: false,
        steps: [
            {
                name: "Initialisation",
                icon: "fal fa-traffic-cone",
            },
            {
                name: "Constructibilité",
                icon: "fal fa-digging",
            },
            {
                name: "Prestataires",
                icon: "fal fa-users",
            },
            {
                name: "Informations étude",
                icon: "fal fa-info-square",
            },
            {
                name: "Capacité",
                icon: "fal fa-layer-group",
            },
            {
                name: "Estimation des lots",
                icon: "fal fa-coins",
            },
            {
                name: "Bilans",
                icon: "fal fa-file-alt",
            },
            {
                name: "Validation du bilan",
                icon: "fal fa-check",
            },
            {
                name: "Dossier de valorisation",
                icon: "fal fa-folder-open",
            },
            {
                name: "Contrat",
                icon: "fal fa-file-contract",
            },
        ],
        builder: {
            name: "Unik'Home",
            offers: [
                {
                    id: 1,
                    type: 1, // Id du référentiel
                    picture:
                        "https://storage.gra.cloud.ovh.net/v1/AUTH_e0b83750570d4ff1986fe199b41300e4/kimono/fc146b18558bd5c1687822a1844619a77faf9ff4/600x370-fit-cover-orientation-0deg?width=600&height=370&fit=cover",
                    price: "1350",
                },
                {
                    id: 2,
                    type: 2, // Id du référentiel
                    picture:
                        "https://www.genio.cc/images/ARTICLES/FEVRIER_2018/ID34/Pod-Space-lead-889x636-min.jpg",
                    price: "1540",
                },
                {
                    id: 3,
                    type: 3, // Id du référentiel
                    picture:
                        "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                    price: "1760",
                },
                {
                    id: 4,
                    type: 4, // Id du référentiel
                    picture:
                        "https://photo.barnes-international.com/annonces/bms/119/min/13382165265d1f0b2a507572.33948755_43fffe3bc2_1920.jpg",
                    price: "1940",
                },
            ],
        },
        country: [
            {
                id: 1,
                name: "France",
                iso: "FR",
            },
            {
                id: 2,
                name: "Italie",
                iso: "IT",
            },
            {
                id: 3,
                name: "Royaume-Uni",
                iso: "UK",
            },
        ],
        referential: [
            {
                id: 1,
                value: "Entrée de gamme",
                type: "construct",
            },
            {
                id: 2,
                value: "Moyenne gamme",
                type: "construct",
            },
            {
                id: 3,
                value: "Gamme supérieure",
                type: "construct",
            },
            {
                id: 4,
                value: "Haut de gamme",
                type: "construct",
            },
            {
                id: 5,
                value: "Urbain <span>(immeuble)</span>",
                type: "sector",
            },
            {
                id: 6,
                value: "Mixte Urbain <span>(immeuble + maison)</span>",
                type: "sector",
            },
            {
                id: 7,
                value: "Pavillonnaire dense",
                type: "sector",
            },
            {
                id: 8,
                value: "Pavillonaire",
                type: "sector",
            },
            {
                id: 9,
                value: "Urbain",
                type: "market",
            },
            {
                id: 10,
                value: "Périurbain",
                type: "market",
            },
            {
                id: 11,
                value: "Pavillonnaire",
                type: "market",
            },
            {
                id: 12,
                value: "Rurale",
                type: "market",
            },
            {
                id: 13,
                value: "Terrain",
                type: "typeGood",
            },
            {
                id: 14,
                value: "Terrain + maison",
                type: "typeGood",
            },
            {
                id: 15,
                value: "Résidence principale",
                type: "usage",
            },
            {
                id: 16,
                value: "Résidence secondaire",
                type: "usage",
            },
            {
                id: 17,
                value: "Plat",
                type: "topographie",
            },
            {
                id: 18,
                value: "Moyennement plat",
                type: "topographie",
            },
            {
                id: 19,
                value: "Pentu",
                type: "topographie",
            },
            {
                id: 20,
                value: "Neuf",
                type: "etatExistant",
            },
            {
                id: 21,
                value: "A rafraichir",
                type: "etatExistant",
            },
            {
                id: 22,
                value: "Grange",
                type: "etatExistant",
            },
            {
                id: 23,
                value: "Classique",
                type: "typePrestation",
            },
            {
                id: 24,
                value: "Moyenne gamme",
                type: "typePrestation",
            },
            {
                id: 25,
                value: "Luxe",
                type: "typePrestation",
            },
            {
                id: 26,
                value: "Particulier",
                type: "statut",
            },
            {
                id: 27,
                value: "Professionnel",
                type: "statut",
            },
            {
                id: 28,
                value: "SCI",
                type: "societyType",
            },
            {
                id: 29,
                value: "SARL",
                type: "societyType",
            },
            {
                id: 30,
                value: "Célibataire",
                type: "civil",
            },
            {
                id: 31,
                value: "Pacsé",
                type: "civil",
            },
            {
                id: 32,
                value: "Marié",
                type: "civil",
            },
            {
                id: 33,
                value: "M",
                type: "gender",
            },
            {
                id: 34,
                value: "Mme",
                type: "gender",
            },
            {
                id: 35,
                value: "Le régime de la communauté",
                type: "regime",
            },
            {
                id: 36,
                value: "La communauté universelle",
                type: "regime",
            },
        ],
        testStudies: [
            {
                id: 9,
                buildability: {
                    state: true,
                    zone: "UA",
                    type: [
                        {
                            name: "Division",
                            state: true,
                        },
                        {
                            name: "Lotisseur",
                            state: false,
                        },
                        {
                            name: "Promoteur",
                            state: true,
                        },
                    ],
                },
                steps: [
                    {
                        nb: 1,
                        actors: [
                            {
                                name: "JDMT",
                                type: "jdmt",
                                color: "#00B9B4",
                            },
                            {
                                name: "Relaximmo",
                                type: "agency",
                                color: "#E85D00",
                            },
                        ],
                        myActions: [
                            {
                                name: "Initialisation d'une étude",
                                state: "lock",
                            },
                        ],
                        theirActions: [
                            {
                                name: "Construction du dossier auprès de JDMT",
                                state: "lock",
                            },
                        ],
                        name: "Initialisation",
                        creation: "2020-05-10T22:00:00.277Z",
                        end: "2020-05-16T22:00:00.277Z",
                    },
                    {
                        nb: 2,
                        actors: [
                            {
                                name: "Géhome",
                                type: "geometer",
                                color: "#9D68D9",
                            },
                        ],
                        myActions: [],
                        theirActions: [
                            {
                                name: "Validation de la constructibilité",
                                state: "lock",
                            },
                        ],
                        name: "Constructibilité",
                        creation: "2020-05-10T22:00:00.277Z",
                        end: "2020-05-16T22:00:00.277Z",
                    },
                    {
                        nb: 3,
                        actors: [
                            {
                                name: "JDMT",
                                type: "jdmt",
                                color: "#00B9B4",
                            },
                        ],
                        myActions: [],
                        theirActions: [
                            {
                                name: "Sélection des partenaires par JDMT",
                                state: "lock",
                            },
                        ],
                        name: "Prestataires",
                        creation: "2020-05-10T22:00:00.277Z",
                        end: "2020-05-16T22:00:00.277Z",
                    },
                    {
                        nb: 4,
                        actors: [
                            {
                                name: "Géomètre",
                                type: "geometer",
                                color: "#9D68D9",
                            },
                            {
                                name: "Agence Immobilière",
                                type: "agency",
                                color: "#E85D00",
                            },
                        ],
                        myActions: [
                            {
                                name: "Informations secteur",
                                type: "sector",
                                state: "init",
                                values: {
                                    sector: null, // Id du référentiel
                                },
                            },
                            {
                                name: "Données marché",
                                type: "market",
                                state: "init",
                                values: {
                                    market: 11, // Id du référentiel
                                    construct: null, // Id du référentiel
                                },
                            },
                            {
                                name: "Programme",
                                type: "programme",
                                state: "init",
                                values: {
                                    habitability: {
                                        min: null,
                                        max: null,
                                    },
                                    garage: {
                                        min: null,
                                        max: null,
                                    },
                                    terrain: {
                                        min: 500,
                                        max: 1000,
                                    },
                                    salePriceMedium: "",
                                },
                            },
                            {
                                name: "Documents",
                                type: "files",
                                state: "init",
                                values: {
                                    properties: [
                                        {
                                            id: 1,
                                            type: "pdf",
                                            name: "titre-de-propriété.pdf",
                                            url: "TOTO",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                        {
                                            id: 2,
                                            type: "pdf",
                                            name: "suite.pdf",
                                            url: "TOTO",
                                            creation:
                                                "2020-05-22T15:30:45.277Z",
                                        },
                                    ],
                                    servitude: null,
                                    etudesSols: [],
                                    pictures: [
                                        {
                                            id: 1,
                                            url:
                                                "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                        {
                                            id: 2,
                                            url:
                                                "https://photo.barnes-international.com/annonces/bms/119/min/13382165265d1f0b2a507572.33948755_43fffe3bc2_1920.jpg",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                        {
                                            id: 3,
                                            url:
                                                "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                        {
                                            id: 4,
                                            url:
                                                "https://photo.barnes-international.com/annonces/bms/119/min/13382165265d1f0b2a507572.33948755_43fffe3bc2_1920.jpg",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                    ],
                                    others: [
                                        {
                                            id: 1,
                                            type: "img",
                                            name: "CI-RV-Proprietaire.jpg",
                                            url: "Yepa !",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                        {
                                            id: 2,
                                            type: "doc",
                                            name: "nos-envies.doc",
                                            url: "Gloups !",
                                            creation:
                                                "2020-05-20T15:30:45.277Z",
                                        },
                                    ],
                                },
                            },
                            {
                                name: "Propriétaire",
                                type: "owners",
                                state: "init",
                                values: {
                                    owners: [
                                        {
                                            id: 1,
                                            mail: "lotito.stephane@gmail.com",
                                            gender: 33,
                                            nationality: 1,
                                            firstname: "Stéphane",
                                            lastname: "LOTITO",
                                            birthday: "1986-12-11",
                                            job: "UX Designer",
                                            civil: 31,
                                            phone: "0123456789",
                                            dateMariage: null,
                                            regime: null,
                                            dateContract: null,
                                            recuPar: "",
                                            identity: [
                                                {
                                                    type: "recto",
                                                    url:
                                                        "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                                                    creation:
                                                        "2020-05-20T22:00:00.277Z",
                                                },
                                                {
                                                    type: "verso",
                                                    url:
                                                        "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                                                    creation:
                                                        "2020-05-20T22:00:00.277Z",
                                                },
                                            ],
                                            address: {
                                                id: 1,
                                                creation:
                                                    "2020-05-06T13:43:00.596Z",
                                                modification:
                                                    "2020-05-06T13:43:00.596Z",
                                                housenumber: "16",
                                                street: "Rue de la ganterie",
                                                postcode: "38760",
                                                city: "Varces-Allières-Risset",
                                            },
                                        },
                                        {
                                            id: 2,
                                            mail: "lotito.stephane@gmail.com",
                                            gender: 34,
                                            nationality: 2,
                                            firstname: "Ginette",
                                            lastname: "LOTITO",
                                            birthday: "1986-12-11",
                                            job: "UX Designer",
                                            civil: 31,
                                            phone: "0123456789",
                                            dateMariage: null,
                                            regime: null,
                                            dateContract: null,
                                            recuPar: "",
                                            identity: [
                                                {
                                                    type: "recto",
                                                    url:
                                                        "https://www.depreux-construction.com/wp-content/uploads/2018/11/depreux-construction.jpg",
                                                    creation:
                                                        "2020-05-20T22:00:00.277Z",
                                                },
                                                {
                                                    type: "verso",
                                                    url: "",
                                                    creation: "",
                                                },
                                            ],
                                            address: {
                                                id: 1,
                                                creation:
                                                    "2020-05-06T13:43:00.596Z",
                                                modification:
                                                    "2020-05-06T13:43:00.596Z",
                                                housenumber: "16",
                                                street: "Rue de la ganterie",
                                                postcode: "38760",
                                                city: "Varces-Allières-Risset",
                                            },
                                        },
                                    ],
                                },
                            },
                            {
                                name: "Notaire",
                                type: "notary",
                                state: "init",
                                values: {
                                    firstname: "",
                                    lastname: "",
                                    phone: "",
                                    mail: "",
                                    address: {
                                        id: 2,
                                        creation: "2020-05-06T13:43:00.596Z",
                                        modification:
                                            "2020-05-06T13:43:00.596Z",
                                        housenumber: "27",
                                        street: "Avenue de l'arnaque",
                                        postcode: "38000",
                                        city: "Grenoble",
                                    },
                                },
                            },
                            {
                                name: "Informations sur le bien",
                                type: "goodInformation",
                                state: "init",
                                values: {
                                    typeGood: 14,
                                    lotissement: false,
                                    usage: null,
                                    dateAchat: "2009-05-03T18:48:47.277Z",
                                    dateSuccession: null,
                                    dateDonation: null,
                                    datePartage: null,
                                    dateDroitRetour: null,
                                    topographie: 18,
                                    servitude: null,
                                    indivision: null,
                                    bati: true,
                                    datePermis: "2009-10-03T18:48:47.277Z",
                                    nbrPermis: "",
                                    SurfaceConcerne: 151.5,
                                    SurfaceTotal: 153.1,
                                    SurfaceUtile: 149.5,
                                    SurfaceHabitable: 149.5,
                                    SurfaceCarrez: 142.47,
                                    SurfaceGarage: 18.3,
                                    mitoyen: false,
                                    nbrMitoyen: "",
                                    cloture: false,
                                    stateCloture: "",
                                    visavis: true,
                                    moreVisavis: "Plutôt proche",
                                    ensoleillement: "Fort",
                                    exposition: "Plein sud",
                                    etatExistant: null,
                                    typePrestation: null,
                                    yearConstruct: "",
                                    yearRebuild: "",
                                    demembrement: false,
                                    usufruitier: "",
                                    nuePropriete: "",
                                    division: "",
                                    nbrOwners: "",
                                },
                            },
                            {
                                name: "Informations sur la vente",
                                type: "salesInformation",
                                state: "init",
                                values: {
                                    misEnVente: true,
                                    quand: null,
                                    price: "359000",
                                    estimate: "349000",
                                    result: "Quelques visites",
                                    statut: null,
                                    societyType: null,
                                },
                            },
                        ],
                        theirActions: [
                            {
                                name: "Terrain et environnement",
                                state: "lock",

                            },
                        ],
                        name: "Informations étude",
                        creation: "2020-05-20T22:00:00.277Z",
                        end: "2020-05-26T22:00:00.277Z",
                    },
                   {
                        nb: 6,
                        actors: [
                            {
                                name: "Géhome",
                                type: "geometer",
                                color: "#9D68D9",
                            },
                            {
                                name: "Relaximmo",
                                type: "agency",
                                color: "#E85D00",
                            },
                        ],
                        myActions: [
                            {
                                name: "Estimations des lots en divison et lotissement",
                                state: "init",
                                type : "plotsEstimation",
                                values : {
                                    blocEstimation : {
                                        urlImage : '../../../statics/testImage/planEstimation.jpg',
                                        estimations:[
                                             {
                                                label : "Estimation 1",
                                                value : 100000
                                            },
                                        ]

                                    },
                                    plotsDivisionEstimation : {
                                        urlImage : '../../../statics/testImage/planEstimation.jpg',
                                        estimations:[
                                            {
                                                label: "Estimation 1",
                                                value : 10000000
                                            },
                                            {
                                                label :"Estimation 2",
                                                value : 100000
                                            },
                                            {
                                                label : "Estimation 3",
                                                value : 10000
                                            }]

                                    },
                                    allotmentEstimation : {
                                        urlImage : '../../../statics/testImage/planEstimation.jpg',
                                        estimations:[
                                            {
                                                label: "Estimation 1",
                                                value : 100000
                                            },
                                            {
                                                label :"Estimation 2",
                                                value : 150000
                                            },
                                            {
                                                label : "Estimation 3",
                                                value : 50000
                                            },
                                            ]
                                        }
                                    }

                            },
                        ],
                        theirActions: [
                            {
                                name: "Estimations des lots en promotion",
                                state: "lock",
                            },
                        ],
                        name: "Estimations des lots",
                        creation: "2020-05-10T22:00:00.277Z",
                        end: "2020-05-16T22:00:00.277Z",
                    },
                    // {
                    //                     //     nb: 6,
                    //                     //     actors: [
                    //                     //         {
                    //                     //             name: "Géhome",
                    //                     //             type: "geometer",
                    //                     //             color: "#9D68D9",
                    //                     //         },
                    //                     //     ],
                    //                     //     myActions: [
                    //                     //         {
                    //                     //             name: "Validation de la constructibilité",
                    //                     //             state: "init",
                    //                     //             type : "constructibility",
                    //                     //             values : {
                    //                     //                 isBuildable : false,
                    //                     //                 urbanismPlanningZone : null,
                    //                     //                 riskArea : null,
                    //                     //                 commentaryArea : '',
                    //                     //                 type: [
                    //                     //                     {
                    //                     //                         name: "Vente en division",
                    //                     //                         state: true,
                    //                     //                     },
                    //                     //                     {
                    //                     //                         name: "Vente en lotisseur",
                    //                     //                         state: null,
                    //                     //                     },
                    //                     //                     {
                    //                     //                         name: "Vente en promotion",
                    //                     //                         state: false,
                    //                     //                     },
                    //                     //                 ],
                    //                     //             }
                    //                     //
                    //                     //         },
                    //                     //     ],
                    //                     //     theirActions: [
                    //                     //     ],
                    //                     //     name: "Constructibilité",
                    //                     //     creation: "2020-05-10T22:00:00.277Z",
                    //                     //     end: "2020-05-16T22:00:00.277Z",
                    //                     // },
                ],


                address: {
                    id: 1,
                    creation: "2020-05-06T13:43:00.596Z",
                    modification: "2020-05-06T13:43:00.596Z",
                    housenumber: "16",
                    street: "Rue de la ganterie",
                    postcode: "38760",
                    city: "Varces-Allières-Risset",
                },
                plots: [
                    {
                        cadastralId: "31555822AB0715",
                        commune: 31555,
                        contenance: "5166",
                        creation: "2020-05-06T13:43:00.609Z",
                        geometry: {
                            coordinates: [
                                [
                                    [5.6825906, 45.0957613],
                                    [5.6827931, 45.0956502],
                                    [5.682966, 45.0956951],
                                    [5.6830945, 45.0956567],
                                    [5.6833019, 45.0957279],
                                    [5.6835188, 45.0957097],
                                    [5.6835224, 45.0958436],
                                    [5.6834908, 45.0960404],
                                    [5.6834878, 45.0960412],
                                    [5.6834836, 45.0960422],
                                    [5.6834802, 45.0960429],
                                    [5.6834765, 45.0960436],
                                    [5.6834713, 45.0960443],
                                    [5.6834651, 45.0960447],
                                    [5.683462, 45.0960448],
                                    [5.6831419, 45.0960489],
                                    [5.6825222, 45.0962274],
                                    [5.6825107, 45.0962299],
                                    [5.6824988, 45.0962311],
                                    [5.6824868, 45.0962311],
                                    [5.682475, 45.0962297],
                                    [5.6824636, 45.096227],
                                    [5.682453, 45.0962231],
                                    [5.6824435, 45.096218],
                                    [5.682435, 45.0962119],
                                    [5.6824281, 45.0962051],
                                    [5.6824228, 45.0961974],
                                    [5.6823323, 45.0960366],
                                    [5.6823101, 45.0959272],
                                    [5.6823954, 45.0958943],
                                    [5.6824573, 45.0957766],
                                    [5.6825906, 45.0957613],
                                ],
                            ],
                            type: "Polygon",
                        },
                        id: 1,
                        lat: 44,
                        lon: 1,
                        modification: "2020-05-06T13:43:00.609Z",
                        numero: 715,
                        section: "822 AB",
                    },
                ],
            },
            {
                id: 18,
                steps: [
                    {
                        nb: 1,
                        actors: [
                            {
                                name: "JDMT",
                                type: "jdmt",
                                color: "#00B9B4",
                            },
                            {
                                name: "Relaximmo",
                                type: "agency",
                                color: "#E85D00",
                            },
                        ],
                        myActions: [
                            {
                                name: "Initialisation d'une étude",
                                state: "lock",
                            },
                        ],
                        theirActions: [
                            {
                                name: "Construction du dosser auprès de JDMT",
                                state: "lock",
                            },
                        ],
                        name: "Initialisation",
                        creation: "2020-05-12T22:00:00.277Z",
                        end: "2020-05-14T22:00:00.277Z",
                    },
                ],
                address: {
                    id: 1,
                    creation: "2020-05-06T13:43:00.596Z",
                    modification: "2020-05-06T13:43:00.596Z",
                    housenumber: "8",
                    street: "Allée de la veissière",
                    postcode: "38640",
                    city: "Claix",
                },
            },
            {
                id: 258,
                steps: [
                    {
                        nb: 1,
                        actors: [
                            {
                                name: "JDMT",
                                type: "jdmt",
                                color: "#00B9B4",
                            },
                            {
                                name: "Relaximmo",
                                type: "agency",
                                color: "#E85D00",
                            },
                        ],
                        myActions: [
                            {
                                name: "Initialisation d'une étude",
                                state: "lock",
                            },
                        ],
                        theirActions: [
                            {
                                name: "Construction du dosser auprès de JDMT",
                                state: "lock",
                            },
                        ],
                        name: "Initialisation",
                        creation: "2020-05-10T22:00:00.277Z",
                        end: "2020-05-16T22:00:00.277Z",
                    },
                    {
                        nb: 2,
                        actors: [
                            {
                                name: "Géhome",
                                type: "geometer",
                                color: "#9D68D9",
                            },
                        ],
                        myActions: [],
                        theirActions: [
                            {
                                name: "Validation de la constructibilité",
                                state: "lock",
                            },
                        ],
                        name: "Constructibilité",
                        creation: "2020-05-12T22:00:00.277Z",
                        end: "2020-05-17T22:00:00.277Z",
                    },
                ],
                address: {
                    id: 1,
                    creation: "2020-05-06T13:43:00.596Z",
                    modification: "2020-05-06T13:43:00.596Z",
                    housenumber: "27",
                    street: "Avenue Gambetta",
                    postcode: "38000",
                    city: "Grenoble",
                },
            },
        ],
    },
};

const getters = {
    projectPlots: (state) => state.values.plots,
    projectIsPlotsLoaded: (state) => state.values.isPlotsLoaded,
    projectPlotsSelected: (state) => state.values.plotsSelected,
    projectProjectCluster: (state) => state.values.projectCluster,
    projectProjectsCluster: (state) => state.values.projectsCluster,
    projectIsProjectsClusterLoaded: (state) =>
        state.values.isProjectsClusterLoaded,
    projectSteps: (state) => state.values.steps,
    projectBuilder: (state) => state.values.builder,
    projectReferential: (state) => state.values.referential,
    projectCountry: (state) => state.values.country,
    projectTestStudies: (state) => state.values.testStudies,
};

const actions = {

    //<editor-fold desc="loadInforamtions">
    loadPlots({ commit, state }, data) {
            commit("LOAD_IS_PLOTS_LOADED", true);
            return new Promise((resolve, reject) => {
                Vue.http
                    .get(
                        Vue.http.options.root +
                            PLOTS_URL +
                            "/" +
                            SEARCH_URL +
                            "?" +
                            LAT_URL +
                            data.lat +
                            "&" +
                            LON_URL +
                            data.lon +
                            "&distance=300m" +
                            "&size=1000"
                    )
                    .then(
                        (response) => {
                            commit("LOAD_PLOTS", response.body);
                            commit("LOAD_IS_PLOTS_LOADED", false);
                            resolve(response);
                        },
                        (response) => {
                            commit("LOAD_IS_PLOTS_LOADED", false);
                            reject(response);
                        }
                    );
            });
        },

        loadPlotsByPlotInfo({ commit, state }, data) {
            commit("LOAD_IS_PLOTS_LOADED", true);
            return new Promise((resolve, reject) => {
                Vue.http
                    .get(
                        Vue.http.options.root +
                            PLOTS_URL +
                            "/" +
                            COORDINATES_URL +
                            "?" +
                            COMMUNE_URL +
                            data.commune +
                            "&" +
                            SECTION_URL +
                            data.section +
                            "&" +
                            NUMERO_URL +
                            data.numero
                    )
                    .then(
                        (response) => {
                            commit("LOAD_IS_PLOTS_LOADED", false);
                            resolve(response);
                        },
                        (response) => {
                            commit("LOAD_IS_PLOTS_LOADED", false);
                            reject(response);
                        }
                    );
            });
        },

        loadProjectsCluster({ commit, state }, data) {
            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
            let urlRelation = "";
            data.options.relations.forEach((element) => {
                urlRelation = urlRelation + "&relations=" + element;
            });
            return new Promise((resolve, reject) => {
                Vue.http
                    .get(
                        Vue.http.options.root +
                            PROJECTS_URL +
                            "?" +
                            OFFSET_URL +
                            data.options.offset +
                            "&" +
                            LIMIT_URL +
                            data.options.limit +
                            '&' +
                            SEARCH_URL + '=' +
                            data.options.search +
                            urlRelation
                    )
                    .then(
                        (response) => {
                            commit("LOAD_PROJECTS_CLUSTER", response.body);
                            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                            resolve(response);
                        },
                        (response) => {
                            reject(response);
                            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        }
                    );
            });
        },

        loadProjectCluster({ commit, state }, data) {
            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
            let urlRelation = "";
            let count = 0;
            data.relations.forEach((element) => {
                if (count == 0) {
                    urlRelation = urlRelation + "?relations=" + element;
                } else {
                    urlRelation = urlRelation + "&relations=" + element;
                }
                count = count + 1;
            });
            return new Promise((resolve, reject) => {
                Vue.http
                    .get(
                        Vue.http.options.root +
                            PROJECTS_URL +
                            "/" +
                            data.projectId +
                            urlRelation
                    )
                    .then(
                        (response) => {
                            commit("LOAD_PROJECT_CLUSTER", response.body);
                            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                            resolve(response);
                        },
                        (response) => {
                            reject(response);
                            commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        }
                    );
            });
        },
    //</editor-fold>

    //<editor-fold desc="Initialisation">
    createProject({ commit, state }) {
        return new Promise((resolve, reject) => {
            Vue.http.post(Vue.http.options.root + PROJECTS_URL).then(
                (response) => {
                    commit("LOAD_PROJECT", response.body);
                    resolve(response);
                },
                (response) => {
                    reject(response);
                }
            );
        });
    },

    addPlotsToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        PLOTS_URL,
                    data.plots
                )
                .then(
                    (response) => {
                        commit("LOAD_PROJECT", response.body);
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (error) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(error);
                    }
                );
        });
    },

    addAddressToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        ADDRESS_URL,
                    data.address
                )
                .then(
                    (response) => {
                        commit("LOAD_PROJECT", response.body);
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="GoodProperty">
    getGoodPropertyByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        GOOD_PROPERTIES_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    addOrUpdateGoodPropertyToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        GOOD_PROPERTIES_URL,
                    data.goodProperty
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="ExistingBuildingProperty">
    getExistingBuildingPropertyByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        EXISTING_BUILDING_PROPERTY_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    addOrCreateExistingBuildingPropertyToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        EXISTING_BUILDING_PROPERTY_URL,
                    data.existingBuildingProperty
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="SaleProperty">
    getSalePropertyByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        SALE_PROPERTIES_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    addOrUpdateSalePropertyToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        SALE_PROPERTIES_URL,
                    data.saleProperty
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="Notary">
    addOrUpdateNotaryToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        NOTARIES_URL,
                    data.notary
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    getNotaryByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        NOTARIES_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="Sector">
    getSectorByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    SECTOR_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    createOrUpdateSectorByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    SECTOR_URL,
                    data.sector
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="Market">
    getMarketByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    MARKET_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    createOrUpdateMarketByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    MARKET_URL,
                    data.market
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="Program">
    getProgrammByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    PROGRAMS_URL
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    createOrUpdateProgrammByProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    PROGRAMS_URL,
                    data.programm
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="projectPersons">
    getPersonsByProjectIdAndPartnersType({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        PERSONS_URL +
                        "/" +
                        PARTNER_TYPE_URL +
                        "/" +
                        data.partnerType
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    createAndAddPersonToProject({ commit, sate }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        PERSONS_URL,
                    data.body
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    getProjectPersonByPersonIdAndProjectId({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        PERSONS_URL +
                        "/" +
                        data.personId
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },


    attachPersonToProject({ commit, state }, data) {
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                        PROJECTS_URL +
                        "/" +
                        data.projectId +
                        "/" +
                        PERSONS_URL +
                        "/" +
                        data.personId,
                    { partnerType: data.partnerType }
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    deleteProjectPerson({commit,state},data){
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .delete(
                    Vue.http.options.root +
                    PROJECTS_PERSONS_URL +
                    "/" +
                    data.projectsPersonsId
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },
    //</editor-fold>

    //<editor-fold desc="File">
    uploadFileToProject({commit,state},data){
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .post(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    FILES_URL,
                    data.fd,
                    {'Content-Type' : 'multipart/form-data' }
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    getProjectFiles({commit,state},data){
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .get(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    FILES_URL +
                    "?" +
                    TYPES_URL +
                    "=" +
                    data.type
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    },

    deleteFileToProject({commit , state},data){
        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", true);
        return new Promise((resolve, reject) => {
            Vue.http
                .delete(
                    Vue.http.options.root +
                    PROJECTS_URL +
                    "/" +
                    data.projectId +
                    "/" +
                    FILES_URL +
                    "/" +
                    data.fileId
                )
                .then(
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        resolve(response);
                    },
                    (response) => {
                        commit("LOAD_IS_PROJECTS_CLUSTER_LOADED", false);
                        reject(response);
                    }
                );
        });
    }
    //</editor-fold>
};

const mutations = {
    LOAD_PLOTS(state, data) {
        state.values.plots = data;
    },
    LOAD_IS_OWNER_LOADED(state, data) {
        state.values.isOwnerLoaded = data;
    },
    LOAD_PROJECT(state, data) {
        state.values.projectCluster = data;
    },
    LOAD_PROJECTS_CLUSTER(state, data) {
        state.values.projectsCluster = data;
    },
    LOAD_PROJECT_CLUSTER(state, data) {
        state.values.projectCluster = data;
    },
    LOAD_IS_PLOTS_LOADED(sate, data) {
        state.values.isPlotsLoaded = data;
    },
    LOAD_IS_PROJECTS_CLUSTER_LOADED(sate, data) {
        state.values.isProjectsClusterLoaded = data;
    },
};

export default {
    state,
    getters,
    actions,
    mutations,
};
