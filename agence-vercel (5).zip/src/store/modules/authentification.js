import VueResource from "vue-resource"
import Vue from 'vue'

const AUTH_URL = "auth"
const LOGIN_URL = "login"
const TOKEN_URL = "token"
const PASSWORD_URL = "password"
const RESET_URL = "reset"
const CHECKCODE_URL = "checkCode"
const CHANGE_URL = "change"

Vue.use(VueResource);

const state = {
    values : {
        isLoginLoading : false,
        isChangeRoute: false
    }
};

const getters = {
  authentificationIsLoginLoading : state => state.values.isLoginLoading,
  authentificationIsChangeRoute : state => state.values.isChangeRoute
};

const actions = {
  login({commit, state}, data) {
    commit('LOAD_IS_LOGIN_LOADING',true)
    return new Promise((resolve, reject) => {
       Vue.http.post(Vue.http.options.root + AUTH_URL + '/' + LOGIN_URL, {
        'email': data.mail,
        'password': data.password
      }).then(response => {
          resolve(response)
      },response => {
         commit('LOAD_IS_LOGIN_LOADING',false)
         reject()})
    })
  },
  getProfile({commit, state}) {
    return new Promise((resolve, reject) => {
      Vue.http.get(Vue.http.options.root + AUTH_URL + '/'+ TOKEN_URL ).then(response => {
          resolve(response)
      })
    })
  },
    getResetPassword({commit,state},data){
        commit('LOAD_IS_LOGIN_LOADING',true)
        return new Promise((resolve, reject) => {
            Vue.http.post(Vue.http.options.root + AUTH_URL + '/' + PASSWORD_URL+ '/' + RESET_URL, {
                'email': data.mail,
            }).then(response => {
                resolve(response)
                commit('LOAD_IS_LOGIN_LOADING',false)
            }, error => {
                reject(error)
                commit('LOAD_IS_LOGIN_LOADING',false)
            })
        })
    },
  checkCodeValid({commit,state},data){
    commit('LOAD_IS_LOGIN_LOADING',true)
    return new Promise((resolve, reject) => {
      Vue.http.get(Vue.http.options.root + AUTH_URL + '/' + PASSWORD_URL+ '/' + CHECKCODE_URL + "/" + data.code).then(response => {
        resolve(response)
        commit('LOAD_IS_LOGIN_LOADING',false)
      },response => {
        reject()})
        commit('LOAD_IS_LOGIN_LOADING',false)
    })
  },
  changePassword({commit,state},data){
    commit('LOAD_IS_LOGIN_LOADING',true)
    return new Promise((resolve, reject) => {
      Vue.http.post(Vue.http.options.root + AUTH_URL + '/' + PASSWORD_URL+ '/' + CHANGE_URL, {
        "code" : data.code,
        'password': data.password,
      }).then(response => {
        resolve(response)
        commit('LOAD_IS_LOGIN_LOADING',false)
      },response => {
        reject()
        commit('LOAD_IS_LOGIN_LOADING',false)
      })
    })
  },

};

const mutations = {
  LOAD_IS_LOGIN_LOADING(state,data){
    state.values.isLoginLoading = data
  }
};

export default {
  state,
  getters,
  actions,
  mutations
}
