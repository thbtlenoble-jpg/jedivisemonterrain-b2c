<template>
    <div id="q-app">
        <q-inner-loading :showing="authentificationIsChangeRoute">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <component :is="layout">
            <router-view @send-notity="notifyFn" />
        </component>
    </div>
</template>

<script>

    import Vuex from "vuex";
    import Store from "./store/index.js";
    const default_layout = "Default";

    export default {
        name: 'App',
        computed:{
            ...Vuex.mapGetters([
                'authentificationIsChangeRoute'
            ]),
            layout(){
                return (this.$route.meta.layout || default_layout) + '-layout';
            }
        },
        methods: {
            notifyFn(e){
                if(e[0] == 'positive'){
                    this.$q.notify({
                        type: e[0],
                        timeout: 4000,
                        progress: true,
                        icon: 'fal fa-check',
                        message: e[1],
                        position: 'top-right'
                    })
                } else if(e[0] == 'negative'){
                    this.$q.notify({
                        type: e[0],
                        timeout: 4000,
                        progress: true,
                        icon: 'fal fa-times',
                        message: e[1],
                        position: 'top-right'
                    })
                } else if(e[0] == 'warning'){
                    this.$q.notify({
                        type: e[0],
                        timeout: 4000,
                        progress: true,
                        icon: 'fal fa-exclamation-triangle',
                        message: e[1],
                        position: 'top-right'
                    })
                } else if(e[0] == 'info'){
                    this.$q.notify({
                        type: e[0],
                        timeout: 4000,
                        progress: true,
                        icon: 'fal fa-info-square',
                        message: e[1],
                        position: 'top-right'
                    })
                }
            }
        }
    }

</script>

<style lang="scss">

    @import "css/app.scss";

    *{
        font-family: $fontFamily !important;
        box-sizing: border-box;
    }

    html, body{
        color: $grey00;
        font: 400 12px/18px $fontFamily;
    }

    i{
        font-family: 'Font Awesome 5 Pro' !important;
    }

    .q-inner-loading{
        z-index: 1000;
    }

    .fade-enter-active, .fade-leave-active {
        transition: opacity .3s ease;
    }

    .fade-enter, .fade-leave-to{
        opacity: 0;
    }

    .form{
        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus{
            -webkit-box-shadow: 0 0 0px 1000px white inset;
            background-color: transparent;
            margin-bottom: 1px;
        }

        // Custom des inputs
        .q-field__control{
            height: 60px;
        }

        .q-field__marginal{
            height: 60px;
        }

        .q-field__append i{
            top: 6px;
            right: 10px;
            font-size: 16px;
        }

        .q-field--standard .q-field__control:before{
            border-bottom: 1px solid rgba(0, 0, 0, 0.09);
        }

        .q-field--standard .q-field__control:hover:before{
            border-color: rgba(0, 0, 0, 0.4);
        }

        .q-field--labeled .q-field__native, .q-field--labeled .q-field__prefix, .q-field--labeled .q-field__suffix{
            padding-bottom: 12px;
        }

        .q-field--labeled .q-field__suffix{
            color: $grey01;
            font-weight: 300;
            font-size: 13px;
            padding-left: 5px;
        }

        .q-field__label{
            font-size: 13px;
            top: 17px;
            padding-top: 8px;
            color: rgba(0, 0, 0, 0.4);
            transition: all .2s ease;
        }

        .q-field--float .q-field__label{
            font-size: 13px;
            top: 17px;
            transition: all .2s ease;
        }

        .q-field__native, .q-field__input{
            font-size: 13px;
            color: $grey00;
        }

        .q-slider{
            margin: 0 0 40px 0;
        }

        .q-slider__track-container{
            background: rgba(0, 0, 0, 0.09);
            border-radius: 2px;
        }

        .q-slider--label.q-slider--label .q-slider__pin{
            top: 57px;
        }

        .q-slider--label.q-slider--label-always .q-slider__arrow{
            top: 22px;
            transform: rotate(180deg) !important;
            opacity: 1;
        }

        .q-slider__pin-text{
            font-size: 10px;
            line-height: 16px;
        }

        .q-slider__pin-text-container{
            min-height: 21px;
            padding: 1px 6px;
        }

        .q-toggle{
            width: 100%;
            justify-content: space-between;
            border-bottom: 1px solid rgba(0,0,0,0.09);
            padding: 17px 0 4px 0;

            i{
                float: left;
                font-size: 16px;
                line-height: 18px;
                color: $blue00;
                padding: 0 20px 0 0;
            }

        }

        .q-toggle__label{
            float: left;
            font-size: 13px;
            font-weight: 500;
        }

        .q-toggle__track{
            height: 0.315em;
            margin-top: 1px;
        }

        .q-toggle__inner--truthy .q-toggle__track{
            opacity: 0.3;
        }

        .q-toggle__inner{
            font-size: 38px;
        }

        .q-select{

            span{
                width: auto !important;
                float: none !important;

                &:first-child{
                    padding: 0 !important;
                }

                &:last-child{
                    padding: 0 !important;
                }

            }

        }

        .q-field__prepend,
        .q-field__before{
            padding-right: 20px;

            .q-icon{
                font-size: 16px;
                margin: 10px 0 0 0;

                &.blue{
                    color: $blue00;
                }

            }

        }

        .q-field__counter{
            font-size: 10px;
        }

        .q-item{
            min-height: auto;
        }

        .q-item__section--avatar{
            min-width: 25px;
            max-width: 25px;
            padding: 0;

            i{
                font-size: 16px;
                color: $grey03;
            }

        }

        .q-item__section--main ~ .q-item__section--side{
            padding: 0;
        }

        .radio{
            padding: 15px 0 4px 0;
            border-bottom: 1px solid rgba(0,0,0,0.09);
            text-align: right;

            .q-radio{

            }

            p{
                float: left;
                margin: 0;
                padding: 11px 0 0 0;
                font-size: 13px;
            }

        }

        .q-radio__label{
            font-size: 13px;
        }

        .validateButton{
            padding-top: 30px;
            width: 100%;
            overflow: hidden;

            &.right{
                text-align: right;
            }

            &.left{
                text-align: left;
            }

        }

        .input-col1{
            overflow: hidden;

            span{
                width: 100%;
                float: left;

                &.surchargeCol1{
                    width: 100% !important;
                    padding: 0 !important;
                }

            }

        }

        .input-col2{
            overflow: hidden;

            span{
                width: 50%;
                float: left;

                &:first-child{
                    padding: 0 10px 0 0;
                }

                &:last-child{
                    padding: 0 0 0 10px;
                }

            }

        }

        .input-col3{
            overflow: hidden;

            span{
                width: 33.33%;
                float: left;

                &:first-child{
                    padding: 0 13px 0 0;
                }

                &:nth-child(2){
                    padding: 0 7px;
                }

                &:last-child{
                    padding: 0 0 0 13px;
                }

            }

        }

        .input-col4{
            overflow: hidden;

            span{
                width: 25%;
                float: left;

                &:first-child{
                    padding: 0 15px 0 0;
                }

                &:nth-child(2){
                    padding: 0 10px 0 5px;
                }

                &:nth-child(3){
                    padding: 0 5px 0 10px;
                }

                &:last-child{
                    padding: 0 0 0 15px;
                }

            }

        }

        .input-col5{
            overflow: hidden;

            span{
                width: 20%;
                float: left;

                &:first-child{
                    padding: 0 16px 0 0;
                }

                &:nth-child(2){
                    padding: 0 12px 0 4px;
                }

                &:nth-child(3){
                    padding: 0 8px 0 8px;
                }

                &:nth-child(4){
                    padding: 0 4px 0 12px;
                }

                &:last-child{
                    padding: 0 0 0 16px;
                }

            }

        }

        .col{

            &.col1{
                width: calc(100% / 12);
            }

            &.col2{
                width: calc(100% / 12 * 2);
            }

            &.col3{
                width: calc(100% / 12 * 3);
            }

            &.col4{
                width: calc(100% / 12 * 4);
            }

            &.col5{
                width: calc(100% / 12 * 5);
            }

            &.col6{
                width: calc(100% / 12 * 6);
            }

            &.col7{
                width: calc(100% / 12 * 7);
            }

            &.col8{
                width: calc(100% / 12 * 8);
            }

            &.col9{
                width: calc(100% / 12 * 9);
            }

            &.col10{
                width: calc(100% / 12 * 10);
            }

            &.col11{
                width: calc(100% / 12 * 11);
            }

            &.col12{
                width: 10%;
            }

        }

        .input{

            .legend{
                padding: 8px 0 0 33px;
                font-size: 10px;
                line-height: 20px;

                i{
                    font-size: 16px;
                    padding: 2px 10px 0 0;
                    float: left;
                }

                .orange{
                    color: $orange;
                }

                .red{
                    color: $red;
                }

                .blue{
                    color: $blue00;
                }

            }

        }

        .center{
            text-align: center;
        }

        .noMargin{
            margin: 0;
        }

    }

    .q-notification{
        box-shadow: none;
        font-size: 13px;
        padding: 0 20px;
        color: #fff !important;
    }

    .q-notification__icon {
        font-size: 16px;
        padding-right: 20px;
        color: #fff;
    }

    .button{
        border-radius: 5px;
        opacity: 1;
        text-align: center;
        text-transform: uppercase;

        &.large{
            font: 500 20px/26px $fontFamily;
            letter-spacing: 0.08px;
            height: 54px;

            .q-btn__wrapper {
                padding: 4px 26px;
            }

        }

        &.medium{
            font: 500 14px/26px $fontFamily;
            letter-spacing: 0.06px;
            height: 36px;

            .q-btn__wrapper {
                padding: 4px 20px;
            }

        }

        &.small{
            font: 500 12px/26px $fontFamily;
            height: 32px;
            letter-spacing: 0.05px;

            .q-btn__wrapper {
                padding: 4px 18px;
            }

            &.round{
                border-radius: 50px;
                width: 32px;

                i{
                    font-size: 16px;
                }

                .q-btn__wrapper {
                    padding: 4px 13px;
                }

            }

        }

        &.minSmall{
            font: 500 12px/26px $fontFamily;
            height: 24px;
            letter-spacing: 0;
            line-height: 18px;

            .q-btn__wrapper {
                padding: 0 10px;
                min-height: auto;
            }

            &.round{
                border-radius: 50px;
                width: 24px;

                i{
                    font-size: 14px;
                }

                .q-btn__wrapper {
                    padding: 0 10px;
                }

            }

        }

        &.right{
            float: right;

            &.margin{
                margin: 0 0 0 10px;
            }

        }

        &.left{
            float: left;

            &.margin{
                margin: 0 0 0 10px;
            }

        }

        &.clear{
            clear: both;
        }

    }

    .q-tabs__content{
        padding: 0 40px;
    }

    .q-tab__icon{
        font-size: 20px;
    }

    .q-tab__label{
        font-size: 8px;
        color: $grey00;
        transition: all .2s ease;
    }

    .q-tab--inactive{
        color: $grey02;

        .q-tab__label{
            color: $grey03;
        }

    }

    .q-tab-panel{
        padding: 0;
    }

    @media screen and (max-width: 1450px){

        .q-tabs__content{
            padding: 0 30px;
        }

    }

    a{
        cursor: pointer;
        color: $grey00;
        text-decoration: underline;
        font: 500 12px/18px $fontFamily;
        transition: all .2s ease;

        &:hover{
            color: $blue00;
        }

    }

    .q-zoom{
        position: absolute;
        height: 100%;
        width: 100%;
        top: 0;

        .zoom{
            display: none;
        }

    }

    .q-zoom__overlay{
        text-align: center;
        padding: 70px;
        background-color: rgba(0,0,0,0.6) !important;

        .q-zoom__content{
            background-color: transparent !important;

            .zoom{
                display: inline;
                max-width: 100%;
                max-height: 100%;
                border-radius: 5px;
            }

        }

    }

    .mapboxgl-ctrl-top-left, .mapboxgl-ctrl-top-right, .mapboxgl-ctrl-bottom-left, .mapboxgl-ctrl-bottom-right{
        z-index: auto;
    }

    #content {
        position: absolute;
        bottom: 0;
        right: 0;
        top: 0;
        left: 100px;
        background-color: $grey05;
        overflow: auto;

        .contentLeft{
            position: absolute;
            left: 0;
            top : 0px;
            bottom: 0;
            right: 300px;
            overflow: auto;

            .scrollArea {
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                right: 0;

                .content{
                    width: 90%;
                    margin: 65px auto 30px;
                }

            }

            .headerBloc {

                .informationsPage {
                    padding: 0 20px;

                    .title {
                        text-align: left;
                        font-size: 20px;
                        line-height: 28px;
                        font-weight: 700;
                        margin: 0 0 7px 0;
                        color: $grey00;

                        .ref{
                            color: $blue00;
                            font-weight: 400;
                        }

                    }

                    .subTitle{
                        font-size: 14px;
                        font-weight: 500;
                        margin: 0 0 5px 0;
                    }

                    .description {
                        text-align: left;
                        font-size: 12px;
                        line-height: 18px;
                        font-weight: 400;
                        color: $grey02;
                    }

                }

            }

        }

        @media screen and (max-width: 1450px){

            .contentLeft{
                right: 250px;

                .scrollArea{

                    .content{
                        margin: 50px auto 30px;
                    }

                }

            }

        }

        .contentRight{
            position: absolute;
            box-shadow: 0 2px 10px 0 rgba(0,0,0,0.03);
            z-index: 12;
            top: 0;
            right: 0;
            bottom: 0;
            width: 300px;
            background: #FFFFFF 0% 0% no-repeat padding-box;

            .scrollArea {
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                right: 0;

                .content{
                    width: 100%;
                    padding: 65px 40px 40px;

                    .title{
                        text-transform: uppercase;
                        font-size: 11px;
                        line-height: 18px;
                        margin: 0 0 10px 0;
                        color: $grey00;

                        i{
                            float: left;
                            padding: 0 15px 0 0;
                            font-size: 16px;
                            color: $blue00;
                        }

                    }

                    p{
                        font-size: 12px;

                        &.empty{
                            color: $grey02;
                            font-style: italic;
                        }

                    }

                }

            }

        }

        @media screen and (max-width: 1450px){

            .contentRight{
                width: 250px;

                .scrollArea{

                    .content{
                        padding: 50px 30px 30px;
                    }

                }

            }

        }

    }

    @media screen and (max-width: 1450px){

        #content{
            left: 80px;
        }

    }

    // Icon MapBox

    .mapboxgl-ctrl-zoom-out .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E %3Cpath style='fill:%23333333;' d='m 7,9 c -0.554,0 -1,0.446 -1,1 0,0.554 0.446,1 1,1 l 6,0 c 0.554,0 1,-0.446 1,-1 0,-0.554 -0.446,-1 -1,-1 z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-zoom-in .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E %3Cpath style='fill:%23333333;' d='M 10 6 C 9.446 6 9 6.4459904 9 7 L 9 9 L 7 9 C 6.446 9 6 9.446 6 10 C 6 10.554 6.446 11 7 11 L 9 11 L 9 13 C 9 13.55401 9.446 14 10 14 C 10.554 14 11 13.55401 11 13 L 11 11 L 13 11 C 13.554 11 14 10.554 14 10 C 14 9.446 13.554 9 13 9 L 11 9 L 11 7 C 11 6.4459904 10.554 6 10 6 z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%23333'%3E %3Cpath d='M10 4C9 4 9 5 9 5L9 5.1A5 5 0 0 0 5.1 9L5 9C5 9 4 9 4 10 4 11 5 11 5 11L5.1 11A5 5 0 0 0 9 14.9L9 15C9 15 9 16 10 16 11 16 11 15 11 15L11 14.9A5 5 0 0 0 14.9 11L15 11C15 11 16 11 16 10 16 9 15 9 15 9L14.9 9A5 5 0 0 0 11 5.1L11 5C11 5 11 4 10 4zM10 6.5A3.5 3.5 0 0 1 13.5 10 3.5 3.5 0 0 1 10 13.5 3.5 3.5 0 0 1 6.5 10 3.5 3.5 0 0 1 10 6.5zM10 8.3A1.8 1.8 0 0 0 8.3 10 1.8 1.8 0 0 0 10 11.8 1.8 1.8 0 0 0 11.8 10 1.8 1.8 0 0 0 10 8.3z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate:disabled .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%23aaa'%3E %3Cpath d='M10 4C9 4 9 5 9 5L9 5.1A5 5 0 0 0 5.1 9L5 9C5 9 4 9 4 10 4 11 5 11 5 11L5.1 11A5 5 0 0 0 9 14.9L9 15C9 15 9 16 10 16 11 16 11 15 11 15L11 14.9A5 5 0 0 0 14.9 11L15 11C15 11 16 11 16 10 16 9 15 9 15 9L14.9 9A5 5 0 0 0 11 5.1L11 5C11 5 11 4 10 4zM10 6.5A3.5 3.5 0 0 1 13.5 10 3.5 3.5 0 0 1 10 13.5 3.5 3.5 0 0 1 6.5 10 3.5 3.5 0 0 1 10 6.5zM10 8.3A1.8 1.8 0 0 0 8.3 10 1.8 1.8 0 0 0 10 11.8 1.8 1.8 0 0 0 11.8 10 1.8 1.8 0 0 0 10 8.3z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-active .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%2333b5e5'%3E %3Cpath d='M10 4C9 4 9 5 9 5L9 5.1A5 5 0 0 0 5.1 9L5 9C5 9 4 9 4 10 4 11 5 11 5 11L5.1 11A5 5 0 0 0 9 14.9L9 15C9 15 9 16 10 16 11 16 11 15 11 15L11 14.9A5 5 0 0 0 14.9 11L15 11C15 11 16 11 16 10 16 9 15 9 15 9L14.9 9A5 5 0 0 0 11 5.1L11 5C11 5 11 4 10 4zM10 6.5A3.5 3.5 0 0 1 13.5 10 3.5 3.5 0 0 1 10 13.5 3.5 3.5 0 0 1 6.5 10 3.5 3.5 0 0 1 10 6.5zM10 8.3A1.8 1.8 0 0 0 8.3 10 1.8 1.8 0 0 0 10 11.8 1.8 1.8 0 0 0 11.8 10 1.8 1.8 0 0 0 10 8.3z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-active-error .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%23e58978'%3E %3Cpath d='M10 4C9 4 9 5 9 5L9 5.1A5 5 0 0 0 5.1 9L5 9C5 9 4 9 4 10 4 11 5 11 5 11L5.1 11A5 5 0 0 0 9 14.9L9 15C9 15 9 16 10 16 11 16 11 15 11 15L11 14.9A5 5 0 0 0 14.9 11L15 11C15 11 16 11 16 10 16 9 15 9 15 9L14.9 9A5 5 0 0 0 11 5.1L11 5C11 5 11 4 10 4zM10 6.5A3.5 3.5 0 0 1 13.5 10 3.5 3.5 0 0 1 10 13.5 3.5 3.5 0 0 1 6.5 10 3.5 3.5 0 0 1 10 6.5zM10 8.3A1.8 1.8 0 0 0 8.3 10 1.8 1.8 0 0 0 10 11.8 1.8 1.8 0 0 0 11.8 10 1.8 1.8 0 0 0 10 8.3z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-background .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%2333b5e5'%3E %3Cpath d='M 10,4 C 9,4 9,5 9,5 L 9,5.1 C 7.0357113,5.5006048 5.5006048,7.0357113 5.1,9 L 5,9 c 0,0 -1,0 -1,1 0,1 1,1 1,1 l 0.1,0 c 0.4006048,1.964289 1.9357113,3.499395 3.9,3.9 L 9,15 c 0,0 0,1 1,1 1,0 1,-1 1,-1 l 0,-0.1 c 1.964289,-0.400605 3.499395,-1.935711 3.9,-3.9 l 0.1,0 c 0,0 1,0 1,-1 C 16,9 15,9 15,9 L 14.9,9 C 14.499395,7.0357113 12.964289,5.5006048 11,5.1 L 11,5 c 0,0 0,-1 -1,-1 z m 0,2.5 c 1.932997,0 3.5,1.5670034 3.5,3.5 0,1.932997 -1.567003,3.5 -3.5,3.5 C 8.0670034,13.5 6.5,11.932997 6.5,10 6.5,8.0670034 8.0670034,6.5 10,6.5 Z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-background-error .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' fill='%23e54e33'%3E %3Cpath d='M 10,4 C 9,4 9,5 9,5 L 9,5.1 C 7.0357113,5.5006048 5.5006048,7.0357113 5.1,9 L 5,9 c 0,0 -1,0 -1,1 0,1 1,1 1,1 l 0.1,0 c 0.4006048,1.964289 1.9357113,3.499395 3.9,3.9 L 9,15 c 0,0 0,1 1,1 1,0 1,-1 1,-1 l 0,-0.1 c 1.964289,-0.400605 3.499395,-1.935711 3.9,-3.9 l 0.1,0 c 0,0 1,0 1,-1 C 16,9 15,9 15,9 L 14.9,9 C 14.499395,7.0357113 12.964289,5.5006048 11,5.1 L 11,5 c 0,0 0,-1 -1,-1 z m 0,2.5 c 1.932997,0 3.5,1.5670034 3.5,3.5 0,1.932997 -1.567003,3.5 -3.5,3.5 C 8.0670034,13.5 6.5,11.932997 6.5,10 6.5,8.0670034 8.0670034,6.5 10,6.5 Z'/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-fullscreen .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E %3Cpath d='M 5 4 C 4.5 4 4 4.5 4 5 L 4 6 L 4 9 L 4.5 9 L 5.7773438 7.296875 C 6.7771319 8.0602131 7.835765 8.9565728 8.890625 10 C 7.8257121 11.0633 6.7761791 11.951675 5.78125 12.707031 L 4.5 11 L 4 11 L 4 15 C 4 15.5 4.5 16 5 16 L 9 16 L 9 15.5 L 7.2734375 14.205078 C 8.0428931 13.187886 8.9395441 12.133481 9.9609375 11.068359 C 11.042371 12.14699 11.942093 13.2112 12.707031 14.21875 L 11 15.5 L 11 16 L 14 16 L 15 16 C 15.5 16 16 15.5 16 15 L 16 14 L 16 11 L 15.5 11 L 14.205078 12.726562 C 13.177985 11.949617 12.112718 11.043577 11.037109 10.009766 C 12.151856 8.981061 13.224345 8.0798624 14.228516 7.3046875 L 15.5 9 L 16 9 L 16 5 C 16 4.5 15.5 4 15 4 L 11 4 L 11 4.5 L 12.703125 5.7773438 C 11.932647 6.7864834 11.026693 7.8554712 9.9707031 8.9199219 C 8.9584739 7.8204943 8.0698767 6.7627188 7.3046875 5.7714844 L 9 4.5 L 9 4 L 6 4 L 5 4 z '/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-shrink .mapboxgl-ctrl-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E %3Cpath style='fill:%23000000;' d='M 4.2421875 3.4921875 A 0.750075 0.750075 0 0 0 3.71875 4.78125 L 5.9648438 7.0273438 L 4 8.5 L 4 9 L 8 9 C 8.500001 8.9999988 9 8.4999992 9 8 L 9 4 L 8.5 4 L 7.0175781 5.9550781 L 4.78125 3.71875 A 0.750075 0.750075 0 0 0 4.2421875 3.4921875 z M 15.734375 3.4921875 A 0.750075 0.750075 0 0 0 15.21875 3.71875 L 12.984375 5.953125 L 11.5 4 L 11 4 L 11 8 C 11 8.4999992 11.499999 8.9999988 12 9 L 16 9 L 16 8.5 L 14.035156 7.0273438 L 16.28125 4.78125 A 0.750075 0.750075 0 0 0 15.734375 3.4921875 z M 4 11 L 4 11.5 L 5.9648438 12.972656 L 3.71875 15.21875 A 0.75130096 0.75130096 0 1 0 4.78125 16.28125 L 7.0273438 14.035156 L 8.5 16 L 9 16 L 9 12 C 9 11.500001 8.500001 11.000001 8 11 L 4 11 z M 12 11 C 11.499999 11.000001 11 11.500001 11 12 L 11 16 L 11.5 16 L 12.972656 14.035156 L 15.21875 16.28125 A 0.75130096 0.75130096 0 1 0 16.28125 15.21875 L 14.035156 12.972656 L 16 11.5 L 16 11 L 12 11 z '/%3E %3C/svg%3E");
    }

    .mapboxgl-ctrl-shrink .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-fullscreen .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-background-error .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-background .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-active-error .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate.mapboxgl-ctrl-geolocate-active .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate:disabled .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-geolocate .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-zoom-in .mapboxgl-ctrl-icon,
    .mapboxgl-ctrl-zoom-out .mapboxgl-ctrl-icon {
        width: 20px;
        height: 20px;
        margin: 5px;
        display: block;
    }

    .mapboxgl-ctrl-compass .mapboxgl-ctrl-icon {
        width: 20px;
        height: 20px;
        margin: 5px;
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E %3Cpolygon fill='%23333333' points='6,9 10,1 14,9'/%3E %3Cpolygon fill='%23CCCCCC' points='6,11 10,19 14,11 '/%3E %3C/svg%3E");
        background-repeat: no-repeat;
        display: inline-block;
    }

</style>
