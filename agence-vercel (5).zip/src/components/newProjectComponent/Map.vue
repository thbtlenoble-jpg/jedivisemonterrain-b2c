<template>
    <div id="map" ref="mapPlot"></div>
</template>

<script>
    import Vue from "vue";
   // import L from "leaflet";
    import Vuex from "vuex";
    import Store from "../../store/index";

    export default {
        name: "Map",
        props: ['entrySelect'],
        data() {
            return {
                listPolygon : [],
                myIcon : {
                    iconUrl: '../../statics/map-marker-icon.jpg',
                    iconSize: [38, 95],
                    iconAnchor: [22, 94],
                    popupAnchor: [-3, -76],
                }
            }
        },
        created(){
            //this.plotsSelected = []
        },
        mounted() {
            this.loadPlots()
        },

        computed: {
            ...Vuex.mapGetters([
                'projectPlots','projectPlotsSelected'
            ])
        },
        methods: {
            ...Vuex.mapActions([
                'loadPlots',
            ]),

            loadPlots() {

                Store.dispatch("loadPlots", {
                    lat: this.entrySelect.geometry.coordinates[1],
                    lon: this.entrySelect.geometry.coordinates[0]
                }).then(response => {
                    this.projectPlots.results.forEach((element)=>{
                        element.selected = false
                    })
                    this.loadMap();
                }, error => {
                })
            },

            loadMap() {
                let vm = this
                // Affichage de la map
                this.map = L.map(this.$refs['mapPlot']).setView([this.entrySelect.geometry.coordinates[1], this.entrySelect.geometry.coordinates[0]], 19);
                this.tileLayer = L.tileLayer('https://wxs.ign.fr/choisirgeoportail/geoportail/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0&STYLE=normal&TILEMATRIXSET=PM&FORMAT=image/jpeg&LAYER=ORTHOIMAGERY.ORTHOPHOTOS&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}', {
                    maxZoom: 20,
                    maxNativeZoom: 19,
                    attribution: '<a target="_blank" href="https://www.geoportail.gouv.fr/">Geoportail France</a>',
                });
                this.tileLayer.addTo(this.map);
                L.control.scale().addTo(this.map);
                this.drawPlots()
                const defaultMarker = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=';

                const defaultMarkerShadow = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC';

                var defaultIcon = new L.Icon({
                    iconUrl: defaultMarker,
                    iconAnchor: [12, 41],
                    shadowUrl: defaultMarkerShadow,
                });

                L.marker([this.entrySelect.geometry.coordinates[1], this.entrySelect.geometry.coordinates[0]], { icon: defaultIcon }).addTo(this.map);

            },
            drawPlots(){
                let vm = this
                this.projectPlots.results.forEach((feature) => {

                    let coordTab = []
                    feature.geometry.coordinates[0].forEach(a =>{
                        let coord = [];
                        coord.push(a[1]);
                        coord.push(a[0])
                        coordTab.push(coord)
                    });

                    let polygon = L.polygon(coordTab).addTo(vm.map);
                    vm.listPolygon.push(polygon)
                    if(feature.selected){
                        polygon.setStyle({ color : '#fae500', opacity : 1, fillOpacity: 0.3, dashArray : null }).on('click', function (e) {
                            if (feature.selected) {
                                polygon.setStyle({ color : '#fae500', opacity : 0.2, fillOpacity: 0.0 })

                            } else {
                                polygon.setStyle({ color : '#fae500', opacity : 1, fillOpacity: 0.3, dashArray : null })
                            }
                        })
                    } else {
                        polygon.setStyle({ color : '#fae500', opacity:0.2, fillOpacity: 0.0 }).on('click', function (e) {
                            if (feature.selected) {
                                polygon.setStyle({ color : '#fae500', opacity : 0.2, fillOpacity: 0.0 })

                            } else {
                                polygon.setStyle({ color : '#fae500', opacity : 1, fillOpacity: 0.3, dashArray : null })

                            }
                        })
                    }



                    polygon.on('mouseover', function (e) {
                        if (!feature.selected) {
                            polygon.setStyle({ opacity : 1, dashArray : '15 15' })
                        }
                    });
                    polygon.on('mouseout', function (e) {
                        if (!feature.selected) {
                            polygon.setStyle({ opacity : 0.2, dashArray : null })
                        }
                    });
                    polygon.on('click', function (e) {
                        if (feature.selected) {
                            feature.selected = false
                            vm.projectPlotsSelected.forEach(function(item,index){
                                if(feature.id == item.id){
                                    vm.projectPlotsSelected.splice(index,1)
                                }
                            })

                        } else {
                            feature.selected = true
                            vm.projectPlotsSelected.push(feature)

                        }
                        //v.saveSelected(feature)
                    });
                });
            },
            removePlots() {

                this.listPolygon.forEach(polygon => {
                    this.map.removeLayer(polygon)
                })
                this.listPolygon = []
            },
        }
    }
</script>

<style scoped>
    #map {
        position: absolute;
        bottom: 0;
        top: 0;
        left: 0;
        right: 0;
        width: 100%;
        height: 100%;
        z-index: 10;
    }
</style>
