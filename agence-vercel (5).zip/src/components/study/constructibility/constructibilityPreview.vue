<template>
    <DIV>
        DEV
    </DIV>
</template>

<script>
    export default {
        name: "constructibilityPreview"
    }
</script>

<style scoped>

</style>
