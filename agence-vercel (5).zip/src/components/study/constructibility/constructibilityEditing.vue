<template>
    <div class="editingConstructibility">
        <div class="headerEditing">
            <span>Edition</span>
            Validation de la constructibilité
            <div class="stepAction">
                <span>{{ currentStep }}</span
                >/{{ nbStep }}
            </div>
        </div>
        <div class="form" v-if="currentStep == 1">
            <div class="answer">Quel est le marché qui avoisine la parcelle ?</div>
            <div class="listBlocs">
                <div class="bloc">
                    <div class="conteneur" :class="{'active': !valuesEditing.isBuildable}" @click="changeBuildability(valuesEditing.isBuildable)"  >
                        <span>Non constructible</span>
                    </div>
                </div>
                <div class="bloc">
                    <div class="conteneur" :class="{'active': valuesEditing.isBuildable}"  @click="changeBuildability(valuesEditing.isBuildable)"  >
                        <span>Constructible</span>
                    </div>
                </div>
            </div>
            <div class="input">
                <div class="input-col2">
                    <span>
                        <q-select
                                v-model="valuesEditing.urbanismPlanningZone"
                                option-value="id" emit-value map-options
                                option-label="value"
                                :options="urbanismPlanningZoneOptions"
                                label="Zonage d'urbanisme"/>
                    </span>
                    <span>
                         <q-select
                                 v-model="valuesEditing.riskArea"
                                 option-value="id" emit-value map-options
                                 option-label="value"
                                 :options="riskAreaOptions"
                                 label="Zonage de risque"/>
                    </span>
                </div>
            </div>
            <div class="input">
                <div class="input-col1">
                    <span>
                         <q-input
                                 v-model="valuesEditing.commentaryArea"
                                 class="texteAreaBloc"
                                 type="textarea"
                                 label="Commentaire"
                         />
                    </span>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 2">
            <div class="answer">Quel type de projet est réalisable ?</div>
            <div class="listBlocs">
                <div class="bloc" v-for="bloc in valuesEditing.type">
                    <div class="conteneur" :class="{ 'trueState': bloc.state == true , 'nullState' : bloc.state == null , 'falseState' : bloc.state == false }" @click="changePossibilityState(bloc)">
                        <div class="state">
                            <span v-if="bloc.state == true"><i class="fal fa-check"></i></span>
                            <span v-if="bloc.state == null"> En attente ...</span>
                            <span v-if="bloc.state == false"><i class="fal fa-times"></i></span>
                        </div>
                        <span v-html="bloc.name"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn
                    v-if="currentStep > 1"
                    class="button small left"
                    unelevated
                    color="grey"
                    text-color="dark"
                    label="Retour"
                    v-on:click="previousStep()"
            />
            <q-btn
                    v-if="currentStep < nbStep && valuesEditing.isBuildable"
                    class="button small right"
                    unelevated
                    color="primary"
                    text-color="white"
                    label="Suite de l'action"
                    v-on:click="nextStep()"
            />
            <q-btn
                    v-if="currentStep == nbStep || !valuesEditing.isBuildable"
                    class="button small right"
                    unelevated
                    color="primary"
                    text-color="white"
                    label="Terminer et fermer"
                    v-on:click="$emit('returnAction', ['endAndClose'])"
            />
            <q-btn
                    class="button small right clear"
                    unelevated
                    color="grey"
                    text-color="dark"
                    label="Fermer"
                    v-on:click="$emit('returnAction', ['close'])"
            />
        </div>
    </div>

</template>

<script>
    export default {
        name: "constructibilityEditing",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                tab: "blocEstimation",
                currentStep: 1,
                nbStep: 2,
                riskAreaOptions : [{id : 1 , value : 'Oui'},{id : 2 , value : 'non'}],
                urbanismPlanningZoneOptions : [{id : 1 , value : 'non'},{id : 2 , value : 'NUECLEAR'}, {id : 3 , value : 'Oui'}]
            };
        },
        methods:{
            nextStep(){
                this.currentStep++
            },
            previousStep(){
                this.currentStep--
            },
            changeBuildability(e){
                e ? this.valuesEditing.isBuildable = false : this.valuesEditing.isBuildable = true;
            },
            changePossibilityState(e){
                if(e.state == null){
                    e.state = true
                }
                else if(e.state == true){
                    e.state = false
                }
                else {
                    e.state = null
                }
            }
        }
    }
</script>

<style lang="scss">

    @import "../../../css/app";

    .editingConstructibility{
        .form{
            .input{
                .texteAreaBloc{
                    height: auto;
                    .q-field__control{
                        height: auto;
                    }
                }
            }

            .listBlocs{
                .bloc{
                    .conteneur{
                        &.trueState{
                            box-shadow: none !important;
                            color: #90D960;
                            border: 1px solid #90D960 !important;
                        }

                        &.falseState{
                            box-shadow: none !important;
                            color :#F1854E;
                            border: 1px solid #F1854E !important ;
                        }
                        &.nullState{
                            .state{
                                span{
                                    font-style: italic !important;
                                    font-size: 11px !important;
                                    color: $grey03 !important;
                                    font-weight: normal !important;
                                }
                            }
                        }
                    }
                }
            }

        }

    }


</style>
