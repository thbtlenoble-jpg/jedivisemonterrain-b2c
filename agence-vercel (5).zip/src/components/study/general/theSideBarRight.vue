<template>
    <div id="theSideBarRight">
        <q-tabs v-model="tab" :breakpoint="0" active-color="blue" align="left" indicator-color="blue">
            <q-tab name="informations" icon="fal fa-info-circle" label="informations" />
            <q-tab name="plots" icon="fal fa-map-marker-alt" label="Parcelles" />
        </q-tabs>
        <q-separator />
        <q-tab-panels v-model="tab" animated swipeable transition-prev="jump-right" transition-next="jump-left">
            <q-tab-panel name="informations">
                <div class="conteneur">
<!--                    <q-btn icon="fal fa-chart-bar" class="button small" color="blue" unelevated label="Planning" />-->
                    <div class="bloc">
                        <i class="fal fa-map-marker-alt"></i>
                        <div class="content">
                            <p v-html="newFilter.addressFormat(projectCluster.address,'type1')">

                            </p>

                        </div>
                    </div>
<!--                    <div class="bloc">-->
<!--                        <i class="fal fa-user-hard-hat"></i>-->
<!--                        <div class="content">-->
<!--                            <p class="big blue">-->
<!--                                <strong>{{projectCluster.steps[step-1].actors.length}}</strong>-->
<!--                            </p>-->
<!--                            <p>-->
<!--                                {{ projectCluster.steps[step-1].actors.length | pluralize('Acteur impliqué', 'Acteurs impliqués') }}-->
<!--                            </p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="bloc">-->
<!--                        <i class="fal fa-clock"></i>-->
<!--                        <div class="content">-->
<!--                            <p class="big blue">-->
<!--                                <strong>{{projectCluster.id | timeTotalStep(projectCluster.steps[step-1].end, projectCluster.steps[step-1].creation)}}</strong> jours-->
<!--                            </p>-->
<!--                            <p>-->
<!--                                {{ nbDays | pluralize('Dédié à cette étape', 'Dédiés à cette étape') }}-->
<!--                            </p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="bloc" v-if="projectCluster.buildability.state">-->
<!--                        <i class="fal fa-check"></i>-->
<!--                        <div class="content">-->
<!--                            <p class="blue">-->
<!--                                Constructible-->
<!--                            </p>-->
<!--                            <p>-->
<!--                                Zone {{projectCluster.buildability.zone}}-->
<!--                            </p>-->
<!--                            <ul>-->
<!--                                <li :class="{ 'false' : !type.state }" v-for="type in projectCluster.buildability.type">-->
<!--                                    <i class="fal fa-arrow-alt-right"></i> {{type.name}}-->
<!--                                </li>-->
<!--                            </ul>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="bloc" v-else>-->
<!--                        <i class="fal fa-times"></i>-->
<!--                        <div class="content">-->
<!--                            <p class="red">-->
<!--                                Non constructible-->
<!--                            </p>-->
<!--                            <p>-->
<!--                                Zone {{projectCluster.buildability.zone}}-->
<!--                            </p>-->
<!--                        </div>-->
<!--                    </div>-->
                </div>
            </q-tab-panel>
            <q-tab-panel name="plots" class="plots">
                <div class="cardPlots" v-for="plot in projectCluster.plots">
                    <div class="infoBloc">
                        <span class="title">
                            Section
                        </span>
                        <span class="description">
                            {{plot.section}}
                        </span>
                    </div>
                    <div class="infoBloc">
                        <span class="title">
                            Numéro
                        </span>
                        <span class="description">
                            {{plot.numero}}
                        </span>
                    </div>
                    <div class="infoBloc">
                        <span class="title">
                            Contenance
                        </span>
                        <span class="description">
                            {{plot.contenance | formatIntegerMetrix}}
                        </span>
                    </div>
                </div>
            </q-tab-panel>
        </q-tab-panels>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../store/index'
    import newFilter from '../../../utils/filters.js'

    export default {
        name: "sideBarRight",
        props: ["projectCluster"],
        data(){
            return{
                tab: 'informations',
                step: 0,
                splitterModel: 20,
                newFilter : newFilter
            }
        },
        computed: {
            // nbDays: function(){
            //     return this.valueNbDays(this.projectCluster.steps[this.step-1].end, this.projectCluster.steps[this.step-1].creation)
            // },
        },
        created() {
            //this.step = this.projectCluster.steps.length
        },
        methods: {
            valueNbDays(end, creation) {
                return newFilter.timeTotalStep(1, end, creation)
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../css/app.scss";

    #theSideBarRight{
        .plots{
            margin-top: 10px;
            padding: 5px;
            .cardPlots{

                display: flex;
                justify-content: space-around;
                width: 90%;
                margin: 20px 5%;
                padding: 15px 5px;
                border: solid 1px $grey04;
                border-radius: 5px;
                .infoBloc{
                    width: 33.33%;
                    text-align: center;
                    span{
                        display: block;
                    }
                    .title{
                        font: 400 8px/18px Poppins;
                        color: $grey03;
                    }
                    .description{
                        font: 500 11px/18px Poppins;
                    }
                }
            }
        }


        .conteneur{
            padding: 35px 40px;

            .bloc{
                margin: 25px 0 0 0;
                overflow: hidden;

                i{
                    float: left;
                    width: 32px;
                    font-size: 16px;
                    line-height: 20px;
                    color: $grey02;
                }

            }

            .content{
                float: left;
                width: 188px;
                font-size: 13px;
                line-height: 20px;

                p{
                    margin: 0;
                    padding: 0;

                    &.big{
                        font-size: 18px;
                        line-height: 20px;
                    }

                    &.blue{
                        color: $blue;
                    }

                    &.red{
                        color: $red;
                    }

                    strong{
                        font-weight: 500;
                        font-size: 24px;
                    }

                }

                ul{
                    margin: 5px 0 0 0;
                    padding: 0;
                    list-style: none;

                    li{
                        line-height: 20px;
                        padding: 0 0 1px 0;
                        font-size: 12px;

                        i{
                            font-size: 16px;
                            line-height: 20px;
                            width: 24px;
                            color: $green;
                        }

                        &.false{
                            color: $grey03;

                            i{
                                color: $grey04;
                            }

                        }

                    }

                }

            }

        }



        @media screen and (max-width: 1450px){

            .conteneur{
                padding: 25px 30px;

                .bloc{
                    margin: 20px 0 0 0;

                    i{
                        width: 30px;
                        line-height: 19px;
                    }

                }

                .content{
                    width: 160px;
                    font-size: 12px;
                    line-height: 19px;

                    p{

                        &.big{
                            font-size: 17px;
                            line-height: 19px;
                        }

                        strong{
                            font-size: 22px;
                        }

                    }

                    ul{
                        margin: 3px 0 0 0;

                        li{
                            line-height: 19px;
                            padding: 0;
                            font-size: 11px;

                            i{
                                line-height: 19px;
                                width: 22px;
                            }

                        }

                    }

                }

            }

        }

    }

</style>
