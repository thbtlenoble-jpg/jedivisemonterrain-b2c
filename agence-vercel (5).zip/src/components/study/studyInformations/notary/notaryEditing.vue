<template>
    <div class="notaryEditing">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Notaire
            <div class="stepAction">
                <span>{{ currentStep }}</span
                >/{{ nbStep }}
            </div>
        </div>
        <div class="form">
            <div class="answer">Indiquez le notaire associé à l'étude</div>
            <div class="input">
                <div class="input-col4">
                    <span>
                        <q-input
                            v-model="notary.firstname"
                            label="Nom"
                            ref="lastname"
                            lazy-rules
                            :rules="[
                                (val) =>
                                    (val && val.length > 0) || 'Champ requis',
                            ]"
                        />
                    </span>
                    <span>
                        <q-input
                            v-model="notary.lastname"
                            label="Prénom"
                            ref="firstname"
                            lazy-rules
                            :rules="[
                                (val) =>
                                    (val && val.length > 0) || 'Champ requis',
                            ]"
                        />
                    </span>
                    <span
                        ><q-input
                            v-model="notary.phone"
                            label="Téléphone"
                            ref="phone"
                            mask="## ## ## ## ##"
                            lazy-rules
                            :rules="[
                                (val) =>
                                    (val && val.length > 0) || 'Champ requis',
                            ]"
                    /></span>
                    <span>
                        <q-input
                            v-model="notary.email"
                            label="Adresse e-mail"
                            ref="email"
                            lazy-rules
                            :rules="[
                                (val) =>
                                    (val && val.length > 0) || 'Champ requis',
                            ]"
                        />
                    </span>
                </div>
                <div class="input-col1">
                    <address-input
                        v-bind:entrySelect="notary.address"
                        v-on:changeAddress="changeAddress"
                    ></address-input>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn
                v-if="currentStep > 1"
                class="button small left"
                unelevated
                color="grey"
                text-color="dark"
                label="Retour"
                v-on:click="previousStep()"
            />
            <q-btn
                v-if="currentStep < nbStep"
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Suite de l'action"
                v-on:click="nextStep()"
            />
            <q-btn
                v-else
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Terminer et fermer"
                v-on:click="
                    addOrCreateNotaryToProject();

                "
            />
            <q-btn
                class="button small right clear"
                unelevated
                color="grey"
                text-color="dark"
                label="Fermer"
                v-on:click="$emit('returnAction', ['close'])"
            />
        </div>
    </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../../../../store/index";
    import newFunctions from "../../../../utils/functions.js";
    import addressInput from "../../../utils/addressInput";

    export default {
        name: "notaryEditing",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                currentStep: 1,
                nbStep: 1,
                functions: newFunctions,
                notary: {
                    email: null,
                    firstname: null,
                    lastname: null,
                    phone: null,
                    address: null,
                },
            };
        },
        computed: {
            ...Vuex.mapGetters([
                "projectReferential",
                "projectIsProjectsClusterLoaded",
            ]),
        },
        created() {
            this.init();
        },
        methods: {
            ...Vuex.mapActions([
                "addOrUpdateNotaryToProject",
                "getNotaryByProjectId",
            ]),
            init() {
                this.getNotaryByProjectId();
            },
            changeAddress(address) {
                this.notary.address = address;
            },
            getNotaryByProjectId() {
                Store.dispatch("getNotaryByProjectId", {
                    projectId: this.projectId,
                }).then(
                    (response) => {
                        if (response.status == 200) {
                            this.notary = { ...this.notary, ...response.body };
                        }
                    },
                    (error) => {}
                );
            },
            addOrCreateNotaryToProject() {
                this.$refs.email.validate();
                this.$refs.lastname.validate();
                this.$refs.firstname.validate();
                this.$refs.phone.validate();

                if(this.notary.address ==null){
                    this.$q.notify({
                        type: 'warning',
                        message: `Vous devez rechercher et sélectionner une adresse pour continuer`
                    })
                }else{
                    if (
                        this.$refs.email.hasError ||
                        this.$refs.lastname.hasError ||
                        this.$refs.firstname.hasError ||
                        this.$refs.phone.hasError
                    ) {
                    } else {
                        Store.dispatch("addOrUpdateNotaryToProject", {
                            projectId: this.projectId,
                            notary: this.notary,
                        }).then(
                            (response) => {
                                this.$emit('returnAction', ['endAndClose']);
                            },
                            (error) => {}
                        );
                    }
                }

            },
        },
        components: {
            addressInput,
        },
    };
</script>

<style lang="scss">
    @import "../../../../css/app";

    .notaryEditing {
    }
</style>
