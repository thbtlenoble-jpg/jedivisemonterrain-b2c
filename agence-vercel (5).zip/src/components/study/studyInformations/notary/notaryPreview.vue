<template>
    <div class="notaryPreview">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['notary', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Notaire
        </div>
        <div class="responses" v-if="state != 'empty'">
            <div class="bloc">
                <div class="answer"><span>1.</span> Indiquez le notaire associé à l'étude</div>
                <div class="response" v-if="emptyNotary()">
                    <div class="name"><i class="fal fa-gavel"></i>Maître {{notary.firstname}} {{notary.lastname}}</div>
                    <div class="address">
                        <i class="fal fa-map-marker-alt"></i>
                        {{notary.address.housenumber}} {{notary.address.street}}<br />{{notary.address.postcode}} {{notary.address.city}}
                    </div>
                    <div class="phone"><i class="fal fa-phone"></i>{{notary.phone}}</div>
                    <div class="mail"><i class="fal fa-envelope"></i>{{notary.email}}</div>
                </div>
                <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'

    export default {
        name: "notaryPreview",
        props: ["valuesPreview", "state","projectId"],
        data(){
            return{
                notary: {
                    email: null,
                    firstname: null,
                    lastname: null,
                    phone: null,
                    address: null,
                },
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded'
            ])
        },
        created(){
          this.getNotaryByProjectId()
        },
        methods:{
            emptyNotary(){
                if(this.notary.firstname == null || this.notary.lastname == null ||
                this.notary.phone == null || this.notary.email == null || this.notary.address == null){
                    return false
                } else {
                    return true
                }
            },
            getNotaryByProjectId() {
                Store.dispatch("getNotaryByProjectId", {
                    projectId: this.projectId,
                }).then(
                    (response) => {
                        if (response.status == 200) {
                            this.notary = { ...this.notary, ...response.body };
                        }
                    },
                    (error) => {}
                );
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .notaryPreview{

        .response{
            padding-top: 5px !important;

            i{
                float: left;
                font-size: 12px;
                line-height: 18px;
                padding: 0 10px 0 0;
                color: $grey02;
                width: 23px;
                text-align: center;
                margin: -2px 0 0 0;
            }

            div{
                padding: 0 0 9px 0;
                font-weight: 400;
                font-size: 11px;
                line-height: 14px;
                display: table;
            }

            .name{
                font-weight: 600;
                font-size: 13px;
                line-height: 14px;
            }

        }

    }

</style>
