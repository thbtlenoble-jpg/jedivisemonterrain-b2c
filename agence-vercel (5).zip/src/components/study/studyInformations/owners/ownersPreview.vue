<template>
    <div class="previewOwners">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['owners', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Propriétaire
        </div>
        <div class="responses" v-if="true">
            <div class="bloc">
                <div class="answer"><span>1.</span> Ajout du ou des propriétaires du bien</div>
                <div class="response">
                    <div class="cardOwners" v-if="owners != null">
                        <cardOwner v-for="(owner, index) in owners" :key="index" :owner="owner.person"></cardOwner>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions'

    import cardOwner from "../../../../components/study/elements/cardOwner";

    export default {
        name: "previewOwners",
        props: ["valuesPreview", "state","projectId"],
        data(){
            return{
                functions: newFunctions,
                owners: null,
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectBuilder',
                'projectIsProjectsClusterLoaded',
                'referentialIsReferentialLoading'
            ])
        },
        created(){
            this.init()
        },
        methods:{
            ...Vuex.mapActions[
                ("getPersonsByProjectIdAndPartnersType")
                ],
            async init() {
                await this.getOwners();
            },
            getOwners() {
                Store.dispatch("getPersonsByProjectIdAndPartnersType", {
                    projectId: this.projectId,
                    partnerType: "owner",
                }).then(
                    (response) => {
                        if(response.status == 200){
                            this.owners = response.body;
                        }

                    },
                    (error) => {}
                );
            },
        },
        components:{
            cardOwner
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .previewOwners {

    }

</style>
