<template>
    <div class="editingOwners">
        <q-inner-loading
            :showing="
                projectIsProjectsClusterLoaded ||
                referentialIsReferentialLoading
            "
        >
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Propriétaires
            <div class="stepAction">
                <span>{{ currentStep }}</span
                >/{{ nbStep }}
            </div>
        </div>
        <div class="form" v-if="currentStep == 1 && !addOwner">
            <div class="answer">Ajout du ou des propriétaires du bien</div>
            <div class="cards">
                <div class="cardOwners" v-for="(owner, index) in owners">
                    <cardOwner :key="index" :owner="owner.person"></cardOwner>
                    <q-btn
                        class="edit button minSmall round"
                        color="grey"
                        text-color="dark"
                        unelevated
                        icon="fal fa-edit"
                        @click="getPersonById(owner.person.id)"
                    />
                                        <q-btn
                                            @click="deleteOwnerFn(owner)"
                                            class="delete button minSmall round"
                                            color="grey"
                                            text-color="dark"
                                            unelevated
                                            icon="fal fa-trash-alt"
                                        />
                    <q-dialog v-model="confirm" persistent>
                        <q-card>
                            <q-card-section>
                                <q-card-section class="q-pt-xs">
                                    <div class="text-overline text-primary">
                                        Suppréssion d'un propriétaire
                                    </div>
                                    <div class="text-h5">
                                        {{ owner.person.firstname }}
                                        {{ owner.person.lastname }}
                                    </div>
                                    <div class="text-h7">
                                        Vous êtes sur le point de supprimer
                                        l'association de ce propiétaire à cette
                                        étude.
                                    </div>
                                </q-card-section>
                            </q-card-section>
                            <q-card-actions align="right" class="bg-grey">
                                <q-btn
                                    flat
                                    label="Annuler"
                                    class="button small"
                                    color="gray"
                                    v-close-popup
                                    @click="annuleDeleteOwnerFn"
                                />
                                <q-btn
                                    unelevated
                                    label="Valider la suppression"
                                    class="button small"
                                    color="primary"
                                    v-close-popup
                                    @click="deleteOwner(owner.id)"
                                />
                            </q-card-actions>
                        </q-card>
                    </q-dialog>
                </div>
                <div class="center noMargin">
                    <q-btn
                        unelevated
                        icon="fal fa-user-plus"
                        label="Ajouter un propriétaire"
                        class="button medium"
                        color="grey"
                        text-color="dark"
                        @click="(addOwner = true), (addStep = 1)"
                    />
                </div>
            </div>
        </div>
        <div class="link" v-if="!addOwner">
            <q-btn
                v-if="currentStep > 1"
                class="button small left"
                unelevated
                color="grey"
                text-color="dark"
                label="Retour"
                v-on:click="previousStep()"
            />
            <q-btn
                v-if="currentStep < nbStep"
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Suite de l'action"
                v-on:click="nextStep()"
            />
            <q-btn
                v-else
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Terminer et fermer"
                v-on:click="$emit('returnAction', ['endAndClose'])"
            />
            <q-btn
                class="button small right clear"
                unelevated
                color="grey"
                text-color="dark"
                label="Fermer"
                v-on:click="$emit('returnAction', ['close'])"
            />
        </div>
        <div class="form" v-if="addStep == 1 && addOwner">
            <div class="answer">Informations du propriétaire</div>
            <div class="input">
                <div class="input-col1">
                    <span
                        ><q-input
                            v-model="owner.email"
                            label="Entrer l'adresse e-mail du propriétaire"
                    /></span>
                </div>
            </div>
        </div>
        <div class="form" v-if="addStep == 2 && addOwner">
            <div class="answer">Informations du propriétaire</div>
            <div class="input">
                <div class="input-col2">
                    <span class="col col8">
                        <div class="input-col2">
                            <span>
                                <div class="radio">
                                    <p>Civilité</p>
                                    <q-radio
                                        v-for="gender in genderReferential"
                                        :key="gender.id"
                                        v-model="owner.civility"
                                        :val="gender.id"
                                        :label="gender.value"
                                    />
                                </div>
                            </span>
<!--                            <span-->
<!--                                ><q-select-->
<!--                                    v-model="owner.nationality"-->
<!--                                    option-value="id"-->
<!--                                    emit-value-->
<!--                                    map-options-->
<!--                                    option-label="name"-->
<!--                                    :options="projectCountry"-->
<!--                                    label="Nationalité"-->
<!--                            /></span>-->
                        </div>
                        <div class="input-col3">
                            <span>
                                <q-input
                                    v-model="owner.lastname"
                                    label="Nom"
                                    ref="lastname"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                                />
                            </span>
                            <span>
                                <q-input
                                    v-model="owner.firstname"
                                    label="Prénom"
                                    ref="firstname"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                                />
                            </span>
                            <span>
                                <q-input
                                    v-model="owner.birthdate"
                                    ref="birthdate"
                                    mask="##/##/####"
                                    fill-mask
                                    label="Date de naissance"
                                    title="Date de naissance"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                                >
                                    <template v-slot:append>
                                        <q-icon
                                            name="fal fa-calendar-alt"
                                            class="cursor-pointer"
                                        >
                                            <q-popup-proxy
                                                ref="qDateProxy"
                                                transition-show="scale"
                                                transition-hide="scale"
                                            >
                                                <q-date
                                                    v-model="owner.birthdate"
                                                    mask="DD/MM/YYYY"
                                                />
                                            </q-popup-proxy>
                                        </q-icon>
                                    </template>
                                </q-input>
                            </span>
                        </div>
                        <div class="input-col2">
                            <span
                                ><q-input
                                    v-model="owner.job"
                                    ref="job"
                                    label="Profession"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                                />
                            </span>
                            <span
                                ><q-select
                                    v-model="owner.maritalStatus"
                                    ref="maritalStatus"
                                    option-value="id"
                                    emit-value
                                    map-options
                                    option-label="value"
                                    :options="civilReferential"
                                    label="Etat civil"
                                    lazy-rules
                                    :rules="[
                                        (val) => val != null || 'Champ requis',
                                    ]"
                            /></span>
                        </div>
                        <div class="input-col1">
                            <address-input
                                v-bind:entrySelect="owner.address"
                                v-on:changeAddress="changeAddress"
                            ></address-input>
                        </div>
                        <div class="input-col2">
                            <span
                                ><q-input
                                    v-model="owner.mobile"
                                    label="Téléphone"
                                    ref="mobile"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                            /></span>
                            <span
                                ><q-input
                                    v-model="owner.email"
                                    ref="email"
                                    label="Adresse e-mail"
                                    lazy-rules
                                    :rules="[
                                        (val) =>
                                            (val && val.length > 0) ||
                                            'Champ requis',
                                    ]"
                            /></span>
                        </div>
                    </span>
                    <!--                    <span class="col col4" v-if="1 == 2">-->
                    <!--                        <div class="input-col1">-->
                    <!--                            <span class="surchargeCol1">-->
                    <!--                                <q-file-->
                    <!--                                    v-model="owner.files"-->
                    <!--                                    label="Carte d'identité"-->
                    <!--                                    counter-->
                    <!--                                    :counter-label="counterLabelFn"-->
                    <!--                                    max-files="3"-->
                    <!--                                    multiple-->
                    <!--                                >-->
                    <!--                                    <template v-slot:prepend>-->
                    <!--                                        <q-icon name="fal fa-paperclip" />-->
                    <!--                                    </template>-->
                    <!--                                </q-file>-->
                    <!--                                Aucun document envoyé-->
                    <!--                            </span>-->
                    <!--                        </div>-->
                    <!--                    </span>-->
                </div>
                <p
                    v-if="valideStatut(owner.maritalStatus) == 'Marié'"
                    class="subTitle"
                >
                    Parce que vous avez sélectionné "Marié"
                </p>
                <div
                    v-if="valideStatut(owner.maritalStatus) == 'Marié'"
                    class="input-col4"
                >
                    <span>
                        <q-input
                            v-model="owner.weddingContract.weddingDate"
                            label="Date de mariage"
                            title="Date de mariage"
                        >
                            <template v-slot:append>
                                <q-icon
                                    name="fal fa-calendar-alt"
                                    class="cursor-pointer"
                                >
                                    <q-popup-proxy
                                        ref="qDateProxy"
                                        transition-show="scale"
                                        transition-hide="scale"
                                    >
                                        <q-date
                                            v-model="
                                                owner.weddingContract
                                                    .weddingDate
                                            "
                                            mask="DD/MM/YYYY"
                                        />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span
                        ><q-input
                            v-model="owner.weddingContract.matrimonialRegime"
                            label="Régime"
                    /></span>
                    <span>
                        <q-input
                            v-model="owner.weddingContract.weddingContractDate"
                            label="Date de contrat"
                            title="Date de contrat"
                        >
                            <template v-slot:append>
                                <q-icon
                                    name="fal fa-calendar-alt"
                                    class="cursor-pointer"
                                >
                                    <q-popup-proxy
                                        ref="qDateProxy"
                                        transition-show="scale"
                                        transition-hide="scale"
                                    >
                                        <q-date
                                            v-model="
                                                owner.weddingContract
                                                    .weddingContractDate
                                            "
                                            mask="DD/MM/YYYY"
                                        />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input
                            v-model="
                                owner.weddingContract.weddingContractNotary
                            "
                            label="Reçu par"
                    /></span>
                </div>
            </div>
        </div>
        <div class="link" v-if="addOwner">
            <q-btn
                v-if="addStep < nbAddStep"
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Rechercher le propriétaire"
                v-on:click="searchOwnerExisting()"
            />
            <q-btn
                v-else
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Enregistrer"
                v-on:click="saveOwner()"
            />
            <q-btn
                class="button small right clear"
                unelevated
                color="grey"
                text-color="dark"
                label="Annuler"
                v-on:click="(addOwner = false), (addStep = 1)"
            />
        </div>
    </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../../../../store/index";
    import newFunctions from "../../../../utils/functions.js";
    import newFilter from "../../../../utils/filters.js";
    import addressInput from "../../../utils/addressInput";
    import cardOwner from "../../../../components/study/elements/cardOwner";

    export default {
        name: "editingOwners",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                currentStep: 1,
                nbStep: 1,
                addOwner: false,
                addStep: 2,
                nbAddStep: 2,
                functions: newFunctions,
                deleteOwnerInfo: "",
                confirm: false,
                isOwnerToUpdate: false,
                isOwnerAttachToProjectToUpdate: false,
                owners: null,
                owner: {
                    firstname: null,
                    lastname: null,
                    nationality: null,
                    mobile: null,
                    phone: null,
                    job: null,
                    email: null,
                    civility: null,
                    nationality: null,
                    civil: null,
                    birthdate: null,
                    maritalStatus: null,
                    address: null,
                    weddingContract: {
                        weddingDate: null,
                        matrimonialRegime: null,
                        weddingContractDate: null,
                        weddingContractNotary: null,
                    },
                },
                civilReferential: [],
                genderReferential: [],
            };
        },
        computed: {
            ...Vuex.mapGetters([
                "projectReferential",
                "projectCountry",
                "projectIsProjectsClusterLoaded",
                "referentialIsReferentialLoading",
            ]),
        },
        created() {
            this.init();
        },
        methods: {
            ...Vuex.mapActions[
                ("getPersonsByProjectIdAndPartnersType",
                "createAndAddPersonToProject",
                "getReferentialValues",
                "getPersonByEmail",
                "getProjectPersonByPersonIdAndProjectId",
                "updatePersonByPersonId",
                "attachPersonToProject",
                "getPersonById",
                "deleteProjectPerson")
            ],
            async init() {
                await this.getReferential();
                await this.getOwners();
            },
             getOwners() {
               return  Store.dispatch("getPersonsByProjectIdAndPartnersType", {
                    projectId: this.projectId,
                    partnerType: "owner",
                }).then(
                    (response) => {
                        this.owners = response.body;
                    },
                    (error) => {}
                );

            },
            getPersonById(personId) {
                Store.dispatch("getPersonById", {
                    personId: personId,
                }).then(
                    (response) => {
                        if (response.status == 200) {
                            this.owner = { ...this.owner, ...response.body };
                            if(this.owner.birthdate != null){
                                this.owner.birthdate = this.functions.dateConverter('decode', this.owner.birthdate)
                            }
                            if (
                                this.owner.maritalStatus != null
                            ) {
                                this.owner.maritalStatus = this.owner.maritalStatus.id;
                            }
                            if (this.owner.civility != null) {
                                this.owner.civility = this.owner.civility.id;
                            }
                            if(this.owner.weddingContract == null){
                                this.owner.weddingContract = {
                                    weddingDate: null,
                                    matrimonialRegime: null,
                                    weddingContractDate: null,
                                    weddingContractNotary: null,
                                }
                            }

                            this.isOwnerAttachToProjectToUpdate = true;
                            this.addStep = 2;
                            this.addOwner = true;
                        }
                    },
                    (error) => {}
                );
            },
            searchOwnerExisting() {
                Store.dispatch("getPersonByEmail", {
                    email: this.owner.email,
                }).then(
                    (response) => {
                        if (response.status == 200) {
                            let person = response.body;
                            Store.dispatch(
                                "getProjectPersonByPersonIdAndProjectId",
                                {
                                    projectId: this.projectId,
                                    personId: person.id,
                                }
                            ).then(
                                (response) => {
                                    if (response.status == 200) {
                                        var isAlreadyOwner = false;
                                        response.body.forEach((element) => {
                                            if (
                                                element.partnerType == "owner"
                                            ) {
                                                isAlreadyOwner = true;
                                            }
                                        });

                                        if (isAlreadyOwner) {
                                            this.$emit("send-notity", [
                                                "negative",
                                                "La personne recherchée est déjà propriétaire.",
                                            ]);
                                            this.addStep = 1;
                                            this.addOwner = false;
                                        } else {
                                            this.owner = {
                                                ...this.owner,
                                                ...person,
                                            };
                                            if(this.owner.birthdate != null){
                                                this.owner.birthdate = this.functions.dateConverter('decode', this.owner.birthdate)
                                            }
                                            if (
                                                this.owner.maritalStatus != null
                                            ) {
                                                this.owner.maritalStatus = this.owner.maritalStatus.id;
                                            }
                                            if (this.owner.civility != null) {
                                                this.owner.civility = this.owner.civility.id;
                                            }
                                            if(this.owner.weddingContract == null){
                                                this.owner.weddingContract = {
                                                    weddingDate: null,
                                                    matrimonialRegime: null,
                                                    weddingContractDate: null,
                                                    weddingContractNotary: null,
                                                }
                                            }
                                            this.addStep = 2;
                                            this.isOwnerToUpdate = true;
                                        }
                                    } else {
                                        this.$emit("send-notity", [
                                            "positive",
                                            "La personne recherchée a été trouvé, veuillez vérifier que les informations sont bonnes",
                                        ]);
                                        this.addStep = 2;
                                        this.isOwnerToUpdate = true;
                                    }
                                },
                                (error) => {}
                            );
                        } else {
                            this.$emit("send-notity", [
                                "warning",
                                "La personne recherchée n'existe pas dans notre base veuillez l'ajouter.",
                            ]);



                            this.addStep = 2;
                        }
                    },
                    (error) => {
                        this.owner.firstname = null;
                        this.owner.lastname = null;
                        this.owner.nationality = null;
                        this.owner.mobile = null;
                        this.owner.phone = null;
                        this.owner.job = null;
                        this.owner.civility = null;
                        this.owner.nationality = null;
                        this.owner.civil = null;
                        this.owner.birthdate = null;
                        this.owner.maritalStatus = null;
                        this.owner.address = null;
                        this.owner.weddingContract.weddingDate = null;
                        this.owner.weddingContract.matrimonialRegime = null;
                        this.owner.weddingContract.weddingContractDate = null;
                        this.owner.weddingContract.weddingContractNotary = null;
                        this.$emit("send-notity", [
                            "warning",
                            "La personne recherchée n'existe pas dans notre base veuillez l'ajouter.",
                        ]);
                        this.addStep = 2;
                    }
                );
            },
            updatePersonByPersonId() {
                console.log(this.owner.birthdate)
                this.owner.birthdate = this.functions.dateConverter('encode', this.owner.birthdate)
                console.log(this.owner.birthdate)
                Store.dispatch("updatePersonByPersonId", {
                    person: this.owner,
                }).then(
                    (response) => {
                        if (response.status == 200) {
                            if (!this.isOwnerAttachToProjectToUpdate) {
                                this.addProjectPersonByProjectIdAndPartnerType();
                            } else {
                                this.getOwners();
                                this.addStep = 1;
                                this.addOwner = false;
                                this.isOwnerAttachToProjectToUpdate = false;
                            }
                        }
                    },
                    (error) => {}
                );
            },
            addProjectPersonByProjectIdAndPartnerType() {
                Store.dispatch("attachPersonToProject", {
                    projectId: this.projectId,
                    personId: this.owner.id,
                    partnerType: "owner",
                }).then(
                    (response) => {
                        this.getOwners();
                        this.addStep = 1;
                        this.addOwner = false;
                        this.isOwnerToUpdate = false;
                    },
                    (error) => {}
                );
            },
            createOwnerToProject() {
                console.log(this.owner.birthdate)
                this.owner.birthdate = this.functions.dateConverter('encode', this.owner.birthdate)
                console.log(this.owner.birthdate)
                Store.dispatch("createAndAddPersonToProject", {
                    projectId: this.projectId,
                    body: {
                        partnerType: "owner",
                        person: this.owner,
                    },
                }).then(
                    (response) => {
                        if (response.status == 200) {
                        }
                        this.getOwners();
                        this.addStep = 1;
                        this.addOwner = false;
                    },
                    (error) => {}
                );
            },
            getReferential() {
                Store.dispatch("getReferentialValues", {
                    referentialId: "personCivility",
                }).then(
                    (response) => {
                        var vm = this;
                        response.body.forEach((element) => {
                            vm.genderReferential.push({
                                id: element.id,
                                value: element.frValue,
                            });
                        });
                    },
                    (error) => {}
                );

                Store.dispatch("getReferentialValues", {
                    referentialId: "personMaritalStatus",
                }).then(
                    (response) => {
                        var vm = this;
                        response.body.forEach((element) => {
                            vm.civilReferential.push({
                                id: element.id,
                                value: element.frValue,
                            });
                        });
                    },
                    (error) => {}
                );
            },
            deleteOwner(id){
                Store.dispatch("deleteProjectPerson", {
                    projectsPersonsId: id,
                }).then(
                    (response) => {
                        this.getOwners().finally( ()=>{
                                this.confirm = false
                            }
                        )
                    },
                    (error) => {}
                );
            },
            valideStatut(value) {
                return newFilter.getReferential(value, this.civilReferential)
                    .value;
            },
            changeAddress(address) {
                this.owner.address = address;
            },
            counterLabelFn({ totalSize, filesNumber, maxFiles }) {
                return `${filesNumber}/${maxFiles} - ${totalSize}`;
            },
            nextStep() {
                this.currentStep++;
            },
            previousStep() {
                this.currentStep--;
            },
            nextStepAddOwner() {
                this.addStep++;
            },
            previousStepAddOwner() {
                this.addStep--;
            },
            deleteOwnerFn(owner) {
                this.confirm = true;
            },
            annuleDeleteOwnerFn(e) {
                this.confirm = false;
            },
            saveOwner() {
                this.$refs.email.validate();
                this.$refs.lastname.validate();
                this.$refs.firstname.validate();
                this.$refs.birthdate.validate();
                this.$refs.mobile.validate();
                this.$refs.job.validate();
                this.$refs.maritalStatus.validate();
                // this.$refs.address.validate();
                if(this.owner.address ==null){
                    this.$q.notify({
                        type: 'warning',
                        message: `Vous devez rechercher et sélectionner une adresse pour continuer`
                    })
                }else{
                    if(this.owner.civility == null){
                        this.$q.notify({
                            type: 'warning',
                            message: `Vous devez sélectionner une civilité`
                        })


                    }else{
                        let regexp = new RegExp("^(?=\\d{2}([-.,\\/])\\d{2}\\1\\d{4}$)(?:0[1-9]|1\\d|[2][0-8]|29(?!.02.(?!(?!(?:[02468][1-35-79]|[13579][0-13-57-9])00)\\d{2}(?:[02468][048]|[13579][26])))|30(?!.02)|31(?=.(?:0[13578]|10|12))).(?:0[1-9]|1[012]).\\d{4}$")
                        if(!regexp.test(this.owner.birthdate)){
                            this.$q.notify({
                                type: 'warning',
                                message: `Vous devez inserer une bonne date de naissance`
                            })
                        }else{
                            if (
                                this.$refs.email.hasError ||
                                this.$refs.lastname.hasError ||
                                this.$refs.firstname.hasError ||
                                this.$refs.birthdate.hasError ||
                                this.$refs.mobile.hasError ||
                                this.$refs.job.hasError ||
                                this.$refs.maritalStatus.hasError
                            ) {
                            } else {
                                if (
                                    this.isOwnerToUpdate ||
                                    this.isOwnerAttachToProjectToUpdate
                                ) {
                                    this.updatePersonByPersonId();
                                } else {
                                    this.createOwnerToProject();
                                }
                            }
                        }

                    }

                }

            },
        },
        components: {
            cardOwner,
            addressInput,
        },
    };
</script>

<style lang="scss">
    @import "../../../../css/app";

    .editingOwners {
        .cards {
            overflow: hidden;
            padding: 0 15px 20px;
            margin: 0;

            .cardOwners {
                padding: 12px 0 0;
                width: 47.5%;
                float: left;
                margin: 0 5% 0 0;
                position: relative;

                &:nth-child(2n + 2) {
                    margin: 0;
                }

                .delete {
                    position: absolute;
                    top: 0;
                    right: 10px;
                }

                .edit {
                    position: absolute;
                    top: 0;
                    right: 44px;
                }
            }
        }

        .input {
            .input-col2 {
                span:last-child {
                    padding: 0 10px 0 0;
                }

                span:first-child {
                    padding: 0 0 0 10px;
                }

                .input-col2 {
                    span:first-child {
                        padding: 0 10px 0 0;
                    }

                    span:last-child {
                        padding: 0 0 0 10px;
                    }
                }

                .input-col3 {
                    span:first-child {
                        padding: 0 13px 0 0;
                    }

                    span:last-child {
                        padding: 0 0 0 13px;
                    }
                }
            }

            .col8 {
                float: right;
            }
        }

        @media screen and (max-width: 1450px) {
            .input {
                .input-col2 {
                    span:last-child {
                        padding: 0;
                    }

                    span:first-child {
                        padding: 0;
                    }
                }

                .col4 {
                    width: 100%;
                }

                .col8 {
                    width: 100%;
                }
            }
        }
    }
</style>
