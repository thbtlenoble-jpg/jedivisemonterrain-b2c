<template>
    <div class="sectorEditing">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Informations secteur
            <div class="stepAction">
                <span>{{currentStep}}</span>/{{nbStep}}
            </div>
        </div>
        <div class="form">
            <div class="answer">De quoi est composé le secteur ?</div>
            <div class="listBlocs">
                <div class="bloc" v-for="bloc in sectorReferential">
                    <div class="conteneur" :class="{ 'active': bloc.id == sectorEditing.type.id }" @click="sectorEditing.type.id = bloc.id">
                        <span v-html="bloc.value"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn v-if="currentStep > 1" class="button small left" unelevated color="grey" text-color="dark" label="Retour" v-on:click="previousStep()" />
            <q-btn v-if="currentStep < nbStep" class="button small right" unelevated color="primary" text-color="white" label="Suite de l'action" v-on:click="nextStep()" />
            <q-btn v-else class="button small right" unelevated color="primary" text-color="white" label="Terminer et fermer" v-on:click="createOrUpdateSectorToProject();$emit('returnAction', ['endAndClose'])" />
            <q-btn class="button small right clear" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions.js'

    export default {
        name: "sectorEditing",
        props: ["valuesEditing","projectId"],
        data(){
            return{
                currentStep: 1,
                nbStep: 1,
                functions: newFunctions,
                sectorReferential : [],
                sectorEditing:{
                    type : {
                        id : null
                    }
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded',
                'referentialIsReferentialLoading'
            ])
        },

        created(){
            this.init()
        },
        methods : {

            ...Vuex.mapActions["getReferentialValues","createOrUpdateSectorByProjectId","getSectorByProjectId"],

            async init(){
                await this.getReferential()
                await  this.getSectorByIdProject()
            },
            getReferential() {
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'sectorType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.sectorReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    }
                )
            },
            getSectorByIdProject(){
                Store.dispatch('getSectorByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.sectorEditing = {...this.sectorEditing,...response.body}
                            if(this.sectorEditing.type === null){
                                this.sectorEditing.type = {id : null}
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            createOrUpdateSectorToProject(){
                Store.dispatch('createOrUpdateSectorByProjectId', {projectId: this.projectId,sector : this.sectorEditing}).then(
                    response => {

                    },
                    error => {

                    }
                )
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .sectorEditing{

    }

</style>
