<template>
    <div class="sectorPreview">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['sector', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Informations secteur
        </div>
        <div class="responses" v-if="1 == 1">
            <div class="bloc">
                <div class="answer"><span>1.</span> De quoi est composé le secteur ?</div>
                <div class="response" :inner-html.prop="sectorPreview.type.frValue" v-if="sectorPreview.type.id != null"></div>
                <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'

    export default {
        name: "sectorPreview",
        props: ["valuesPreview", "projectId"],
        data(){
            return{
                sectorPreview : {
                    type : {
                        id : null
                    }
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded',
                'referentialIsReferentialLoading'

            ])
        },
        created(){
          this.init()
        },
        methods:{
            ...Vuex.mapActions["getReferentialValues","getSectorByProjectId"],

            async init(){
                await  this.getSectorByIdProject()
            },
            getSectorByIdProject(){
                Store.dispatch('getSectorByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.sectorPreview = {...this.sectorPreview,...response.body}
                        }
                    },
                    error => {

                    }
                )
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .sectorPreview{

    }

</style>
