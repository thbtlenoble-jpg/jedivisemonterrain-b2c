<template>
    <div class="previewMarket">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['market', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Données marché
        </div>
        <div class="responses" v-if="1==1">
            <div class="bloc">
                <div class="answer"><span>1.</span> Quel est le marché qui avoisine la parcelle ?</div>
                <div class="response" :inner-html.prop="marketPreview.type.frValue" v-if="marketPreview.type.id != null"></div>
                <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
            <div class="bloc">
                <div class="answer"><span>2.</span> Quel est le type de construction approprié ?</div>
                <div v-if="marketPreview.constructionType.id != null">
                    <div class="response" :inner-html.prop="marketPreview.constructionType.frValue"></div>
<!--                    <div v-for="offer in projectBuilder.offers" v-if="offer.type == valuesPreview.construct">-->
<!--                        <span class="picture" :style="{ backgroundImage: 'url(' + offer.picture + ')' }"></span>-->
<!--                        <div class="price">{{offer.price | formatPriceInteger}} €/m²</div>-->
<!--                    </div>-->
                </div>
                <div class="empty"v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions'

    export default {
        name: "previewMarket",
        props: ["valuesPreview", "projectId"],
        data(){
            return{
                functions: newFunctions,
                marketPreview : {
                    type: {
                        id : null
                    },
                    constructionType : {
                        id : null
                    }
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectBuilder',
                'projectIsProjectsClusterLoaded',
                'referentialIsReferentialLoading'
            ])
        },
        created(){
          this.init()
        },
        methods:{
            ...Vuex.mapActions["getMarketByProjectId"],

            async init(){
                await  this.getMarketByIdProject()
            },

            getMarketByIdProject(){
                Store.dispatch('getMarketByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.marketPreview = {...this.marketPreview,...response.body}
                        }
                    },
                    error => {

                    }
                )
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .previewMarket {

        .bloc{

            .picture{
                margin: 10px 0;
                width: 100%;
                padding: 60% 0 0 0;
                background-position: center;
                background-size: cover;
                display: block;
                border-radius: 5px;
            }

            .price{
                text-align: right;
                font-size: 12px;
            }

        }

    }
</style>
