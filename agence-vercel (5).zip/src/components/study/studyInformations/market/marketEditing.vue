<template>
    <div class="editingMarket">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Données marché
            <div class="stepAction">
                <span>{{currentStep}}</span>/{{nbStep}}
            </div>
        </div>
        <div class="form" v-if="currentStep == 1">
            <div class="answer">Quel est le marché qui avoisine la parcelle ?</div>
            <div class="listBlocs">
                <div class="bloc" v-for="bloc in typeReferential">
                    <div class="conteneur" :class="{ 'active': bloc.id == marketEditing.type.id }" @click="marketEditing.type.id = bloc.id">
                        <span v-html="bloc.value"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 2">
            <div class="answer">Quel est le type de construction approprié ?</div>
            <div class="listBlocs">
                <div class="bloc" v-for="bloc in constructionTypeReferential">
                    <div class="conteneur" :class="{ 'active': bloc.id == marketEditing.constructionType.id }" @click="marketEditing.constructionType.id = bloc.id">
                        <span v-html="bloc.value"></span>
                    </div>
                </div>
            </div>
<!--            <div class="listBlocs">-->
<!--                <div class="bloc" v-for="bloc in functions.getAllReferentialAction('construct', projectReferential)" :class="{ 'active': bloc.id == valuesEditing.construct }">-->
<!--                    <div v-for="offer in projectBuilder.offers" v-if="offer.type == bloc.id">-->
<!--                        <span class="picture" :style="{ backgroundImage: 'url(' + offer.picture + ')' }"></span>-->
<!--                        <div class="price">{{offer.price | formatPriceInteger}} €/m²</div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
        </div>
        <div class="link">
            <q-btn v-if="currentStep > 1" class="button small left" unelevated color="grey" text-color="dark" label="Retour" v-on:click="previousStep()" />
            <q-btn v-if="currentStep < nbStep" class="button small right" unelevated color="primary" text-color="white" label="Suite de l'action" v-on:click="nextStep()" />
            <q-btn v-else class="button small right" unelevated color="primary" text-color="white" label="Terminer et fermer" v-on:click="createOrUpdateMarketToProject();$emit('returnAction', ['endAndClose'])" />
            <q-btn class="button small right clear" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions.js'

    export default {
        name: "editingMarket",
        props: ["valuesEditing","projectId"],
        data(){
            return{
                currentStep: 1,
                nbStep: 2,
                functions: newFunctions,
                typeReferential : [],
                constructionTypeReferential : [],
                marketEditing : {
                    type: {
                        id : null
                    },
                    constructionType : {
                        id : null
                    }
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectBuilder',
                'referentialIsReferentialLoading',
                'projectIsProjectsClusterLoaded'
            ])
        },
        created(){
          this.init()
        },
        methods:{
            ...Vuex.mapActions["getReferentialValues","createOrUpdateMarketByProjectId","getMarketByProjectId"],

            async init(){
                await this.getReferential()
                await  this.getMarketByIdProject()
            },
            getReferential() {
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'marketType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.typeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    }
                )

                Store.dispatch('getReferentialValues', {referentialId: 'marketConstructionType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.constructionTypeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    }
                )
            },
            getMarketByIdProject(){
                Store.dispatch('getMarketByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.marketEditing = {...this.marketEditing,...response.body}
                            if(this.marketEditing.type === null){
                                this.marketEditing.type = {id : null}
                            }
                            if(this.marketEditing.constructionType === null){
                                this.marketEditing.constructionType = {id : null}
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            createOrUpdateMarketToProject(){
                Store.dispatch('createOrUpdateMarketByProjectId', {projectId: this.projectId,market : this.marketEditing}).then(
                    response => {

                    },
                    error => {

                    }
                )
            },

            nextStep(){
                this.currentStep++
            },
            previousStep(){
                this.currentStep--
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .editingMarket {

        .bloc{

            .picture{
                width: 100%;
                padding: 65% 0 0 0;
                background-position: center;
                background-size: cover;
                display: block;
                border-radius: 5px;
            }

            .price{
                text-align: right;
                padding: 5px 0 0 0;
                font-size: 12px;
                transition: all .2s ease;
            }

            &.active{

                .price{
                    color: $blue00;
                    font-weight: 600;
                }

            }

        }

    }
</style>
