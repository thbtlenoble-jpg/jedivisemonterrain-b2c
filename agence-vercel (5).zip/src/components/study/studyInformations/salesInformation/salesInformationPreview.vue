<template>
    <div class="salesInformationPreview">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['salesInformation', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Informations sur la vente
        </div>
        <div class="responses" v-if="state != 'empty'">
            <div class="bloc">
                <div class="answer"><span>1.</span> Des informations nécessaires à l'élaboration du dossier de valorisation</div>
                <div class="response">
                    <span class="regular">Le bien a-t-il déjà été mis en vente ?</span>
                    <div class="arrow" v-if="salePropertyPreview.wasInSale != null">
                        <div v-if="salePropertyPreview.wasInSale"><i class="fal fa-check yes"></i> Oui</div>
                        <div v-else><i class="fal fa-times no"></i> Non</div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.wasInSaleDate == null }"></i>
                            <div class="table">
                                <span>Depuis quand : </span>
                                <div v-if="salePropertyPreview.wasInSaleDate != null">{{salePropertyPreview.wasInSaleDate | dateFormat('type1')}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.price == '' || salePropertyPreview.price == null }"></i>
                            <div class="table">
                                <span>A quel prix : </span>
                                <div v-if="salePropertyPreview.price != '' || salePropertyPreview.price !== null">{{salePropertyPreview.price | formatPriceInteger}} €</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.estimation == '' || salePropertyPreview.estimation == null }"></i>
                            <div class="table">
                                <span>Estimation : </span>
                                <div v-if="salePropertyPreview.estimation != '' || salePropertyPreview.estimation !== null">{{salePropertyPreview.estimation | formatPriceInteger}} €</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.result == '' || salePropertyPreview.result == null }"></i>
                            <div class="table">
                                <span>Résultat obtenu : </span>
                                <div v-if="salePropertyPreview.result != ''">{{salePropertyPreview.result}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.ownerStatus == null }"></i>
                            <div class="table">
                                <span>Statut du propriétaire : </span>
                                <div v-if="salePropertyPreview.ownerStatus != null">{{salePropertyPreview.ownerStatus | getReferential(statusReferential).value}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="salePropertyPreview.wasInSale && valideStatut(salePropertyPreview.ownerStatus) == 'Professionnel'">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': salePropertyPreview.companyType == null }"></i>
                            <div class="table">
                                <span>Type de société : </span>
                                <div v-if="salePropertyPreview.companyType != null">{{salePropertyPreview.companyType | getReferential(companyTypeReferential).value}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions'
    import newFilter from '../../../../utils/filters.js'
    import config from '../../../../utils/config.js'

    export default {
        name: "salesInformationPreview",
        props: ["valuesPreview", "state", "projectId"],
        data(){
            return{
                functions: newFunctions,
                statusReferential: [],
                companyTypeReferential: [],
                salePropertyPreview: {
                    wasInSale: null,
                    wasInSaleDate: null,
                    price: null,
                    estimation: null,
                    result: null,
                    ownerStatus: null,
                    companyType: null

                },
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectBuilder',
                'projectIsProjectsClusterLoaded',
                'referentialIsReferentialLoading'
            ])
        },
        created(){
          this.init()
        },
        methods:{
            ...Vuex.mapActions(["getSalePropertyByProjectId","getReferentialValues"]),
            async init() {
                let vm = this
                await this.getReferential()
                await this.getSalePropertyByProjectId()

            },
            getReferential() {
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'salePropertyOwnerStatus'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.statusReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )

                Store.dispatch('getReferentialValues', {referentialId: 'salePropertyCompanyType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.companyTypeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )

            },
            getSalePropertyByProjectId(){

                Store.dispatch('getSalePropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.salePropertyPreview = {...this.salePropertyPreview,...response.body}
                            if(this.salePropertyPreview.companyType != null){
                                this.salePropertyPreview.companyType = this.salePropertyPreview.companyType.id
                            }
                            if(this.salePropertyPreview.ownerStatus != null){
                                this.salePropertyPreview.ownerStatus = this.salePropertyPreview.ownerStatus.id
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            valideStatut(value) {
                return newFilter.getReferential(value, this.statusReferential).value
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .salesInformationPreview {

    }
</style>
