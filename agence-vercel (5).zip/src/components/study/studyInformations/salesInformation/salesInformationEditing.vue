<template>
    <div class="salesInformationEditing">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Informations sur la vente
            <div class="stepAction">
                <span>{{currentStep}}</span>/{{nbStep}}
            </div>
        </div>
        <div class="form">
            <div class="answer">Des informations nécessaires à l'élaboration du dossier de valorisation</div>
            <div class="input">
                <div class="input-col1">
                    <span>
                        <q-toggle indeterminate-value="null" v-model="salePropertyEditing.wasInSale" left-label
                                  label="Le bien a-t-il déjà été mis en vente ?"/>
                    </span>
                </div>
                <div class="input-col3" v-if="salePropertyEditing.wasInSale">
                    <span>
                        <q-input v-model="salePropertyEditing.wasInSaleDate" label="Depuis quand ?">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="salePropertyEditing.wasInSaleDate" mask="DD/MM/YYYY"/>
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input v-model="salePropertyEditing.price" mask="### ### ###" input-class="text-right"
                                 label="A quel prix ?">
                            <template v-slot:append>
                                <q-icon name="fas fa-euro-sign"/>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input v-model="salePropertyEditing.estimation" title="Comment le bien a-t-il été estimé ?"
                                 mask="### ### ###" input-class="text-right"
                                 label="Comment le bien a-t-il été estimé ?">
                            <template v-slot:append>
                                <q-icon name="fas fa-euro-sign"/>
                            </template>
                        </q-input>
                    </span>
                </div>
                <div :class="{ 'input-col3' : valideStatut(salePropertyEditing.ownerStatus) == 'Professionnel', 'input-col2' : valideStatut(salePropertyEditing.ownerStatus) != 'Professionnel' }"
                     v-if="salePropertyEditing.wasInSale">
                    <span><q-input v-model="salePropertyEditing.result" title="Quel résultat avez-vous obtenu ?"
                                   label="Quel résultat avez-vous obtenu ?"/></span>
                    <span>
                        <q-select v-model="salePropertyEditing.ownerStatus" option-value="id" emit-value map-options
                                  option-label="value" :options="statusReferential" label="Statut du propriétaire"/>
                    </span>
                    <span v-if="valideStatut(salePropertyEditing.ownerStatus) == 'Professionnel'">
                        <q-select v-model="salePropertyEditing.companyType" option-value="id" emit-value map-options
                                  option-label="value" :options="companyTypeReferential" label="Type de société"/>
                    </span>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn v-if="currentStep > 1" class="button small left" unelevated color="grey" text-color="dark"
                   label="Retour" v-on:click="previousStep()"/>
            <q-btn v-if="currentStep < nbStep" class="button small right" unelevated color="primary" text-color="white"
                   label="Suite de l'action" v-on:click="nextStep()"/>
            <q-btn v-else class="button small right" unelevated color="primary" text-color="white"
                   label="Terminer et fermer" v-on:click="addOrCreateSalePropertyToProject();$emit('returnAction', ['endAndClose'])"/>
            <q-btn class="button small right clear" unelevated color="grey" text-color="dark" label="Fermer"
                   v-on:click="endVisibility(); $emit('returnAction', ['close'])"/>
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions.js'
    import newFilter from '../../../../utils/filters.js'
    import config from '../../../../utils/config.js'

    export default {
        name: "salesInformationEditing",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                currentStep: 1,
                nbStep: 1,
                functions: newFunctions,
                statusReferential: [],
                companyTypeReferential: [],
                salePropertyEditing: {
                    wasInSale: null,
                    wasInSaleDate: null,
                    price: null,
                    estimation: null,
                    result: null,
                    ownerStatus: null,
                    companyType: null

                },
                societyTypeReferential: [],

            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'referentialIsReferentialLoading'
            ])
        },
        created() {
            this.init()
        },
        methods: {
            ...Vuex.mapActions["getReferentialValues", "addOrUpdateSalePropertyToProject","getSalePropertyByProjectId",'projectIsProjectsClusterLoaded'],

            async init() {
                let vm = this
                await this.getReferential()
                await this.getSalePropertyByProjectId()


            },
             getReferential() {
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'salePropertyOwnerStatus'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.statusReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'salePropertyCompanyType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.companyTypeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    }
                )

            },
            getSalePropertyByProjectId(){

                Store.dispatch('getSalePropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.salePropertyEditing = {...this.salePropertyEditing,...response.body}
                            if(this.salePropertyEditing.companyType != null){
                                this.salePropertyEditing.companyType = this.salePropertyEditing.companyType.id
                            }
                            if(this.salePropertyEditing.ownerStatus != null){
                                this.salePropertyEditing.ownerStatus = this.salePropertyEditing.ownerStatus.id
                            }
                            // Formatage des dates pour l'affichage
                            if (this.salePropertyEditing.wasInSaleDate != null) {
                                this.salePropertyEditing.wasInSaleDate = newFunctions.dateConverter('decode', this.salePropertyEditing.wasInSaleDate)
                            }

                        }
                    },
                    error => {

                    }
                )
            },
            addOrCreateSalePropertyToProject(){
                this.endVisibility()
                Store.dispatch('addOrUpdateSalePropertyToProject',{projectId : this.projectId, saleProperty : this.salePropertyEditing}).then(
                    response => {
                    },
                    error => {
                    }
                )
            },
            endVisibility() {
                // Formatage des dates pour l'affichage
                if (this.salePropertyEditing.wasInSaleDate != null) {
                    this.salePropertyEditing.wasInSaleDate = newFunctions.dateConverter('encode', this.salePropertyEditing.wasInSaleDate)
                }
                if(this.salePropertyEditing.price != null & typeof this.salePropertyEditing.price == "string"){
                    this.salePropertyEditing.price = this.salePropertyEditing.price.replace(/ /g,'')
                    this.salePropertyEditing.price = parseInt(this.salePropertyEditing.price,10)
                }
                if(this.salePropertyEditing.estimation != null & typeof this.salePropertyEditing.estimation == "string"){
                    this.salePropertyEditing.estimation = this.salePropertyEditing.estimation.replace(/ /g,'')
                    this.salePropertyEditing.estimation = parseInt(this.salePropertyEditing.estimation,10)
                }

            },
            valideStatut(value) {
                return newFilter.getReferential(value, this.statusReferential).value
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .salesInformationEditing {

    }

</style>
