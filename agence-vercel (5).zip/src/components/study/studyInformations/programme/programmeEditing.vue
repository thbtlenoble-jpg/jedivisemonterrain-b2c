<template>
    <div class="programmeEditing">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Programme
            <div class="stepAction">
                <span>{{currentStep}}</span>/{{nbStep}}
            </div>
        </div>
        <div class="form">
            <div class="answer">Quel est le type de maison approprié ?</div>
            <div class="boxed">
                <div class="slider">
                    <div class="title">Surface habitable préconisée</div>
                    <q-range
                        v-model="floorSpaceValue" color="primary" :min="habitability[0]" :max="habitability[1]"
                        :left-label-value="formatNull(floorSpaceValue.min, habitability[0]) + ' m²'"
                        :right-label-value="formatNull(floorSpaceValue.max, habitability[1]) + ' m²'"
                        :left-label-color="colorNull(floorSpaceValue.min, habitability[0])" :right-label-color="colorNull(floorSpaceValue.max, habitability[1])"
                        label-always drag-range :step="5"
                    />
                </div>
                <div class="slider">
                    <div class="title">Surface de garage préconisée</div>
                    <q-range
                        v-model="garageAreaValue" color="primary" :min="garage[0]" :max="garage[1]"
                        :left-label-value="formatNull(garageAreaValue.min, garage[0]) + ' m²'"
                        :right-label-value="formatNull(garageAreaValue.max, garage[1]) + ' m²'"
                        :left-label-color="colorNull(garageAreaValue.min, garage[0])" :right-label-color="colorNull(garageAreaValue.max, garage[1])"
                        label-always drag-range
                    />
                </div>
                <div class="slider">
                    <div class="title">Surface de terrain préconisée</div>
                    <q-range
                        v-model="landSurfaceValue" color="primary" :min="terrain[0]" :max="terrain[1]"
                        :left-label-value="formatNull(landSurfaceValue.min, terrain[0]) + ' m²'"
                        :right-label-value="formatNull(landSurfaceValue.max, terrain[1]) + ' m²'"
                        :left-label-color="colorNull(landSurfaceValue.min, terrain[0])" :right-label-color="colorNull(landSurfaceValue.max, terrain[1])"
                        label-always drag-range :step="10"
                    />
                </div>
                <div class="input-col1">
                    <q-input v-model="programmEditing.estimation" mask="##########" input-class="text-right" label="Prix de vente préconisé pour ce programme">
                        <template v-slot:append>
                            <q-icon name="fas fa-euro-sign" />
                        </template>
                    </q-input>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn v-if="currentStep > 1" class="button small left" unelevated color="grey" text-color="dark" label="Retour" v-on:click="previousStep()" />
            <q-btn v-if="currentStep < nbStep" class="button small right" unelevated color="primary" text-color="white" label="Suite de l'action" v-on:click="nextStep()" />
            <q-btn v-else class="button small right" unelevated color="primary" text-color="white" label="Terminer et fermer" v-on:click="createOrUpdateProgrammToProject();$emit('returnAction', ['endAndClose'])" />
            <q-btn class="button small right clear" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions.js'

    export default {
        name: "programmeEditing",
        props: ["valuesEditing", "projectId"],
        data(){
            return{
                currentStep: 1,
                nbStep: 1,
                functions: newFunctions,
                habitability: [0, 200],
                garage: [0, 50],
                terrain: [0, 1000],
                floorSpaceValue : {
                    min : null,
                    max : null
                },
                garageAreaValue :  {
                    min : null,
                    max : null
                },
                landSurfaceValue :  {
                    min : null,
                    max : null
                },
                programmEditing : {
                    floorSpaceMin : null,
                    floorSpaceMax : null,
                    garageAreaMin : null,
                    garageAreaMax:  null,
                    landSurfaceMin : null,
                    landSurfaceMax : null,
                    estimation : null
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded'
            ])
        },
        created(){
            this.init()
        },
        methods: {
            ...Vuex.mapActions["createOrUpdateProgrammByProjectId","getProgrammByProjectId"],

            async init(){
                await  this.getProgrammByIdProject()
            },
            getProgrammByIdProject(){
                Store.dispatch('getProgrammByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.programmEditing = {...this.programmEditing,...response.body}
                            this.bindDataToValue()
                        }
                    },
                    error => {

                    }
                )
            },
            createOrUpdateProgrammToProject(){
               this.bindDataToProgrammEdit()
                Store.dispatch('createOrUpdateProgrammByProjectId', {projectId: this.projectId,programm : this.programmEditing}).then(
                    response => {

                    },
                    error => {

                    }
                )
            },
            bindDataToProgrammEdit(){
                if(this.programmEditing.estimation != null & typeof this.programmEditing.estimation == "string"){
                    this.programmEditing.estimation = this.programmEditing.estimation.replace(/ /g,'','')
                    console.log(this.programmEditing.estimation)
                    this.programmEditing.estimation = parseInt(this.programmEditing.estimation,10)
                }
                this.programmEditing.floorSpaceMin = this.floorSpaceValue.min
                this.programmEditing.floorSpaceMax = this.floorSpaceValue.max
                this.programmEditing.garageAreaMin = this.garageAreaValue.min
                this.programmEditing.garageAreaMax = this.garageAreaValue.max
                this.programmEditing.landSurfaceMin = this.landSurfaceValue.min
                this.programmEditing.landSurfaceMax = this.landSurfaceValue.max
            },

            bindDataToValue(){
                this.floorSpaceValue.min = this.programmEditing.floorSpaceMin
                this.floorSpaceValue.max = this.programmEditing.floorSpaceMax
                this.garageAreaValue.min = this.programmEditing.garageAreaMin
                this.garageAreaValue.max = this.programmEditing.garageAreaMax
                this.landSurfaceValue.min = this.programmEditing.landSurfaceMin
                this.landSurfaceValue.max = this.programmEditing.landSurfaceMax
            },
            formatNull(val, min) {
                if(val == null){
                    return '---'
                } else {
                    return val
                }
            },
            colorNull(val, min) {
                if(val == null){
                    return 'blue-grey'
                } else {
                    return 'dark'
                }
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .programmeEditing{

        .boxed{
            padding-bottom: 20px;
        }

    }

</style>
