<template>
    <div class="programmePreview">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['programme', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Programme
        </div>
        <div class="responses" v-if="1==1">
            <div class="bloc">
                <div class="answer"><span>1.</span> Quel est le type de maison approprié ?</div>
                <div class="response">
                    <span class="regular">Surface habitable préconisée</span>
                    <div class="arrow" v-if="programmPreview.floorSpaceMin != null || programmPreview.floorSpaceMax != null">
                        <i class="fal fa-arrow-alt-right"></i> {{programmPreview.floorSpaceMin}} m² - {{programmPreview.floorSpaceMax}} m²
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Surface de garage préconisée</span>
                    <div class="arrow" v-if="programmPreview.garageAreaMin != null || programmPreview.garageAreaMax != null">
                        <i class="fal fa-arrow-alt-right"></i> {{programmPreview.garageAreaMin}} m² - {{programmPreview.garageAreaMax}} m²
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Surface de terrain préconisée</span>
                    <div class="arrow" v-if="programmPreview.landSurfaceMin != null || programmPreview.landSurfaceMax != null">
                        <i class="fal fa-arrow-alt-right"></i> {{programmPreview.landSurfaceMin}} m² - {{programmPreview.landSurfaceMax}} m²
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Prix de vente préconisé pour ce programme</span>
                    <div class="arrow" v-if="programmPreview.estimation != null">
                        <i class="fal fa-arrow-alt-right"></i> {{programmPreview.estimation | formatPriceInteger}} €
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'

    export default {
        name: "programmePreview",
        props: ["valuesPreview", "projectId"],
        data(){
            return{
                programmPreview : {
                    floorSpaceMin : null,
                    floorSpaceMax : null,
                    garageAreaMin : null,
                    garageAreaMax:  null,
                    landSurfaceMin : null,
                    landSurfaceMax : null,
                    estimation: null
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded'
            ])
        },
        created(){
          this.init()
        },
        methods:{
            ...Vuex.mapActions["getProgrammByProjectId"],

            async init(){
                await  this.getProgrammByIdProject()
            },

            getProgrammByIdProject(){
                Store.dispatch('getProgrammByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.programmPreview = {...this.programmPreview,...response.body}
                        }
                    },
                    error => {

                    }
                )
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .programmePreview{

    }

</style>
