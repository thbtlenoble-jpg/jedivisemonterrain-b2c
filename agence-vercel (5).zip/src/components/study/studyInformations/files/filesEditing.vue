<template>
    <div class="editingFiles">
        <q-inner-loading
            :showing="
                projectIsProjectsClusterLoaded ||
                referentialIsReferentialLoading
            "
        >
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Documents
            <div class="stepAction">
                <span>{{ currentStep }}</span
                >/{{ nbStep }}
            </div>
        </div>
        <div class="form" v-if="currentStep == 1">
            <div class="answer">Ajout des documents propriétaires et biens</div>
            <div class="input">
                <div class="input-col3">
                    <span class="files">
                        <file-uploader
                            v-bind:projectId="projectId"
                            v-bind:options="filesPropertyTitleOptions"
                            v-on:getFiles="getFiles"
                        ></file-uploader>

                        <div v-if="filesPropertyTitleList == null">
                            <a
                                @click="noDocument('properties')"
                                class="noDocument"
                                >Pas de documents ?</a
                            >
                        </div>
                        <div v-else-if="filesPropertyTitleList.length == 0">
                            <span class="empty"
                                >Il n'y a pas de titre de propriété</span
                            >
                        </div>
                        <q-list v-else>
                            <q-item
                                v-for="(file, index) in filesPropertyTitleList"
                                :key="index"
                                class="file no-padding"
                            >
                                <q-item-section avatar top class="icon">
                                    <q-icon
                                        name="fal fa-file-pdf"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'pdf'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-word"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'doc'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-image"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'img'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'file'
                                        "
                                    />
                                </q-item-section>
                                <q-item-section top class="infos">
                                    <div class="name">
                                        <a
                                            :href="file.myFile.fileUrl"
                                            target="_blank"
                                            >{{ file.myFile.fileName }}</a
                                        >
                                        <span
                                            >Ajouté le
                                            {{
                                                file.myFile.creation
                                                    | dateFormat("type2")
                                            }}</span
                                        >
                                    </div>
                                </q-item-section>
                                <q-item-section top side class="button">
                                    <q-btn
                                        class="button minSmall round"
                                        color="grey"
                                        text-color="dark"
                                        unelevated
                                        icon="fal fa-times"
                                        @click="
                                            deleteFileFn(file, [
                                                file.myFile.fileName,
                                                'titre de propriété',
                                            ])
                                        "
                                    />
                                </q-item-section>
                            </q-item>
                        </q-list>
                        <q-dialog v-model="confirm" persistent>
                            <q-card>
                                <q-card-section>
                                    <q-card-section class="q-pt-xs">
                                        <div class="text-overline text-primary">
                                            Suppréssion {{ fileInfosDelete[1] }}
                                        </div>
                                        <div class="text-h5">
                                            {{ fileInfosDelete[0] }}
                                        </div>
                                        <div class="text-h7">
                                            Vous êtes sur le point de supprimer
                                            un fichier, une fois validé vous ne
                                            pourrez plus revenir en arrière.
                                        </div>
                                    </q-card-section>
                                </q-card-section>
                                <q-card-actions align="right" class="bg-grey">
                                    <q-btn
                                        flat
                                        label="Annuler"
                                        class="button small"
                                        color="gray"
                                        v-close-popup
                                        @click="annuleDeleteFileFn"
                                    />
                                    <q-btn
                                        unelevated
                                        label="Valider la suppression"
                                        class="button small"
                                        color="primary"
                                        v-close-popup
                                        @click="valideDeleteFileFn(fileDelete)"
                                    />
                                </q-card-actions>
                            </q-card>
                        </q-dialog>
                    </span>
                    <span class="files">
                        <file-uploader
                            v-bind:projectId="projectId"
                            v-bind:options="filesServitudesOptions"
                            v-on:getFiles="getFiles"
                        ></file-uploader>
                        <div v-if="filesServitudesList == null">
                            <a
                                @click="noDocument('servitude')"
                                class="noDocument"
                                >Pas de documents ?</a
                            >
                        </div>
                        <div v-else-if="filesServitudesList.length == 0">
                            <span class="empty">Il n'y a pas de servitude</span>
                        </div>
                        <q-list v-else>
                            <q-item
                                v-for="(file, index) in filesServitudesList"
                                :key="index"
                                class="file no-padding"
                            >
                                <q-item-section avatar top class="icon">
                                    <q-icon
                                        name="fal fa-file-pdf"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'pdf'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-word"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'doc'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-image"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'img'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'file'
                                        "
                                    />
                                </q-item-section>
                                <q-item-section top class="infos">
                                    <div class="name">
                                        <a
                                            :href="file.myFile.fileUrl"
                                            target="_blank"
                                            >{{ file.myFile.fileName }}</a
                                        >
                                        <span
                                            >Ajouté le
                                            {{
                                                file.myFile.creation
                                                    | dateFormat("type2")
                                            }}</span
                                        >
                                    </div>
                                </q-item-section>
                                <q-item-section top side class="button">
                                    <q-btn
                                        class="button minSmall round"
                                        color="grey"
                                        text-color="dark"
                                        unelevated
                                        icon="fal fa-times"
                                        @click="
                                            deleteFileFn(file, [
                                                file.myFile.fileName,
                                                'servitude',
                                            ])
                                        "
                                    />
                                </q-item-section>
                            </q-item>
                        </q-list>
                        <q-dialog v-model="confirm" persistent>
                            <q-card>
                                <q-card-section>
                                    <q-card-section class="q-pt-xs">
                                        <div class="text-overline text-primary">
                                            Suppréssion {{ fileInfosDelete[1] }}
                                        </div>
                                        <div class="text-h5">
                                            {{ fileInfosDelete[0] }}
                                        </div>
                                        <div class="text-h7">
                                            Vous êtes sur le point de supprimer
                                            un fichier, une fois validé vous ne
                                            pourrez plus revenir en arrière.
                                        </div>
                                    </q-card-section>
                                </q-card-section>
                                <q-card-actions align="right" class="bg-grey">
                                    <q-btn
                                        flat
                                        label="Annuler"
                                        class="button small"
                                        color="gray"
                                        v-close-popup
                                        @click="annuleDeleteFileFn"
                                    />
                                    <q-btn
                                        unelevated
                                        label="Valider la suppression"
                                        class="button small"
                                        color="primary"
                                        v-close-popup
                                        @click="valideDeleteFileFn(fileDelete)"
                                    />
                                </q-card-actions>
                            </q-card>
                        </q-dialog>
                    </span>
                    <span class="files">
                        <file-uploader
                            v-bind:projectId="projectId"
                            v-bind:options="filesSoilSurveyOptions"
                            v-on:getFiles="getFiles"
                        ></file-uploader>
                        <div v-if="filesSoilSurveyList == null">
                            <a
                                @click="noDocument('etudesSols')"
                                class="noDocument"
                                >Pas de documents ?</a
                            >
                        </div>
                        <div v-else-if="filesSoilSurveyList.length == 0">
                            <span class="empty"
                                >Il n'y a pas d'étude de sols</span
                            >
                        </div>
                        <q-list v-else>
                            <q-item
                                v-for="(file, index) in filesSoilSurveyList"
                                :key="index"
                                class="file no-padding"
                            >
                                <q-item-section avatar top class="icon">
                                    <q-icon
                                        name="fal fa-file-pdf"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'pdf'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-word"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'doc'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-image"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'img'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'file'
                                        "
                                    />
                                </q-item-section>
                                <q-item-section top class="infos">
                                    <div class="name">
                                        <a
                                            :href="file.myFile.fileUrl"
                                            target="_blank"
                                            >{{ file.myFile.fileName }}</a
                                        >
                                        <span
                                            >Ajouté le
                                            {{
                                                file.myFile.creation
                                                    | dateFormat("type2")
                                            }}</span
                                        >
                                    </div>
                                </q-item-section>
                                <q-item-section top side class="button">
                                    <q-btn
                                        class="button minSmall round"
                                        color="grey"
                                        text-color="dark"
                                        unelevated
                                        icon="fal fa-times"
                                        @click="
                                            deleteFileFn(file, [
                                                file.myFile.fileName,
                                                'étude du sol',
                                            ])
                                        "
                                    />
                                </q-item-section>
                            </q-item>
                        </q-list>
                        <q-dialog v-model="confirm" persistent>
                            <q-card>
                                <q-card-section>
                                    <q-card-section class="q-pt-xs">
                                        <div class="text-overline text-primary">
                                            Suppréssion {{ fileInfosDelete[1] }}
                                        </div>
                                        <div class="text-h5">
                                            {{ fileInfosDelete[0] }}
                                        </div>
                                        <div class="text-h7">
                                            Vous êtes sur le point de supprimer
                                            un fichier, une fois validé vous ne
                                            pourrez plus revenir en arrière.
                                        </div>
                                    </q-card-section>
                                </q-card-section>
                                <q-card-actions align="right" class="bg-grey">
                                    <q-btn
                                        flat
                                        label="Annuler"
                                        class="button small"
                                        color="gray"
                                        v-close-popup
                                        @click="annuleDeleteFileFn"
                                    />
                                    <q-btn
                                        unelevated
                                        label="Valider la suppression"
                                        class="button small"
                                        color="primary"
                                        v-close-popup
                                        @click="valideDeleteFileFn(fileDelete)"
                                    />
                                </q-card-actions>
                            </q-card>
                        </q-dialog>
                    </span>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 2">
            <div class="answer">Compléter avec des photos du bien</div>
            <div class="input">
                <div class="input-col1">
                    <file-uploader
                        v-bind:projectId="projectId"
                        v-bind:options="filesPicturesOfPropertyOptions"
                        v-on:getFiles="getFiles"
                    ></file-uploader>
                </div>
                <div
                    class="input-col1"
                    v-if="filesPicturesOfPropertyList == null"
                >
                    <span>
                        <a @click="noDocument('pictures')" class="noDocument"
                            >Pas de photos ?</a
                        >
                    </span>
                </div>
                <div
                    class="input-col1"
                    v-else-if="filesPicturesOfPropertyList.length == 0"
                >
                    <span class="empty">Il n'y a pas de photo du bien</span>
                </div>
                <div class="input-col1" v-else>
                    <span class="files">
                        <div class="pictures">
                            <div
                                v-for="(picture,
                                index) in filesPicturesOfPropertyList"
                                :key="index"
                                class="picture no-padding"
                            >
                                <div
                                    class="img"
                                    :style="{
                                        backgroundImage:
                                            'url(' +
                                            picture.myFile.thumbUrl +
                                            ')',
                                    }"
                                >
                                    <q-zoom background-color="black">
                                        <img
                                            :src="picture.myFile.fileUrl"
                                            class="zoom"
                                        />
                                    </q-zoom>
                                </div>
                                <span
                                    >Ajouté le
                                    {{
                                        picture.myFile.creation
                                            | dateFormat("type2")
                                    }}</span
                                >
                                <q-btn
                                    class="button minSmall round"
                                    color="grey"
                                    text-color="dark"
                                    unelevated
                                    icon="fal fa-times"
                                    @click="
                                        deletePictureFn(picture, [
                                            picture.myFile.fileName,
                                            'photo de propriété',
                                        ])
                                    "
                                />
                            </div>
                        </div>
                        <q-dialog v-model="confirmDeletePicture" persistent>
                            <q-card>
                                <q-card-section horizontal>
                                    <q-card-section class="q-pt-xs">
                                        <div class="text-overline text-primary">
                                            Suppréssion
                                        </div>
                                        <div class="text-h5">
                                            {{ fileInfosDelete[0] }}
                                        </div>
                                        <div class="text-h7">
                                            Vous êtes sur le point de supprimer
                                            un fichier, une fois validé vous ne
                                            pourrez plus revenir en arrière.
                                        </div>
                                    </q-card-section>
                                    <q-card-section
                                        class="col-5 flex flex-center"
                                    >
                                        <q-img
                                            class="rounded-borders"
                                            :src="fileInfosDelete[1]"
                                        />
                                    </q-card-section>
                                </q-card-section>
                                <q-card-actions align="right" class="bg-grey">
                                    <q-btn
                                        flat
                                        label="Annuler"
                                        class="button small"
                                        color="gray"
                                        v-close-popup
                                        @click="annuleDeleteFileFn"
                                    />
                                    <q-btn
                                        unelevated
                                        label="Valider la suppression"
                                        class="button small"
                                        color="primary"
                                        v-close-popup
                                        @click="valideDeleteFileFn(fileDelete)"
                                    />
                                </q-card-actions>
                            </q-card>
                        </q-dialog>
                    </span>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 3">
            <div class="answer">D'autres documents à envoyer ?</div>
            <div class="input">
                <div class="input-col1">
                    <span class="files">
                        <file-uploader
                            v-bind:projectId="projectId"
                            v-bind:options="filesOthersOptions"
                            v-on:getFiles="getFiles"
                        ></file-uploader>
                        <div v-if="filesOthersList == null">
                            <a @click="noDocument('others')" class="noDocument"
                                >Pas de documents ?</a
                            >
                        </div>
                        <div v-else-if="filesOthersList.length == 0">
                            <span class="empty"
                                >Il n'y a pas d'autres documents</span
                            >
                        </div>
                        <q-list v-else>
                            <q-item
                                v-for="(file, index) in filesOthersList"
                                :key="index"
                                class="file no-padding"
                            >
                                <q-item-section avatar top class="icon">
                                    <q-icon
                                        name="fal fa-file-pdf"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'pdf'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-word"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'doc'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file-image"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'img'
                                        "
                                    />
                                    <q-icon
                                        name="fal fa-file"
                                        v-if="
                                            getFileFormat(
                                                file.myFile.fileName
                                            ) == 'file'
                                        "
                                    />
                                </q-item-section>
                                <q-item-section top class="infos">
                                    <div class="name">
                                        <a
                                            :href="file.myFile.fileUrl"
                                            target="_blank"
                                            >{{ file.myFile.fileName }}</a
                                        >
                                        <span
                                            >Ajouté le
                                            {{
                                                file.myFile.creation
                                                    | dateFormat("type2")
                                            }}</span
                                        >
                                    </div>
                                </q-item-section>
                                <q-item-section top side class="button">
                                    <q-btn
                                        class="button minSmall round"
                                        color="grey"
                                        text-color="dark"
                                        unelevated
                                        icon="fal fa-times"
                                        @click="
                                            deleteFileFn(file, [
                                                file.myFile.fileName,
                                                'autres documents',
                                            ])
                                        "
                                    />
                                </q-item-section>
                            </q-item>
                        </q-list>
                        <q-dialog v-model="confirm" persistent>
                            <q-card>
                                <q-card-section>
                                    <q-card-section class="q-pt-xs">
                                        <div class="text-overline text-primary">
                                            Suppréssion {{ fileInfosDelete[1] }}
                                        </div>
                                        <div class="text-h5">
                                            {{ fileInfosDelete[0] }}
                                        </div>
                                        <div class="text-h7">
                                            Vous êtes sur le point de supprimer
                                            un fichier, une fois validé vous ne
                                            pourrez plus revenir en arrière.
                                        </div>
                                    </q-card-section>
                                </q-card-section>
                                <q-card-actions align="right" class="bg-grey">
                                    <q-btn
                                        flat
                                        label="Annuler"
                                        class="button small"
                                        color="gray"
                                        v-close-popup
                                        @click="annuleDeleteFileFn"
                                    />
                                    <q-btn
                                        unelevated
                                        label="Valider la suppression"
                                        class="button small"
                                        color="primary"
                                        v-close-popup
                                        @click="valideDeleteFileFn(fileDelete)"
                                    />
                                </q-card-actions>
                            </q-card>
                        </q-dialog>
                    </span>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn
                v-if="currentStep > 1"
                class="button small left"
                unelevated
                color="grey"
                text-color="dark"
                label="Retour"
                v-on:click="previousStep()"
            />
            <q-btn
                v-if="currentStep < nbStep"
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Suite de l'action"
                v-on:click="nextStep()"
            />
            <q-btn
                v-else
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Terminer et fermer"
                v-on:click="$emit('returnAction', ['endAndClose'])"
            />
            <q-btn
                class="button small right clear"
                unelevated
                color="grey"
                text-color="dark"
                label="Fermer"
                v-on:click="$emit('returnAction', ['close'])"
            />
        </div>
    </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../../../../store/index";
    import newFunctions from "../../../../utils/functions.js";
    import fileUploader from "../../../utils/fileUploader";
    import newFunction from "../../../../utils/functions";

    export default {
        name: "editingFiles",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                currentStep: 1,
                nbStep: 3,
                functions: newFunctions,
                confirm: false,
                confirmDeletePicture: false,
                fileDelete: null,
                fileInfosDelete: "",
                filesPropertyTitleList: null,
                filesServitudesList: null,
                filesPicturesOfPropertyList: null,
                filesSoilSurveyList: null,
                filesOthersList: null,

                filesReferential: [],
                filesPropertyTitleOptions: {
                    type: null,
                    maxFiles: 3,
                    accept: " .pdf, .jpg, image/*, .png , .jpeg ",
                },
                filesServitudesOptions: {
                    type: null,
                    maxFiles: 3,
                    accept: " .pdf, .jpg, image/*, .png , .jpeg ",
                },
                filesSoilSurveyOptions: {
                    type: null,
                    maxFiles: 3,
                    accept: " .pdf, .jpg, image/*, .png , .jpeg ",
                },
                filesPicturesOfPropertyOptions: {
                    type: null,
                    maxFiles: 3,
                    accept: ".jpg, .png , .jpeg",
                },
                filesOthersOptions: {
                    type: null,
                    maxFiles: 3,
                    accept: " .pdf, .jpg, image/*, .png , .jpeg ",
                },
            };
        },
        computed: {
            ...Vuex.mapGetters([
                "projectReferential",
                "projectBuilder",
                "projectIsProjectsClusterLoaded",
                "referentialIsReferentialLoading",
            ]),
        },
        created() {
            this.init();
        },
        methods: {
            ...Vuex.mapActions[
                ("getReferentialValues",
                "getProjectFiles",
                "deleteFileToProject")
            ],
            init() {
                Store.dispatch("getReferentialValues", {
                    referentialId: "fileType",
                }).then(
                    (response) => {
                        this.filesReferential = response.body;
                        this.filesReferential.forEach((element) => {
                            console.log(element);
                            switch (element.frValue) {
                                case "Titre de propriété":
                                    this.filesPropertyTitleOptions.type = element;
                                    break;
                                case "Servitude":
                                    this.filesServitudesOptions.type = element;
                                    break;
                                case "Etude de sol":
                                    this.filesSoilSurveyOptions.type = element;
                                    break;
                                case "Photo du bien":
                                    this.filesPicturesOfPropertyOptions.type = element;
                                    break;
                                case "Autres documents":
                                    this.filesOthersOptions.type = element;
                                    break;
                            }
                            Store.dispatch("getProjectFiles", {
                                projectId: this.projectId,
                                type: element.id,
                            }).then((response) => {
                                switch (element.frValue) {
                                    case "Titre de propriété":
                                        this.filesPropertyTitleList =
                                            response.body;
                                        break;
                                    case "Servitude":
                                        this.filesServitudesList =
                                            response.body;
                                        break;
                                    case "Etude de sol":
                                        this.filesSoilSurveyList =
                                            response.body;
                                        break;
                                    case "Photo du bien":
                                        this.filesPicturesOfPropertyList =
                                            response.body;
                                        break;
                                    case "Autres documents":
                                        this.filesOthersList = response.body;
                                        break;
                                }
                            });
                        });
                    },
                    (error) => {}
                );
            },
            getFiles() {
                this.filesReferential.forEach((element) => {
                    Store.dispatch("getProjectFiles", {
                        projectId: this.projectId,
                        type: element.id,
                    }).then((response) => {
                        switch (element.frValue) {
                            case "Titre de propriété":
                                this.filesPropertyTitleList = response.body;
                                break;
                            case "Servitude":
                                this.filesServitudesList = response.body;
                                break;
                            case "Etude de sol":
                                this.filesSoilSurveyList = response.body;
                                break;
                            case "Photo du bien":
                                this.filesPicturesOfPropertyList =
                                    response.body;
                                break;
                            case "Autres documents":
                                this.filesOthersList = response.body;
                                break;
                        }
                    });
                });
            },
            deleteFile(e) {
                Store.dispatch("deleteFileToProject", {
                    projectId: this.projectId,
                    fileId: e,
                })
                    .then((response) => {
                        if (response.status == 200) {
                            this.$q.notify({
                                type: "positive",
                                timeout: 4000,
                                progress: true,
                                icon: "fal fa-check",
                                message: "Le document bien été supprimer",
                                position: "top",
                            });
                        } else {
                            this.$q.notify({
                                type: "negative",
                                timeout: 4000,
                                progress: true,
                                icon: "fal fa-check",
                                message:
                                    "Une erreur est survenue lors de la supression du document",
                                position: "top",
                            });
                        }
                        this.confirm = false;
                        this.getFiles();
                    })
                    .catch((error) => {
                        this.$q.notify({
                            type: "negative",
                            timeout: 4000,
                            progress: true,
                            icon: "fal fa-check",
                            message:
                                "Une erreur est survenue lors de la supression du document",
                            position: "top",
                        });
                    });
            },
            nextStep() {
                this.currentStep++;
            },
            previousStep() {
                this.currentStep--;
            },
            counterLabelFn({ totalSize, filesNumber, maxFiles }) {
                return `${filesNumber}/${maxFiles} - ${totalSize}`;
            },
            deleteFileFn(file, infos) {
                this.fileDelete = file;
                this.fileInfosDelete = infos;
                this.confirm = true;
            },
            deletePictureFn(picture, infos) {
                this.fileDelete = picture;
                this.fileInfosDelete = infos;
                this.confirmDeletePicture = true;
            },
            annuleDeleteFileFn(e) {
                this.confirm = false;
            },
            annuleDeletePictureFn(e) {
                this.confirmDeletePicture = false;
            },
            valideDeleteFileFn(e) {
                this.deleteFile(e.id);
            },
            valideDeletePictureFn(e) {
                this.confirmDeletePicture = false;
            },
            getFileFormat(e) {
                return newFunction.getFileFormat(e);
            },
            noDocument(doc) {
                if (doc == "properties") {
                    this.filesPropertyTitleList = [];
                } else if (doc == "servitude") {
                    this.filesServitudesList = [];
                } else if (doc == "etudesSols") {
                    this.filesSoilSurveyList = [];
                } else if (doc == "pictures") {
                    this.filesPicturesOfPropertyList = [];
                } else if (doc == "others") {
                    this.filesOthersList = [];
                }
            },
        },

        components: {
            fileUploader,
        },
    };
</script>

<style lang="scss">
    @import "../../../../css/app";

    .editingFiles {
        .files {
            margin: 0;

            .file {
                margin: 20px 0 0;

                .icon {
                    padding: 1px 0 0 0;
                }

                .infos {
                    .name {
                        a {
                            display: block;
                            font-weight: 600;
                            font-size: 12px;
                            line-height: 18px;
                        }

                        span {
                            font-size: 9px;
                            line-height: 13px;
                            color: $grey03;
                            display: block;
                            padding: 0;
                            width: 100%;
                        }
                    }
                }

                .button {
                    margin: 0;
                }
            }

            .pictures {
                padding: 15px 0 0;

                .picture {
                    float: left;
                    width: 21.25%;
                    position: relative;
                    margin: 0 5% 20px 0;

                    &:nth-child(4n + 4) {
                        margin: 0 0 20px 0;
                    }

                    .img {
                        width: 100%;
                        padding: 60% 0 0 0;
                        border-radius: 5px;
                        background-position: center;
                        background-size: cover;
                    }

                    span {
                        font-size: 9px;
                        line-height: 13px;
                        color: $grey03;
                        display: block;
                        padding: 5px 0 0 0;
                        width: 100%;
                    }

                    button {
                        position: absolute;
                        top: -12px;
                        right: 10px;
                    }
                }
            }
        }

        .noDocument {
            display: block;
            text-align: center;
            padding: 10px 0;
            margin: 10px 0;
        }

        .empty {
            width: 100% !important;
            display: block;
            text-align: center;
            padding: 10px 0 !important;
            margin: 10px 0;
            font-size: 12px;
            font-style: italic;
            color: $grey02;
        }

        @media screen and (max-width: 1500px) {
            .files {
                width: 100% !important;
                padding: 0 0 10px 0 !important;

                .file {
                    margin: 10px 0;
                }

                .pictures {
                    .picture {
                        float: left;
                        width: 30%;
                        position: relative;
                        margin: 0 5% 20px 0;

                        &:nth-child(4n + 4) {
                            margin: 0 5% 20px 0;
                        }

                        &:nth-child(3n + 3) {
                            margin: 0 0 20px 0;
                        }

                        .img {
                            width: 100%;
                            padding: 60% 0 0 0;
                            border-radius: 5px;
                        }
                    }
                }
            }
        }
    }
</style>
