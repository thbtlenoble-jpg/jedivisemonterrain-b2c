<template>
    <div class="previewFiles">
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['files', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Documents
        </div>
        <div class="responses" v-if="state != 'empty'">
            <div class="bloc">
                <div class="answer"><span>1.</span> Ajout des documents propriétaires et biens</div>
                <div class="response">
                    <span class="regular">Titre de propriété</span>
                    <div class="files" v-if="filesPropertyTitleList != null">
                        <div v-if="filesPropertyTitleList.length == 0">
                            <div class="arrow">
                                <i class="fal fa-arrow-alt-right"></i> Il n'y a pas de documents
                            </div>
                        </div>
                        <div v-else>
                            <div v-for="file in filesPropertyTitleList">
                                <i class="fal fa-file-pdf" v-if="getFileFormat(file.myFile.fileName) == 'pdf'" />
                                <i class="fal fa-file-word" v-if="getFileFormat(file.myFile.fileName) == 'doc'" />
                                <i class="fal fa-file-image" v-if="getFileFormat(file.myFile.fileName) == 'img'" />
                                <i class="fal fa-file" v-if="getFileFormat(file.myFile.fileName) == 'file' " />
                                <div class="name">
                                    <a :href="file.myFile.fileUrl" target="_blank">{{file.myFile.fileName}}</a>
                                    <span>Ajouté le {{file.myFile.creation | dateFormat('type1')}}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Servitude</span>
                    <div class="files" v-if="filesServitudesList != null">
                        <div v-if="filesServitudesList.length == 0">
                            <div class="arrow">
                                <i class="fal fa-arrow-alt-right"></i> Il n'y a pas de documents
                            </div>
                        </div>
                        <div v-else>
                            <div v-for="file in filesServitudesList">
                            <i class="fal fa-file-pdf" v-if="getFileFormat(file.myFile.fileName) == 'pdf'" />
                            <i class="fal fa-file-word" v-if="getFileFormat(file.myFile.fileName) == 'doc'" />
                            <i class="fal fa-file-image" v-if="getFileFormat(file.myFile.fileName) == 'img'" />
                            <i class="fal fa-file" v-if="getFileFormat(file.myFile.fileName) == 'file' " />
                            <div class="name">
                                <a :href="file.myFile.fileUrl" target="_blank">{{file.myFile.fileName}}</a>
                                <span>Ajouté le {{file.myFile.creation | dateFormat('type1')}}</span>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Etude de sols</span>
                    <div class="files" v-if="filesSoilSurveyList != null">
                        <div v-if="filesSoilSurveyList.length == 0">
                            <div class="arrow">
                                <i class="fal fa-arrow-alt-right"></i> Il n'y a pas de documents
                            </div>
                        </div>
                        <div v-else>
                            <i class="fal fa-file-pdf" v-if="getFileFormat(file.myFile.fileName) == 'pdf'" />
                            <i class="fal fa-file-word" v-if="getFileFormat(file.myFile.fileName) == 'doc'" />
                            <i class="fal fa-file-image" v-if="getFileFormat(file.myFile.fileName) == 'img'" />
                            <i class="fal fa-file" v-if="getFileFormat(file.myFile.fileName) == 'file' " />
                            <div class="name">
                                <a :href="file.myFile.fileUrl" target="_blank">{{file.myFile.fileName}}</a>
                                <span>Ajouté le {{file.myFile.creation | dateFormat('type1')}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
            <div class="bloc">
                <div class="answer"><span>2.</span> Compléter avec des photos du bien</div>
                <div class="response" v-if="filesPicturesOfPropertyList != null">
                    <div v-if="filesPicturesOfPropertyList.length == 0">
                        <div class="arrow">
                            <i class="fal fa-arrow-alt-right"></i> Il n'y a pas de photo du bien
                        </div>
                    </div>
                    <div v-else>
                        <div class="list" v-for="picture in filesPicturesOfPropertyList">
                            <span class="picture" :style="{ backgroundImage: 'url(' + picture.myFile.thumbUrl + ')' }">
                                <q-zoom background-color="black">
                                    <img :src="picture.myFile.fileUrl" class="zoom">
                                </q-zoom>
                            </span>
                            <span class="date">Le {{picture.myFile.creation | dateFormat('type2')}}</span>
                        </div>
                    </div>
                </div>
                <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
            <div class="bloc">
                <div class="answer"><span>3.</span> D'autres documents à envoyer ?</div>
                <div class="response" v-if="filesOthersList != null">
                    <div v-if="filesOthersList.length == 0">
                        <div class="arrow">
                            <i class="fal fa-arrow-alt-right"></i> Il n'y a pas de document supplémentaire
                        </div>
                    </div>
                    <div class="files" v-else>
                        <div v-for="file in filesOthersList">
                            <i class="fal fa-file-pdf" v-if="getFileFormat(file.myFile.fileName) == 'pdf'" />
                            <i class="fal fa-file-word" v-if="getFileFormat(file.myFile.fileName) == 'doc'" />
                            <i class="fal fa-file-image" v-if="getFileFormat(file.myFile.fileName) == 'img'" />
                            <i class="fal fa-file" v-if="getFileFormat(file.myFile.fileName) == 'file' " />
                            <div class="name">
                                <a :href="file.myFile.fileUrl" target="_blank">{{file.myFile.fileName}}</a>
                                <span>Ajouté le {{file.myFile.creation | dateFormat('type1')}}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions'

    export default {
        name: "previewFiles",
        props: ["valuesPreview", "state","projectId"],
        data(){
            return{
                functions: newFunctions,
                filesPropertyTitleList : null,
                filesServitudesList : null,
                filesPicturesOfPropertyList : null,
                filesSoilSurveyList : null,
                filesOthersList : null,
                filesReferential : [],
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectBuilder'
            ])
        },
        created(){
            this.init()
        },
        methods:{
            ...Vuex.mapActions["getReferentialValues","getProjectFiles","deleteFileToProject"],
            init(){
                Store.dispatch('getReferentialValues', {referentialId: 'fileType'}).then(
                    response => {
                        this.filesReferential = response.body
                        this.filesReferential.forEach(element => {
                            Store.dispatch('getProjectFiles',{projectId :this.projectId ,type : element.id}).then( response =>{
                                switch (element.frValue) {
                                    case 'Titre de propriété':
                                        this.filesPropertyTitleList = response.body
                                        break;
                                    case 'Servitude':
                                        this.filesServitudesList = response.body
                                        break;
                                    case 'Etude de sol':
                                        this.filesSoilSurveyList = response.body
                                        break;
                                    case 'Photo du bien':
                                        this.filesPicturesOfPropertyList = response.body
                                        break;
                                    case 'Autres documents':
                                        this.filesOthersList = response.body
                                        break;
                                }
                            })

                        })
                    },
                    error => {

                    }
                )
            },
            getFileFormat(e){
                return this.functions.getFileFormat(e)
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .previewFiles {

        .bloc{
            overflow: hidden;

            .list{
                float: left;
                width: 46%;
                margin: 0 8% 15px 0;

                .picture{
                    width: 100%;
                    padding: 60% 0 0 0;
                    background-position: center;
                    background-size: cover;
                    display: block;
                    border-radius: 5px;
                    position: relative;
                }

                .date{
                    float: left;
                    font-size: 9px;
                    color: $grey03;
                }

                &:nth-child(2n+2){
                    margin: 0 0 15px 0;
                }

            }

        }

    }
</style>
