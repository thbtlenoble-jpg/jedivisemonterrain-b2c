<template>
    <div class="goodInformationEditing">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded || referentialIsReferentialLoading">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="headerEditing">
            <span>Edition</span>
            Informations sur le bien
            <div class="stepAction">
                <span>{{currentStep}}</span>/{{nbStep}}
            </div>
        </div>
        <div class="form" v-if="currentStep == 1">
            <div class="answer">Informations générales</div>
            <div class="input">
                <div class="input-col2">
                    <span>
                        <q-select v-model="goodPropertyEditing.type" option-value="id" emit-value map-options option-label="value" :options="typeGoodReferential" label="Type de bien" />
                    </span>
                    <span>
                        <q-toggle indeterminate-value="null" v-model="goodPropertyEditing.isInAllotment" left-label label="Situé en lotissement" />
                    </span>
                </div>
                <div class="input-col2">
                    <span class="col col9">
                        <q-select v-model="goodPropertyEditing.usage" option-value="id" emit-value map-options option-label="value" :options="usageReferential" label="Usage du bien" />
                    </span>
                    <span class="col col3">
                        <q-input v-model="goodPropertyEditing.acquisitionDate" label="Date d'achat">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="goodPropertyEditing.acquisitionDate" mask="DD/MM/YYYY" />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                </div>
                <div class="input-col4">
                    <span>
                        <q-input v-model="goodPropertyEditing.sucessionDate" label="Date de sucession" title="Date de sucession">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="goodPropertyEditing.sucessionDate" mask="DD/MM/YYYY" />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input v-model="goodPropertyEditing.donationDate" label="Date de donation" title="Date de donation">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="goodPropertyEditing.donationDate" mask="DD/MM/YYYY" />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input v-model="goodPropertyEditing.shareDate" label="Date de sucession" title="Date de partage">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="goodPropertyEditing.shareDate" mask="DD/MM/YYYY" />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                    <span>
                        <q-input v-model="goodPropertyEditing.rightReturnDate" label="Date de droit de retour" title="Date de droit de retour">
                            <template v-slot:append>
                                <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                    <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                        <q-date v-model="goodPropertyEditing.rightReturnDate" mask="DD/MM/YYYY" />
                                    </q-popup-proxy>
                                </q-icon>
                            </template>
                        </q-input>
                    </span>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 2">
            <div class="answer">Informations terrain</div>
            <div class="input">
                <div class="input-col2">
                    <span>
                        <q-select v-model="goodPropertyEditing.topography" option-value="id" emit-value map-options option-label="value" :options="topographyReferential" label="Topographie générale" />
                    </span>
                    <span>
                        <q-toggle indeterminate-value="null" v-model="goodPropertyEditing.isInRightOfWay" left-label label="Servitude de passage ou indivision ?" />
                    </span>
                </div>
                <div class="input-col1" v-if="goodPropertyEditing.isInRightOfWay">
                    <span>
                        <q-toggle indeterminate-value="null" v-model="goodPropertyEditing.isInIndivision" left-label label="Y a-t-il indivision ?">
                            <i class="fal fa-arrow-alt-right"></i>
                        </q-toggle>
                    </span>
                    <span class="legend">
                        <i class="fal fa-exclamation-triangle orange"></i> Si indivision, nécessité d'avoir le titre de propriété
                    </span>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 3">
            <div class="answer">Informations sur le bâti existant</div>
            <div class="input">
                <div class="inpu-col1">
                    <q-toggle indeterminate-value="null" v-model="existingBuildingPropertyEditing.isExistingBuilding" left-label label="Un bâti est existant ?" />
                </div>
                <div v-if="existingBuildingPropertyEditing.isExistingBuilding">
                    <div class="input-col4">
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.dateBuildingPermit" label="Date de permis de construire" title="Date de permis de construire">
                                <template v-slot:append>
                                    <q-icon name="fal fa-calendar-alt" class="cursor-pointer">
                                        <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
                                            <q-date v-model="existingBuildingPropertyEditing.dateBuildingPermit" mask="DD/MM/YYYY" />
                                        </q-popup-proxy>
                                    </q-icon>
                                </template>
                            </q-input>
                        </span>
                        <span><q-input v-model="existingBuildingPropertyEditing.refBuildingPermit" title="N° de permis de construire" label="N° de permis de construire" /></span>
                        <span><q-input v-model="existingBuildingPropertyEditing.concernedSurface" label="Surface concernée" suffix="m²" input-class="text-right" /></span>
                        <span><q-input v-model="existingBuildingPropertyEditing.totalSurface" label="Surface totale" suffix="m²" input-class="text-right" /></span>
                    </div>
                    <div class="input-col4">
                        <span><q-input v-model="existingBuildingPropertyEditing.usefulSurface" label="Surface utile" suffix="m²" input-class="text-right" /></span>
                        <span><q-input v-model="existingBuildingPropertyEditing.livingSpace" label="Surface habitable" suffix="m²" input-class="text-right" /></span>
                        <span><q-input v-model="existingBuildingPropertyEditing.squareLowArea" label="Surface loi Carrez" suffix="m²" input-class="text-right" /></span>
                        <span><q-input v-model="existingBuildingPropertyEditing.garageSurface" label="Surface garage" suffix="m²" input-class="text-right" /></span>
                    </div>
                    <div class="input-col2">
                        <span>
                            <q-toggle indeterminate-value="null" v-model="existingBuildingPropertyEditing.isTerraced" left-label label="Mitoyenneté ?" />
                        </span>
                        <span>
                            <q-toggle indeterminate-value="null" v-model="existingBuildingPropertyEditing.hasFencing" left-label label="Clôture ?" />
                        </span>
                    </div>
                    <div class="input-col2">
                        <span v-if="existingBuildingPropertyEditing.isTerraced">
                            <q-input v-model="existingBuildingPropertyEditing.numberSideTerraced" label="Nombre de cotés mitoyens">
                                <template v-slot:before>
                                    <q-icon class="blue" name="fal fa-arrow-alt-right" />
                                </template>
                            </q-input>
                        </span>
                        <span v-else style="height:1px;"></span>
                        <span v-if="existingBuildingPropertyEditing.hasFencing">
                            <q-input v-model="existingBuildingPropertyEditing.locationConditionFences" label="Emplacement et état des clôtures">
                                <template v-slot:before>
                                    <q-icon class="blue" name="fal fa-arrow-alt-right" />
                                </template>
                            </q-input>
                        </span>
                        <span v-else style="height:1px;"></span>
                    </div>
                    <div class="input-col1">
                        <span>
                            <q-toggle indeterminate-value="null" v-model="existingBuildingPropertyEditing.isOpposite" left-label label="Vis-à-vis ?" />
                        </span>
                    </div>
                    <div class="input-col3" v-if="existingBuildingPropertyEditing.isOpposite">
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.oppositePrecision" label="Précisé le vis-à-vis">
                                <template v-slot:before>
                                    <q-icon class="blue" name="fal fa-arrow-alt-right" />
                                </template>
                            </q-input>
                        </span>
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.sunshine" label="Ensoleillement" />
                        </span>
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.exposition" label="Exposition" />
                        </span>
                    </div>
                    <div class="input-col4">
                        <span>
                            <q-select v-model="existingBuildingPropertyEditing.existingCondition" option-value="id" emit-value map-options option-label="value" :options="existingConditionReferential" label="Etat de l'existant" />
                        </span>
                        <span>
                            <q-select v-model="existingBuildingPropertyEditing.presentationType" option-value="id" emit-value map-options option-label="value" :options="presentationTypeReferential" label="Type de prestation" />
                        </span>
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.constructingYear" label="Année de construction" />
                        </span>
                        <span>
                            <q-input v-model="existingBuildingPropertyEditing.renovationYear" label="Année de rénovation" />
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="form" v-if="currentStep == 4">
            <div class="answer">Dernières informations</div>
            <div class="input">
                <div class="input-col1">
                    <q-toggle indeterminate-value="maybe" v-model="goodPropertyEditing.isIndismemberment" left-label label="Le bien fait l'objet d'un démembrement ?" />
                </div>
                <div v-if="goodPropertyEditing.isIndismemberment">
                    <div class="input-col4">
                        <span><q-input v-model="goodPropertyEditing.usufructuary" label="Usufruitier" /></span>
                        <span><q-input v-model="goodPropertyEditing.bareProperty" label="Nue-propriété" /></span>
                        <span><q-input v-model="goodPropertyEditing.fullOwnerShipInDivision" label="Pleine propriété / en division" /></span>
                        <span><q-input v-model="goodPropertyEditing.numberOfOwners" label="Nbr de personnes propriétaire" /></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="link">
            <q-btn v-if="currentStep > 1" class="button small left" unelevated color="grey" text-color="dark" label="Retour" v-on:click="previousStep()" />
            <q-btn v-if="currentStep < nbStep" class="button small right" unelevated color="primary" text-color="white" label="Suite de l'action" v-on:click="nextStep()" />
            <q-btn v-else class="button small right" unelevated color="primary" text-color="white" label="Terminer et fermer" v-on:click="saveAllInformations(); $emit('returnAction', ['endAndClose'])" />
            <q-btn class="button small right clear" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="endVisibility(); $emit('returnAction', ['close'])" />
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions.js'

    export default {
        name: "goodInformationEditing",
        props: ["valuesEditing","projectId"],
        data(){
            return{
                currentStep: 1,
                nbStep: 4,
                functions: newFunctions,
                typeGoodReferential: [],
                usageReferential: [],
                topographyReferential: [],
                existingConditionReferential: [],
                presentationTypeReferential: [],
                goodPropertyEditing : {
                    isInSale : null,
                    type : null,
                    isInAllotment : null,
                    usage : null,
                    acquisitionDate : null,
                    sucessionDate : null,
                    donationDate : null,
                    shareDate : null,
                    rightReturnDate : null,
                    topography : null,
                    isInRightOfWay : null,
                    isInIndivision : null,
                    isIndismemberment : null,
                    usufructuary : null,
                    bareProperty : null,
                    fullOwnerShipInDivision : null,
                    numberOfOwners : null
                },
                existingBuildingPropertyEditing: {
                    isExistingBuilding : null,
                    dateBuildingPermit : null,
                    refBuildingPermit : null,
                    concernedSurface : null,
                    totalSurface : null,
                    usefulSurface : null,
                    livingSpace : null,
                    squareLowArea : null,
                    garageSurface : null,
                    isTerraced : null,
                    hasFencing : null,
                    numberSideTerraced : null,
                    locationConditionFences : null,
                    isOpposite : null,
                    oppositePrecision : null,
                    sunshine : null,
                    exposition : null,
                    existingCondition : null,
                    presentationType : null,
                    constructingYear : null,
                    renovationYear : null
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential','projectIsProjectsClusterLoaded','referentialIsReferentialLoading'
            ])
        },
        created() {
            this.init()
        },
        methods: {
            ...Vuex.mapActions(["getGoodPropertyByProjectId","addOrUpdateGoodPropertyToProject","getProjectReferentialValues","addOrCreateExistingBuildingPropertyToProject","getExistingBuildingPropertyByProjectId"]),
            init() {
                let vm = this
                 this.getReferential()
                 this.getGoodProperty()
                this.getExistingBuildingProperty()
                // Formatage des dates pour l'affichage


            },
            getReferential(){
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.typeGoodReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyUsage'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.usageReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyTopography'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.topographyReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'existingBuildingPropertyExistingCondition'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.existingConditionReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'existingBuildingPropertyPresentationType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.presentationTypeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
            },
            getGoodProperty(){
                Store.dispatch('getGoodPropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.goodPropertyEditing = {...this.goodPropertyEditing,...response.body}
                            if(this.goodPropertyEditing.type != null){
                                this.goodPropertyEditing.type = this.goodPropertyEditing.type.id
                            }
                            if(this.goodPropertyEditing.usage != null){
                                this.goodPropertyEditing.usage = this.goodPropertyEditing.usage.id
                            }
                            if(this.goodPropertyEditing.topography != null){
                                this.goodPropertyEditing.topography = this.goodPropertyEditing.topography.id
                            }

                            if(this.goodPropertyEditing.acquisitionDate != null){
                                this.goodPropertyEditing.acquisitionDate = newFunctions.dateConverter('decode', this.goodPropertyEditing.acquisitionDate)
                            }
                            if(this.goodPropertyEditing.sucessionDate != null){
                                this.goodPropertyEditing.sucessionDate = newFunctions.dateConverter('decode', this.goodPropertyEditing.sucessionDate)
                            }
                            if(this.goodPropertyEditing.donationDate != null){
                                this.goodPropertyEditing.donationDate = newFunctions.dateConverter('decode', this.goodPropertyEditing.donationDate)
                            }
                            if(this.goodPropertyEditing.shareDate != null){
                                this.goodPropertyEditing.shareDate = newFunctions.dateConverter('decode', this.goodPropertyEditing.shareDate)
                            }
                            if(this.goodPropertyEditing.rightReturnDate != null){
                                this.goodPropertyEditing.rightReturnDate = newFunctions.dateConverter('decode', this.goodPropertyEditing.rightReturnDate)
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            getExistingBuildingProperty(){
                Store.dispatch('getExistingBuildingPropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.existingBuildingPropertyEditing = {...this.existingBuildingPropertyEditing,...response.body}
                            if(this.existingBuildingPropertyEditing.existingCondition != null){
                                this.existingBuildingPropertyEditing.existingCondition = this.existingBuildingPropertyEditing.existingCondition.id
                            }
                            if(this.existingBuildingPropertyEditing.presentationType != null){
                                this.existingBuildingPropertyEditing.presentationType = this.existingBuildingPropertyEditing.presentationType.id
                            }

                            if(this.existingBuildingPropertyEditing.dateBuildingPermit != null){
                                this.existingBuildingPropertyEditing.dateBuildingPermit = newFunctions.dateConverter('decode', this.existingBuildingPropertyEditing.dateBuildingPermit)
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            saveAllInformations(){
                this.endVisibility()
                Store.dispatch('addOrUpdateGoodPropertyToProject',{projectId : this.projectId, goodProperty : this.goodPropertyEditing}).then(
                    response => {
                    },
                    error => {

                    }
                )
                Store.dispatch('addOrCreateExistingBuildingPropertyToProject',{projectId : this.projectId, existingBuildingProperty : this.existingBuildingPropertyEditing}).then(
                    response => {
                    },
                    error => {

                    }
                )
            },
            nextStep(){
                this.currentStep++
            },
            previousStep(){
                this.currentStep--
            },
            endVisibility() {
                // Formatage des dates pour l'affichage
                if(this.goodPropertyEditing.acquisitionDate != null){
                    this.goodPropertyEditing.acquisitionDate = newFunctions.dateConverter('encode', this.goodPropertyEditing.acquisitionDate)
                }
                if(this.goodPropertyEditing.sucessionDate != null){
                    this.goodPropertyEditing.sucessionDate = newFunctions.dateConverter('encode', this.goodPropertyEditing.sucessionDate)
                }
                if(this.goodPropertyEditing.donationDate != null){
                    this.goodPropertyEditing.donationDate = newFunctions.dateConverter('encode', this.goodPropertyEditing.donationDate)
                }
                if(this.goodPropertyEditing.shareDate != null){
                    this.goodPropertyEditing.shareDate = newFunctions.dateConverter('encode', this.goodPropertyEditing.shareDate)
                }
                if(this.goodPropertyEditing.rightReturnDate != null){
                    this.goodPropertyEditing.rightReturnDate = newFunctions.dateConverter('encode', this.goodPropertyEditing.rightReturnDate)
                }
                if(this.existingBuildingPropertyEditing.dateBuildingPermit != null){
                    this.existingBuildingPropertyEditing.dateBuildingPermit = newFunctions.dateConverter('encode', this.existingBuildingPropertyEditing.dateBuildingPermit)
                }
            }
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .goodInformationEditing{

    }

</style>
