<template>
    <div class="goodInformationPreview">
        <q-inner-loading :showing="projectIsProjectsClusterLoaded">
            <q-spinner size="3em" :thickness="2" color="primary" />
        </q-inner-loading>
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['goodInformation', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Informations sur le bien
        </div>
        <div class="responses" v-if="state != 'empty'">
            <div class="bloc">
                <div class="answer"><span>1.</span> Informations générales</div>
                <div class="response">
                    <span class="regular">Type de bien</span>
                    <div class="arrow" v-if="goodPropertyPreview.type != null">
                        {{goodPropertyPreview.type | getReferential(typeGoodReferential).value}}
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Situé en lotissement</span>
                    <div class="arrow" v-if="goodPropertyPreview.isInAllotment != null">
                        <div v-if="goodPropertyPreview.isInAllotment"><i class="fal fa-check yes"></i> Oui</div>
                        <div v-else><i class="fal fa-times no"></i> Non</div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Usage du bien</span>
                    <div class="arrow" v-if="goodPropertyPreview.usage != null">
                        {{goodPropertyPreview.usage | getReferential(usageReferential).value}}
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Les dates :</span>
                    <div class="arrow" v-if="goodPropertyPreview.acquisitionDate != null || goodPropertyPreview.sucessionDate != null || goodPropertyPreview.donationDate != null || goodPropertyPreview.shareDate != null || goodPropertyPreview.rightReturnDate != null">
                        <span>Achat : <span class="date" v-if="goodPropertyPreview.acquisitionDate != null">Le {{goodPropertyPreview.acquisitionDate | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                        <span>Succession : <span class="date" v-if="goodPropertyPreview.sucessionDate != null">Le {{goodPropertyPreview.sucessionDate | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                        <span>Donation : <span class="date" v-if="goodPropertyPreview.donationDate != null">Le {{goodPropertyPreview.donationDate | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                        <span>Partage : <span class="date" v-if="goodPropertyPreview.shareDate != null">Le {{goodPropertyPreview.shareDate | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                        <span>Droit de retour : <span class="date" v-if="goodPropertyPreview.rightReturnDate != null">Le {{goodPropertyPreview.rightReturnDate | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
            <div class="bloc">
                <div class="answer"><span>2.</span> Informations terrain</div>
                <div class="response">
                    <span class="regular">Topographie générale</span>
                    <div class="arrow" v-if="valuesPreview.topographie != null">
                        {{goodPropertyPreview.topography | getReferential(topographyReferential).value}}
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div class="response">
                    <span class="regular">Servitude de passage</span>
                    <div class="arrow" v-if="goodPropertyPreview.isInRightOfWay != null">
                        <div v-if="goodPropertyPreview.isInRightOfWay"><i class="fal fa-check yes"></i> Oui</div>
                        <div v-else><i class="fal fa-times no"></i> Non</div>
                        <div class="sub" v-if="goodPropertyPreview.isInRightOfWay">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': goodPropertyPreview.isInIndivision == null }"></i>
                            <div class="table">
                                <span>En indivision : </span>
                                <div v-if="goodPropertyPreview.isInIndivision">Oui</div>
                                <div v-else-if="goodPropertyPreview.isInIndivision == null"><span class="empty">Non renseignée</span></div>
                                <div v-else>Non</div>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
            <div class="bloc">
                <div class="answer"><span>3.</span> Informations sur l'existant ?</div>
                <div class="response">
                    <span class="regular">Un bâti est existant ?</span>
                    <div class="arrow" v-if="existingBuildingPropertyPreview.isExistingBuilding != null">
                        <div v-if="existingBuildingPropertyPreview.isExistingBuilding"><i class="fal fa-check yes"></i> Oui</div>
                        <div v-else><i class="fal fa-times no"></i> Non</div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
                <div v-if="existingBuildingPropertyPreview.isExistingBuilding">
                    <div class="response">
                        <span class="regular">Informations permis de construire</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.dateBuildingPermit != null || existingBuildingPropertyPreview.dateBuildingPermit != ''">
                            <span>Date : <span class="date" v-if="existingBuildingPropertyPreview.dateBuildingPermit != null">Le {{existingBuildingPropertyPreview.dateBuildingPermit | dateFormat('type1')}}</span><span class="empty" v-else>Non renseignée</span></span>
                            <span>Numéro : <span class="date" v-if="existingBuildingPropertyPreview.refBuildingPermit != '' && existingBuildingPropertyPreview.refBuildingPermit != null ">{{existingBuildingPropertyPreview.refBuildingPermit}}</span><span class="empty" v-else>Non renseignée</span></span>
                        </div>
                        <div class="empty" v-if="existingBuildingPropertyPreview.dateBuildingPermit == null || existingBuildingPropertyPreview.refBuildingPermit == '' || existingBuildingPropertyPreview.refBuildingPermit == null"><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Les surfaces :</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.concernedSurface != '' && existingBuildingPropertyPreview.concernedSurface != null
                                              && existingBuildingPropertyPreview.totalSurface != '' && existingBuildingPropertyPreview.totalSurface != null
                                              && existingBuildingPropertyPreview.usefulSurface != '' && existingBuildingPropertyPreview.usefulSurface != null
                                              && existingBuildingPropertyPreview.livingSpace != '' && existingBuildingPropertyPreview.livingSpace != null
                                              && existingBuildingPropertyPreview.garageSurface != '' && existingBuildingPropertyPreview.garageSurface != null">
                            <span>Concerné : <span class="date" v-if="existingBuildingPropertyPreview.concernedSurface != '' && existingBuildingPropertyPreview.garageSurface != null">{{existingBuildingPropertyPreview.concernedSurface | formatPriceFloat}} m²</span></span>
                            <span>Total : <span class="date" v-if="existingBuildingPropertyPreview.totalSurface != '' && existingBuildingPropertyPreview.totalSurface != null">{{existingBuildingPropertyPreview.totalSurface | formatPriceFloat}} m²</span></span>
                            <span>Utile : <span class="date" v-if="existingBuildingPropertyPreview.usefulSurface != '' && existingBuildingPropertyPreview.usefulSurface != null">{{existingBuildingPropertyPreview.usefulSurface | formatPriceFloat}} m²</span></span>
                            <span>Habitable : <span class="date" v-if="existingBuildingPropertyPreview.livingSpace != '' && existingBuildingPropertyPreview.livingSpace != null" >{{existingBuildingPropertyPreview.livingSpace | formatPriceFloat}} m²</span></span>
                            <span>Loi carrez : <span class="date" v-if="existingBuildingPropertyPreview.squareLowArea != '' && existingBuildingPropertyPreview.squareLowArea != null">{{existingBuildingPropertyPreview.squareLowArea | formatPriceFloat}} m²</span></span>
                            <span>Garage : <span class="date" v-if="existingBuildingPropertyPreview.garageSurface != '' && existingBuildingPropertyPreview.garageSurface != null">{{existingBuildingPropertyPreview.garageSurface | formatPriceFloat}} m²</span></span>
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Mitoyenneté :</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.isTerraced != null">
                            <div v-if="existingBuildingPropertyPreview.isTerraced"><i class="fal fa-check yes"></i> Oui</div>
                            <div v-else><i class="fal fa-times no"></i> Non</div>
                            <div class="sub" v-if="existingBuildingPropertyPreview.isTerraced">
                                <i class="fal fa-arrow-alt-right" :class="{ 'red': existingBuildingPropertyPreview.numberSideTerraced == '' && existingBuildingPropertyPreview.numberSideTerraced == null }"></i>
                                <div class="table">
                                    <span>Nombre de cotés : </span>
                                    <div v-if="existingBuildingPropertyPreview.numberSideTerraced != '' && existingBuildingPropertyPreview.numberSideTerraced != null">{{existingBuildingPropertyPreview.numberSideTerraced}}</div>
                                    <div v-else><span class="empty">Non renseignée</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Clôture :</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.hasFencing != null">
                            <div v-if="existingBuildingPropertyPreview.hasFencing"><i class="fal fa-check yes"></i> Oui</div>
                            <div v-else><i class="fal fa-times no"></i> Non</div>
                            <div class="sub" v-if="existingBuildingPropertyPreview.hasFencing">
                                <i class="fal fa-arrow-alt-right" :class="{ 'red': existingBuildingPropertyPreview.locationConditionFences == '' && existingBuildingPropertyPreview.locationConditionFences == null }"></i>
                                <div class="table">
                                    <span>Emplacement et état : </span>
                                    <div v-if="existingBuildingPropertyPreview.locationConditionFences != ''">{{existingBuildingPropertyPreview.locationConditionFences}}</div>
                                    <div v-else><span class="empty">Non renseignée</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Vis-à-vis :</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.isOpposite != null">
                            <div v-if="existingBuildingPropertyPreview.isOpposite"><i class="fal fa-check yes"></i> Oui</div>
                            <div v-else><i class="fal fa-times no"></i> Non</div>
                            <div class="sub" v-if="existingBuildingPropertyPreview.isOpposite">
                                <i class="fal fa-arrow-alt-right" :class="{ 'red': existingBuildingPropertyPreview.oppositePrecision == '' && existingBuildingPropertyPreview.oppositePrecision == null }"></i>
                                <div class="table">
                                    <span>Précisé : </span>
                                    <div v-if="existingBuildingPropertyPreview.oppositePrecision != '' && existingBuildingPropertyPreview.oppositePrecision != null">{{existingBuildingPropertyPreview.oppositePrecision}}</div>
                                    <div v-else><span class="empty">Non renseignée</span></div>
                                </div>
                            </div>
                            <div class="sub" v-if="existingBuildingPropertyPreview.isOpposite">
                                <i class="fal fa-arrow-alt-right" :class="{ 'red': existingBuildingPropertyPreview.sunshine == '' && existingBuildingPropertyPreview.sunshine == null }"></i>
                                <div class="table">
                                    <span>Ensoleillement : </span>
                                    <div v-if="existingBuildingPropertyPreview.sunshine != '' && existingBuildingPropertyPreview.sunshine != null">{{existingBuildingPropertyPreview.sunshine}}</div>
                                    <div v-else><span class="empty">Non renseignée</span></div>
                                </div>
                            </div>
                            <div class="sub" v-if="existingBuildingPropertyPreview.isOpposite">
                                <i class="fal fa-arrow-alt-right" :class="{ 'red': existingBuildingPropertyPreview.exposition == '' && existingBuildingPropertyPreview.exposition == null }"></i>
                                <div class="table">
                                    <span>Exposition : </span>
                                    <div v-if="existingBuildingPropertyPreview.exposition != '' && existingBuildingPropertyPreview.exposition != null">{{existingBuildingPropertyPreview.exposition}}</div>
                                    <div v-else><span class="empty">Non renseignée</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Etat de l'existant</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.existingCondition != null">
                            {{existingBuildingPropertyPreview.existingCondition | getReferential(existingConditionReferential).value}}
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Type de prestation</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.presentationType != null">
                            {{existingBuildingPropertyPreview.presentationType | getReferential(presentationTypeReferential).value}}
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Année de construction</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.constructingYear != '' && existingBuildingPropertyPreview.constructingYear != null">
                            {{existingBuildingPropertyPreview.yearConstruct}}
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                    </div>
                    <div class="response">
                        <span class="regular">Année de rénovation</span>
                        <div class="arrow" v-if="existingBuildingPropertyPreview.renovationYear != '' && existingBuildingPropertyPreview.renovationYear != null">
                            {{existingBuildingPropertyPreview.renovationYear}}
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right grey"></i> Non renseigné</div>
                    </div>
                </div>
            </div>
            <div class="bloc">
                <div class="answer"><span>4.</span> Dernières informations</div>
                <div class="response">
                    <span class="regular">Le bien fait l'objet d'un démembrement ?</span>
                    <div class="arrow" v-if="goodPropertyPreview.isIndismemberment != null">
                        <div v-if="goodPropertyPreview.isIndismemberment"><i class="fal fa-check yes"></i> Oui</div>
                        <div v-else><i class="fal fa-times no"></i> Non</div>
                        <div class="sub" v-if="goodPropertyPreview.isIndismemberment">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': goodPropertyPreview.usufructuary == '' && goodPropertyPreview.usufructuary == null }"></i>
                            <div class="table">
                                <span>Usufruitier : </span>
                                <div v-if="goodPropertyPreview.usufructuary != '' && goodPropertyPreview.usufructuary != null">{{goodPropertyPreview.usufructuary}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="goodPropertyPreview.isIndismemberment">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': goodPropertyPreview.bareProperty == '' && goodPropertyPreview.bareProperty == null }"></i>
                            <div class="table">
                                <span>Nue-propriété : </span>
                                <div v-if="goodPropertyPreview.bareProperty != '' && goodPropertyPreview.bareProperty != null">{{goodPropertyPreview.bareProperty}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="goodPropertyPreview.isIndismemberment">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': goodPropertyPreview.fullOwnerShipInDivision == '' && goodPropertyPreview.usufructuary == null }"></i>
                            <div class="table">
                                <span>Pleine propriété / en division : </span>
                                <div v-if="goodPropertyPreview.fullOwnerShipInDivision != ''">{{goodPropertyPreview.fullOwnerShipInDivision}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                        <div class="sub" v-if="goodPropertyPreview.isIndismemberment">
                            <i class="fal fa-arrow-alt-right" :class="{ 'red': goodPropertyPreview.numberOfOwners == '' && goodPropertyPreview.numberOfOwners == null }"></i>
                            <div class="table">
                                <span>Nbr de propriétaire : </span>
                                <div v-if="goodPropertyPreview.numberOfOwners != '' && goodPropertyPreview.numberOfOwners != null">{{goodPropertyPreview.numberOfOwners}}</div>
                                <div v-else><span class="empty">Non renseignée</span></div>
                            </div>
                        </div>
                    </div>
                    <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>
                </div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../../store/index'
    import newFunctions from '../../../../utils/functions'


    export default {
        name: "goodInformationPreview",
        props: ["valuesPreview", "state","projectId"],
        data(){
            return{
                functions: newFunctions,
                typeGoodReferential: [],
                usageReferential: [],
                topographyReferential: [],
                existingConditionReferential: [],
                presentationTypeReferential: [],
                goodPropertyPreview : {
                    isInSale : null,
                    type : null,
                    isInAllotment : null,
                    usage : null,
                    acquisitionDate : null,
                    sucessionDate : null,
                    donationDate : null,
                    shareDate : null,
                    rightReturnDate : null,
                    topography : null,
                    isInRightOfWay : null,
                    isInIndivision : null,
                    isIndismemberment : null,
                    usufructuary : null,
                    bareProperty : null,
                    fullOwnerShipInDivision : null,
                    numberOfOwners : null
                },
                existingBuildingPropertyPreview: {
                    isExistingBuilding : null,
                    dateBuildingPermit : null,
                    refBuildingPermit : null,
                    concernedSurface : null,
                    totalSurface : null,
                    usefulSurface : null,
                    livingSpace : null,
                    squareLowArea : null,
                    garageSurface : null,
                    isTerraced : null,
                    hasFencing : null,
                    numberSideTerraced : null,
                    locationConditionFences : null,
                    isOpposite : null,
                    oppositePrecision : null,
                    sunshine : null,
                    exposition : null,
                    existingCondition : null,
                    presentationType : null,
                    constructingYear : null,
                    renovationYear : null
                }
            }
        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential','projectIsProjectsClusterLoaded'
            ])
        },
        created(){
            this.init()
        },
        methods:{
            ...Vuex.mapActions(["getGoodPropertyByProjectId","getReferentialValues","getExistingBuildingPropertyByProjectId"]),
            init() {
                let vm = this
                this.getReferential()
                this.getGoodProperty()
                this.getExistingBuildingProperty()
                // Formatage des dates pour l'affichage


            },
            getReferential(){
                let vm = this
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.typeGoodReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyUsage'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.usageReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'goodPropertyTopography'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.topographyReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'existingBuildingPropertyExistingCondition'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.existingConditionReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
                Store.dispatch('getReferentialValues', {referentialId: 'existingBuildingPropertyPresentationType'}).then(
                    response => {
                        vm = this
                        response.body.forEach(element => {
                            vm.presentationTypeReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {

                    }
                )
            },
            getGoodProperty(){
                Store.dispatch('getGoodPropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){

                            this.goodPropertyPreview = {...this.goodPropertyPreview,...response.body}
                            if(this.goodPropertyPreview.type != null){
                                this.goodPropertyPreview.type = this.goodPropertyPreview.type.id
                            }
                            if(this.goodPropertyPreview.usage != null){
                                this.goodPropertyPreview.usage = this.goodPropertyPreview.usage.id
                            }
                            if(this.goodPropertyPreview.topography != null){
                                this.goodPropertyPreview.topography = this.goodPropertyPreview.topography.id
                            }
                        }
                    },
                    error => {

                    }
                )
            },
            getExistingBuildingProperty(){
                Store.dispatch('getExistingBuildingPropertyByProjectId', {projectId: this.projectId}).then(
                    response => {
                        if(response.status == 200){
                            this.existingBuildingPropertyPreview = {...this.existingBuildingPropertyPreview,...response.body}
                            if(this.existingBuildingPropertyPreview.existingCondition != null){
                                this.existingBuildingPropertyPreview.existingCondition = this.existingBuildingPropertyPreview.existingCondition.id
                            }
                            if(this.existingBuildingPropertyPreview.presentationType != null){
                                this.existingBuildingPropertyPreview.presentationType = this.existingBuildingPropertyPreview.presentationType.id
                            }
                        }
                    },
                    error => {

                    }
                )
            },
        }
    }

</script>

<style lang="scss">

    @import "../../../../css/app";

    .goodInformationPreview{

        .response{

            .arrow{

                .date{
                    font-size: 12px !important;
                    display: inline-block !important;
                    color: $grey00 !important;
                    font-weight: 600 !important;
                }

                .empty{
                    display: inline-block !important;
                    color: $grey01 !important;
                }

            }

        }

    }

</style>
