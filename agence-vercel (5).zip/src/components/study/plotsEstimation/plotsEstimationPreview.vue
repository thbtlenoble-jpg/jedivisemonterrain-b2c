<template>
    <div class="plotsEstimationPreview">
<!--        <q-inner-loading :showing="projectIsProjectsClusterLoaded">-->
<!--            <q-spinner size="3em" :thickness="2" color="primary" />-->
<!--        </q-inner-loading>-->
        <div class="link">
            <q-btn class="button small" unelevated color="grey" text-color="dark" label="Fermer" v-on:click="$emit('returnAction', ['close'])" />
            <q-btn class="button small" unelevated color="primary" text-color="white" label="Editer" icon="fal fa-edit" v-on:click="$emit('returnAction', ['plotsEstimation', valuesPreview] )" />
        </div>
        <div class="headerPreview">
            <span>Aperçu</span>
            Estimations des lots en division et lotissement
        </div>
        <div class="responses" v-if="1==1">
            <div class="bloc">

                <div class="response">
                    <span class="regular grey">Estimation pour la vente en l'état</span>
                        <div class="arrow finalPrice"  v-if="valuesPreview.blocEstimation.estimations[0].value != null">
                            <i class="fal fa-arrow-alt-right"></i>{{valuesPreview.blocEstimation.estimations[0].value | formatPriceInteger}} €
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> En attente d'information</div>

                </div>
                <div class="response">
                    <span class="regular grey">Estimation pour la vente en division</span>
                    <div v-for="(estimation,index) in valuesPreview.plotsDivisionEstimation.estimations" :key="index">
                        <div class="arrow"  v-if="estimation.value != null">
                            <i class="fal fa-arrow-alt-right"></i> <span>{{estimation.label}} :</span>  {{estimation.value | formatPriceInteger}} €
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> {{estimation.label}}: En attente d'information</div>
                    </div>
                    <div class="arrow finalPrice"  v-if="plotsDivisionEstimationFinalPrice != null || plotsDivisionEstimationFinalPrice != ''">
                        <i class="fal fa-arrow-alt-right"></i> {{plotsDivisionEstimationFinalPrice | formatPriceInteger}} €
                    </div>
                </div>
                <div class="response">
                    <span class="regular grey">Estimation pour la vente en lotisseur</span>
                    <div v-for="(estimation,index) in valuesPreview.allotmentEstimation.estimations" :key="index">
                        <div class="arrow"  v-if="estimation.value != null">
                            <i class="fal fa-arrow-alt-right"></i> <span>{{estimation.label}} :</span> {{estimation.value | formatPriceInteger}} €
                        </div>
                        <div class="empty" v-else><i class="fal fa-arrow-alt-right"></i> {{estimation.label}}: En attente d'information</div>
                    </div>
                    <div class="arrow finalPrice"  v-if="allotmentEstimationFinalPrice != null || allotmentEstimationFinalPrice != ''">
                        <i class="fal fa-arrow-alt-right"></i> {{allotmentEstimationFinalPrice | formatPriceInteger}} €
                    </div>

                </div>
            </div>
        </div>
        <div class="inquire" v-else>
            <i class="fal fa-pause-circle"></i> Action non initiée
        </div>
    </div>
</template>

<script>
    import Vuex from 'vuex'
    export default {
        name: "plotsEstimationPreview",
        props: ["valuesPreview", "projectId"],
        data(){
            return{

            }
        },
        created(){

        },
        computed: {
            ...Vuex.mapGetters([
                'projectReferential',
                'projectIsProjectsClusterLoaded'
            ]),
            plotsDivisionEstimationFinalPrice(){
                let finalPrice = 0
                this.valuesPreview.plotsDivisionEstimation.estimations.forEach((element) => {
                    finalPrice = finalPrice + element.value
                })
                return finalPrice
            },
            allotmentEstimationFinalPrice(){
                let finalPrice = 0
                this.valuesPreview.allotmentEstimation.estimations.forEach((element) => {
                    finalPrice = finalPrice + element.value
                })
                return finalPrice
            }

    }
    }

</script>

<style lang="scss">
    @import "../../../css/app";
    .plotsEstimationPreview{

    }
</style>
