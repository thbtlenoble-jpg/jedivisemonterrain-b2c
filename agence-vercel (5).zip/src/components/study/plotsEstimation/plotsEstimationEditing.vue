<template>
    <div class="editingPlotsEstimation">
        <div class="headerEditing">
            <span>Edition</span>
            Estimations des lots
            <div class="stepAction">
                <span>{{ currentStep }}</span
                >/{{ nbStep }}
            </div>
        </div>
        <q-tabs
            v-model="tab"
            :breakpoint="0"
            active-color="blue"
            align="left"
            indicator-color="blue"
        >
            <q-tab name="blocEstimation" label="VENTE EN BLOC" class="tabs" />
            <q-tab
                name="plotsDivisionEstimation"
                label="VENTE EN DIVISION"
                class="tabs"
            />
            <q-tab
                name="allotmentEstimation"
                label="VENTE EN LOTISSEUR"
                class="tabs"
            />
        </q-tabs>
        <q-separator />
        <q-tab-panels
            v-model="tab"
            animated
            swipeable
            transition-prev="jump-right"
            transition-next="jump-left"
        >
            <q-tab-panel name="blocEstimation">
                <div class="contentTabs row justify-between">
                    <div class="plan col-8" :style="{ backgroundImage: 'url(' + valuesEditing.blocEstimation.urlImage + ')' }">
                        <q-zoom background-color="black">
                            <img :src="valuesEditing.blocEstimation.urlImage" class="zoom">
                        </q-zoom>
                    </div>
                    <div class="estimationsList col-3">
                        <q-input
                                v-for="estimation in valuesEditing.blocEstimation.estimations"
                                v-model="estimation.value"
                                :label="estimation.label"

                        />
                    </div>
                </div>
            </q-tab-panel>
            <q-tab-panel name="plotsDivisionEstimation">
                <div class="contentTabs row justify-between">
                    <div class="plan col-8" :style="{ backgroundImage: 'url(' + valuesEditing.plotsDivisionEstimation.urlImage + ')' }">
                        <q-zoom background-color="black">
                            <img :src="valuesEditing.plotsDivisionEstimation.urlImage" class="zoom">
                        </q-zoom>
                    </div>
                    <div class="estimationsList col-3">
                        <q-input
                                v-for="estimation in valuesEditing.plotsDivisionEstimation.estimations"
                                v-model="estimation.value"
                                :label="estimation.label"

                        />
                    </div>
                </div>
            </q-tab-panel>
            <q-tab-panel name="allotmentEstimation">
                <div class="contentTabs row justify-between">
                    <div class="plan col-8" :style="{ backgroundImage: 'url(' + valuesEditing.allotmentEstimation.urlImage + ')' }">
                        <q-zoom background-color="black">
                            <img :src="valuesEditing.allotmentEstimation.urlImage" class="zoom">
                        </q-zoom>
                    </div>
                    <div class="estimationsList col-3">
                        <q-input
                                v-for="estimation in valuesEditing.allotmentEstimation.estimations"
                                v-model="estimation.value"
                                :label="estimation.label"

                        />
                    </div>
                </div>
            </q-tab-panel>
        </q-tab-panels>
        <div class="link">
            <q-btn
                v-if="currentStep > 1"
                class="button small left"
                unelevated
                color="grey"
                text-color="dark"
                label="Retour"
                v-on:click="previousStep()"
            />
            <q-btn
                v-if="currentStep < nbStep"
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Suite de l'action"
                v-on:click="nextStep()"
            />
            <q-btn
                v-else
                class="button small right"
                unelevated
                color="primary"
                text-color="white"
                label="Terminer et fermer"
                v-on:click="$emit('returnAction', ['endAndClose'])"
            />
            <q-btn
                class="button small right clear"
                unelevated
                color="grey"
                text-color="dark"
                label="Fermer"
                v-on:click="$emit('returnAction', ['close'])"
            />
        </div>
    </div>
</template>

<script>
    export default {
        name: "plotsEstimationEditing",
        props: ["valuesEditing", "projectId"],
        data() {
            return {
                tab: "blocEstimation",
                currentStep: 1,
                nbStep: 1,
            };
        },
    };
</script>

<style lang="scss">
    .editingPlotsEstimation {
        tabs {
            font-size: 16px;
        }
        .plan{
            position: relative;
            background-position: top center;
            background-size: contain;
            background-repeat: no-repeat;
            height: 300px;
        }
    }
</style>
