<template>
    <div class="cardOwner">
        <div class="bloc">
            <div class="left">
<!--                <span class="nationality">{{ functions.getCountry(owner.nationality, projectCountry).iso }}</span>-->
            </div>
            <div class="right">
                <span class="name"> {{ ownerComput.firstname }} {{ ownerComput.lastname }}</span>
                <span class="civil">{{ ownerComput.maritalStatus.frValue  }}</span>
            </div>
        </div>
        <div class="bloc">
            <div class="left">
                <i class="fal fa-map-marker-alt"></i>
            </div>
            <div class="right">
                <span class="address">{{ ownerComput.address.housenumber }} {{ owner.address.street }}<br />{{ owner.address.postcode }} {{ owner.address.city }}</span>
            </div>
        </div>
        <div class="bloc">
            <div class="left">
                <i class="fal fa-phone"></i>
            </div>
            <div class="right">
                <span class="phone">{{ ownerComput.mobile }}</span>
            </div>
        </div>
        <div class="bloc">
            <div class="left">
                <i class="fal fa-envelope"></i>
            </div>
            <div class="right">
                <span class="mail">{{ ownerComput.email }}</span>
            </div>
        </div>
        <div class="bloc">
            <div class="left">
                <i class="fal fa-birthday-cake"></i>
            </div>
            <div class="right">
                <span class="birthday">Le {{ ownerComput.birthdate | dateFormat('type1') }}</span>
            </div>
        </div>
<!--        <div class="bloc">-->
<!--            <div class="identity" v-for="card in owner.identity">-->
<!--                <span :style="{ backgroundImage: 'url(' + card.url + ')' }" v-if="card.url != ''">-->
<!--                    <q-zoom background-color="black">-->
<!--                        <img :src="card.url" class="zoom">-->
<!--                    </q-zoom>-->
<!--                    <i class="fal fa-check"></i>-->
<!--                </span>-->
<!--                <span v-else class="noCard"><i class="fal fa-times"></i></span>-->
<!--            </div>-->
<!--        </div>-->
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../../store/index'
    import newFunctions from '../../../utils/functions'

    export default {
        name: "cardOwner",
        props: ["owner"],
        data() {
            return {
                functions: newFunctions,
                civilReferential : [],
                genderReferential : []
            }
        },
        created(){
          this.init()
        },
        computed: {


            ...Vuex.mapGetters([
                'projectReferential',
                'projectCountry'
            ]),
            ownerComput(){
                return this.owner
            }
        },
        methods:{
            ...Vuex.mapActions["getPersonsByProjectIdAndPartnersType","createAndAddPersonToProject","getReferentialValues"],
            async init() {
                await this.getReferential()
            },

            getReferential(){
                Store.dispatch('getReferentialValues', {referentialId: 'personCivility'}).then(
                    response => {
                        var vm = this
                        response.body.forEach(element => {
                            vm.genderReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    })

                Store.dispatch('getReferentialValues', {referentialId: 'personMaritalStatus'}).then(
                    response => {
                        var vm = this
                        response.body.forEach(element => {
                            vm.civilReferential.push({id: element.id, value: element.frValue})
                        })
                    },
                    error => {
                    })

            },
        }
    }

</script>

<style lang="scss">

    @import "../../../css/app";

    .cardOwner {
        border-radius: 5px;
        border: 1px solid $grey04;
        padding: 18px 20px;
        font-size: 10px;
        line-height: 12px;
        font-weight: 400;
        margin: 0 0 20px 0;

        .bloc{
            margin: 0 0 3px !important;
            clear: both;
            overflow: hidden;

            .left{
                float: left;
                width: 18px;
                text-align: center;
                margin: 0 5px 0 0;

                .nationality{
                    background-color: $blue00;
                    width: 100%;
                    height: 11px;
                    display: block;
                    font-size: 9px !important;
                    line-height: 12px !important;
                    border-radius: 10px;
                    color: white !important;
                    margin: 3px 0 0 0;
                }

                i{
                    font-size: 12px;
                    color: $grey02;
                    line-height: 18px;
                }

            }

            .right{
                display: table;

                span{
                    font-size: 10px !important;
                    padding: 2px 0 0 0;
                    color: $grey00 !important;
                    line-height: 14px !important;
                    display: block;
                }

                .name{
                    padding: 0;
                    font-size: 11px !important;
                    line-height: 18px !important;
                    color: $grey00 !important;
                    font-weight: 600 !important;
                }

            }

            .identity{
                margin: 10px 4% 0 0;
                float: left;
                width: 46%;

                &:last-child{
                    float: right;
                    margin: 10px 0 0 4%;
                }

                span{
                    position: relative;
                    border-radius: 5px;
                    display: block;
                    padding: 70% 0 0 0;
                    background-size: cover;
                    background-position: center;
                    clear: none;

                    &.noCard{
                        background-color: $grey05;

                        i{
                            background-color: $grey02;
                        }

                    }

                    i{
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        width: 24px;
                        height: 24px;
                        line-height: 24px;
                        font-size: 12px;
                        text-align: center;
                        margin: -12px 0 0 -12px;
                        background-color: $green;
                        color: white;
                        border-radius: 12px;
                    }

                }

            }

        }

    }

</style>
