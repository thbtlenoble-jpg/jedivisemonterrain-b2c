<template>
    <div class="cardProject">
        <div class="infoProject">
            <div class="ref">
<!--                <div class="refCircle" v-if="lastStep.myActions != ''" v-bind:style="borderColorStyle"></div>-->
                <div class="refCircle"></div>
                <span>Réf. {{projectCluster.id | digit }}</span>
            </div>
            <div class="address" v-if="projectCluster.address !== null ">
                <div class="iconStreet">
                    <i class="fal fa-map-marker-alt"></i>
                    <div class="streetAddress">
                        <span v-html=" newFilter.addressFormat(projectCluster.address,'type1')"></span>
                    </div>
                </div>
            </div>
        </div>
<!--        <div class="step">-->
<!--            <div class="stepNumber">-->
<!--                <span class="currentStep">{{lastStep.nb}}</span>-->
<!--                <span class="slashTen">/10</span>-->
<!--            </div>-->
<!--            <div class="stepLeft">-->
<!--                <div class="title">Etape</div>-->
<!--                <div class="stepInfo">{{lastStep.name}}</div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="actions">-->
<!--            <div class="nonActeur" v-if="lastStep.myActions == ''">-->
<!--                <i class="fal fa-check"></i>-->
<!--                <div class="statusInfo">-->
<!--                    Aucune action requise-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="acteur" :class="{ noAction : !actionsRemaining }" v-else>-->
<!--                <div class="remaining" v-if="actionsRemaining">-->
<!--                    <i class="fal fa-tasks"></i>-->
<!--                    <span class="action" :class="{ 'finish' : action.state == 'finish' }" v-for="(action, index) in lastStep.myActions" v-if="index < 3"><span>{{index + 1}}.</span>{{action.name}}</span>-->
<!--                    <span class="more" v-if="lastStep.myActions.length > 2">+{{lastStep.myActions.length - 3}} autres actions</span>-->
<!--                </div>-->
<!--                <div class="locked" v-else>-->
<!--                    <i class="fal fa-check"></i>-->
<!--                    <div class="statusInfo">-->
<!--                        Aucune action requise-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="bottom">-->
<!--            <div class="nonActeur" v-if="lastStep.myActions == ''">-->
<!--                <div class="time">-->
<!--                    <span class="timeLeft">{{projectCluster.id | dateCompareStep(lastStep.end, lastStep.creation)}}</span>-->
<!--                    <span class="bgBar">-->
<!--                        <span class="bar" v-bind:style="barStyle"></span>-->
<!--                    </span>-->
<!--                </div>-->
<!--                <span class="info">En cous auprès d’un partenaire</span>-->
<!--            </div>-->
<!--            <div class="acteur" v-else>-->
<!--                <div class="time">-->
<!--                    <span class="timeLeft">{{projectCluster.id | dateCompareStep(lastStep.end, lastStep.creation)}}</span>-->
<!--                    <span class="bgBar">-->
<!--                        <span class="bar" v-bind:style="barStyle"></span>-->
<!--                    </span>-->
<!--                </div>-->
<!--                <span class="info" :style="bgColorLightStyle" v-if="!actionsRemaining">En cous auprès d’un partenaire</span>-->
<!--            </div>-->
<!--        </div>-->
        <div class="link">
            <q-btn :to="{ name : 'Study', params: { id : projectCluster.id }}"
                icon="fal fa-info-circle" unelevated class="button medium"
                color="grey" text-color="greyDark" label="Suivi complet" />
        </div>
    </div>
</template>

<script>

    import newFilter from '../../utils/filters.js'
    import config from '../../utils/config.js'

    export default {
        name: "cardProject",
        props: ["projectCluster"],
        data(){
            return{
                newFilter : newFilter
            }
        },
        computed: {
            // lastStep: function(){
            //     return this.projectCluster.steps[this.projectCluster.steps.length - 1]
            // },
            barStyle: function(){
                let percent = this.valuePercentStep(this.lastStep.end, this.lastStep.creation)
                let color = ""
                if(percent < 51) {
                    color = config.COLOR_GREEN
                } else if (percent < 76) {
                    color = config.COLOR_ORANGE
                } else {
                    color = config.COLOR_RED
                }
                return {
                    width:  percent + '%',
                    backgroundColor: color
                }
            },
            bgColorLightStyle: function(){
                let percent = this.valuePercentStep(this.lastStep.end, this.lastStep.creation)
                let color = ""
                if(percent < 51) {
                    color = config.COLOR_GREEN_LIGHT
                } else if (percent < 76) {
                    color = config.COLOR_ORANGE_LIGHT
                } else {
                    color = config.COLOR_RED_LIGHT
                }
                return {
                    backgroundColor: color
                }
            },
            borderColorStyle: function(){
                let percent = this.valuePercentStep(this.lastStep.end, this.lastStep.creation)
                let color = ""
                if(percent < 51) {
                    color = config.COLOR_GREEN
                } else if (percent < 76) {
                    color = config.COLOR_ORANGE
                } else {
                    color = config.COLOR_RED
                }
                return {
                    borderColor: color
                }
            },
            actionsRemaining: function() {
                let remaining = false
                this.lastStep.myActions.forEach((item, i) => {
                    if(item.state != 'lock'){
                        remaining = true
                    }
                })
                return remaining
            }
        },
        methods: {
            valuePercentStep(end, creation) {
                return newFilter.percentStep(1, end, creation)
            }
        }
    }

</script>

<style lang="scss">

    @import "../../css/app.scss";

    .cardProject {
        float: left;
        width: 100%;
        position: relative;
        background-color: #FFFFFF;
        box-shadow: 0px 5px 15px #0000000D;
        border-radius: 5px;
        opacity: 1;
        border-radius: 5px;
        overflow: hidden;
        transition: all .2s ease;

        &:hover{
            box-shadow: none;

            .link{
                opacity: 1;
            }

        }

        .infoProject {
            float: left;
            width: 100%;
            padding: 30px 30px 20px;
            border-bottom: 1px solid $grey05;

            .ref {
                float: left;
                width: 100%;
                margin-bottom: 20px;

                .refCircle{
                    float: left;
                    width: 16px;
                    height: 16px;
                    background-color: #FFFFFF;
                    border: 4px solid $grey02;
                    border-radius: 100px;
                    margin: 0 20px 0 0;
                }

                span {
                    font-size: 12px;
                    line-height: 16px;
                    color: $grey02;
                }

            }

            .address {
                float: left;
                width: 100%;

                i {
                    width: 16px;
                    text-align: center;
                    float: left;
                    font-size: 16px;
                    margin: 0 20px 0 0;
                    line-height: 18px;
                    color: $grey02;
                }

                .streetAddress {
                    float: left;
                    font-size: 12px;
                    line-height: 16px;
                    color: $grey00;

                    span{
                        display: block;
                        margin: 0 0 3px 0;
                    }

                }

            }

        }

        .step {
            float: left;
            width: 100%;
            margin-top: 20px;
            padding: 0px 30px;

            .stepNumber{
                float: left;
                padding-top: 13px;
                width: 36px;

                .currentStep{
                    font-size: 14px;
                    line-height: 20px;
                    font-weight: 700;
                    color: $grey00;
                }

                .slashTen{
                    font-size: 10px;
                    line-height: 20px;
                    color: $grey02;
                }

            }

            .stepLeft{
                float: left;

                .title{
                    font-size: 10px;
                    line-height: 14px;
                    color: $grey02;
                    text-transform: capitalize;
                }

                .stepInfo{
                    font-size: 13px;
                    line-height: 20px;
                    font-weight: 500;
                    color: $grey00;
                }

            }

        }

        .actions{
            float: left;
            width: 100%;
            text-align: center;

            .nonActeur{
                padding: 0px 30px 15px;

                i{
                    color: $grey03;
                }

            }

            .acteur{
                min-height: 139px;
                padding: 0px 30px 15px;
                text-align: left;

                &.noAction{
                    min-height: auto;
                }

                i{
                    color: $grey03;
                    text-align: center;
                    padding-bottom: 5px;
                }

                .action{
                    display: block;
                    padding: 0 0 0 36px;
                    font-size: 13px;
                    line-height: 18px;

                    &.finish{
                        font-style: italic;
                        color: $grey01;
                    }

                    span{
                        font-weight: 700;
                        padding: 0 5px 0 0;
                    }

                }

                .more{
                    display: block;
                    padding: 0 0 0 36px;
                    font-style: italic;
                    color: $grey02;
                }

                .locked{

                    i{
                        color: $green00;
                        padding-bottom: 0;
                    }

                    .statusInfo{
                        text-align: center;
                        font-size: 13px;
                        line-height: 20px;
                        color: $grey02;
                    }

                }

            }

            i{
                width: 100%;
                padding-top: 15px;
                font-size: 30px;
                display: block;
            }

            .statusInfo{
                font-size: 13px;
                line-height: 20px;
                color: $grey02;
            }

        }

        .bottom{
            overflow: hidden;
            float: left;
            width: 100%;

            .nonActeur, .acteur{
                overflow: hidden;

                .info{
                    display: block;
                    padding: 20px 25px;
                    background-color: $grey03;
                    text-align: center;
                    font-size: 13px;
                    line-height: 19px;
                    color: $grey00;
                }

                .time{

                    .timeLeft{
                        display: block;
                        font-size: 10px;
                        line-height: 16px;
                        color: $grey02;
                        text-align: right;
                        padding: 0 10px 5px;
                    }

                    .bgBar{
                        display: block;
                        height: 5px;
                        background-color: $grey04;

                        .bar{
                            display: block;
                            height: 5px;
                            float: left;
                            background-color: $grey03;
                        }

                    }

                }

            }

            .acteur{
                background-color: transparent;

                .time{

                    .timeLeft{
                        color: $grey02;
                    }

                    .bgBar{
                        overflow: hidden;
                        background-color: $grey04 !important;
                    }

                }

            }

        }

        .link{
            position: absolute;
            top: 0;
            opacity: 0;
            transition: all .2s ease;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(255,255,255,0.7);
            text-align: center;
            border-radius: 5px;

            a{
                top: 50%;
                margin: -18px 0 0 0;
            }

        }

    }

</style>
