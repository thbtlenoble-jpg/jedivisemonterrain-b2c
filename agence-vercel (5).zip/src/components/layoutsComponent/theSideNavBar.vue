<template>
    <div id="theSideNavBar">
        <div class="logo">
            <img src="../../statics/logo-min.png" alt="">
            <span class="agencyName">{{agencyName}}</span>
        </div>
        <ul>
            <li v-if="1==2"> <router-link :to="{ name: 'Dashboard' }"><i class="fas fa-tachometer-alt-fast"></i></router-link></li>
            <li v-if="1==2">
                <a title="A découvrir prochainement" :class="{ 'active': active == 'prospecting' }">
                    <i class="fal fa-search"></i>
                    <span>Prospection</span>
                </a>
            </li>
            <li>
                <router-link :to="{ name: 'ListingStudies' }" :class="{ 'active': active == 'study' }">
                    <i class="fal fa-layer-group"></i>
                    <span>Mes études</span>
                </router-link>
            </li>
            <li v-if="1==2">
                <router-link :to="{ name: 'AgencyManagement' }" :class="{ 'active': active == 'parameters' }">
                    <i class="fal fa-cogs"></i>
                    <span>Paramétrages</span>
                </router-link>
            </li>
        </ul>
        <div class="userConnectedBloc">
            <div class="username">
                <span>{{userName}}</span>
            </div>
            <div class="profilePicture"></div>
            <div class="logout" @click="logout">
                <i class="fal fa-sign-out"></i>
            </div>
        </div>
    </div>
</template>

<script>

    import Vuex from 'vuex'
    import Store from '../../store/index'

    export default {
        name: "sideNavBar",
        data(){
            return{
                userName : '',
                agencyName : ''
            }
        },
        computed : {
            active() {
                return this.$route.meta.menu
            }
        },
        created(){
            this.init()
        },
        methods : {
            ...Vuex.mapActions['getPersonById','getProfile','getOneRealEstateAgencyById'],

            init(){
                Store.dispatch('getProfile').then(response =>{
                    if(response.body.personId != null){
                        Store.dispatch('getPersonById',{personId : response.body.personId}).then(response =>{
                            this.userName = response.body.firstname
                        })
                        Store.dispatch('getOneRealEstateAgencyById',{reaId : response.body.structureId}).then(response =>{
                            this.agencyName = response.body.name
                        })
                    }
                },
                error =>{

                })
            },
            logout(){
                localStorage.removeItem("jwt")
                this.$router.push({name : 'Login'})
                Store.state.authentification.values.isLoginLoading = false
            }
        }
    }

</script>

<style lang="scss">

    @import "../../css/app.scss";

    #theSideNavBar{
        position: absolute;
        box-shadow: 0 2px 10px 0 rgba(0,0,0,0.03);
        top: 0px;
        left: 0;
        bottom: 0;
        width: 100px;
        background: #FFFFFF 0% 0% no-repeat padding-box;
        z-index: 2;
        text-align: center;
        color: #fff;
        font-size: 22px;

        .logo{
            padding: 25px;
            border-bottom: 1px solid $grey04;

            img{
                width: 100%;
            }

            span{

                color: black;
                font-size: 10px;
            }

        }

        @media screen and (max-width: 1450px){

            .logo{
                padding: 20px;
            }

        }

        ul{
            margin-top: 130px;
            float: left;
            width: 100%;
            padding: 0;

            li{
                width: 100%;
                text-decoration: none;
                list-style-type: none;

                a{
                    text-align: center;
                    text-decoration: none;
                    transition: all .2s ease;
                    color: $grey03;
                    display: block;
                    padding: 30px 0;

                    &:hover{
                        color: $grey00;
                    }

                    &.active{

                        i, span{
                            color: $grey00;
                        }

                    }

                    i{
                        width: 100%;
                        font-size: 20px;
                    }

                    span{
                        font-size: 8px;
                        text-transform: uppercase;
                    }

                }

            }

        }

        @media screen and (max-width: 1450px){

            ul{

                li{

                    a{

                        span{
                            font-size: 7px;
                        }

                    }

                }

            }

        }

        @media screen and (max-height: 800px){

            ul{
                margin-top: 80px;

                li{

                    a{
                        padding: 20px 0;

                        i{
                            font-size: 18px;
                        }

                    }

                }

            }

        }

        .userConnectedBloc{
            position: absolute;
            width: 100%;
            bottom: 0;
            height: 150px;
            .username{
                color: black;
                font-size: 10px;
                padding-bottom: 5px;
            }

            .profilePicture{
                margin: 0 auto 20px;
                background-image: url("../../statics/profileEmpty.jpg");
                border: 1px solid $grey05;
                background-position: center;
                background-size: contain;
                height: 40px;
                width: 40px;
                border-radius: 100px;
            }

            .logout{
                padding: 25px 0;
                cursor: pointer;
                color: $grey03;
                transition: all .2s ease;

                &:hover{
                    color: $grey00;
                }

                i{
                    text-align: center;
                    letter-spacing: 0px;
                    opacity: 1;
                }

            }

        }

        @media screen and (max-width: 1450px){

            .userConnectedBloc{

                .logout{
                    padding: 20px 0;
                }

            }

        }

        @media screen and (max-height: 700px){

            .userConnectedBloc{
                height: 120px;

                .profilePicture{
                    margin: 0 auto 10px;
                    width: 30px;
                    height: 30px;
                }

                .logout{
                    padding: 20px 0;

                    i{
                        font-size: 18px;
                    }

                }

            }

        }

    }

    @media screen and (max-width: 1450px){

        #theSideNavBar{
            width: 80px;
        }

    }

</style>
