<template>
    <div class="fileUploader">
        <q-file
            v-if="options != undefined"
            name="cover_files"
            v-model="files"
            multiple
            use-chips
            :label="options.type.frValue"
            @input="uploadFiles"
            :max-files="options.maxFiles"
            counter
            :counter-label="counterLabelFn"
            :accept="options.accept"
            @rejected="onRejected"
        >
            <template v-slot:prepend>
                <q-icon name="fal fa-paperclip" />
            </template>
        </q-file>
    </div>
</template>

<script>
    import Vuex from "vuex";
    import Store from "../../store/index";

    export default {
        props: ["projectId", "options"],
        name: "fileUploader",
        data() {
            return {
                files: null,
            };
        },

        computed: {},

        methods: {
            ...Vuex.mapActions["uploadFileToProject"],
            counterLabelFn({ totalSize, filesNumber, maxFiles }) {
                return `${filesNumber} files of ${maxFiles} | ${totalSize}`;
            },
            onRejected(rejectedEntries) {
                this.$q.notify({
                    type: "negative",
                    message: `${rejectedEntries.length} file(s) did not pass validation constraints`,
                });
            },
            uploadFiles(e) {
                console.log(e);
                let fd = new FormData();

                e.forEach((element, index) => {
                    fd.append("files", element);
                });
                fd.append("type", this.options.type.id);
                Store.dispatch("uploadFileToProject", {
                    projectId: this.projectId,
                    fd: fd,
                })
                    .then((response) => {
                        if (response.status == 201) {
                            this.$q.notify({
                                type: "positive",
                                timeout: 4000,
                                progress: true,
                                icon: "fal fa-check",
                                message:
                                    "Les documents ont bien été enregistrer",
                                position: "top",
                            });
                        } else {
                            this.$q.notify({
                                type: "negative",
                                timeout: 4000,
                                progress: true,
                                icon: "fal fa-check",
                                message:
                                    "Une erreur est survenue lors de l'enrgistrement des documents",
                                position: "top",
                            });
                        }
                        this.$emit("getFiles");
                        this.files = null;
                    })
                    .catch((error) => {
                        this.$q.notify({
                            type: "negative",
                            timeout: 4000,
                            progress: true,
                            icon: "fal fa-check",
                            message:
                                "Une erreur est survenue lors de l'enrgistrement des documents",
                            position: "top",
                        });
                        this.files = null;
                        this.$emit("getFiles");
                    });
            },
        },
    };
</script>

<style lang="scss"></style>
