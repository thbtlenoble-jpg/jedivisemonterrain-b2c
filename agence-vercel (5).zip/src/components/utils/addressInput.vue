<template>
    <div id="addressInput">
        <span>
                        <q-input
                                v-model="address"
                                label="Adresse"
                                debounce="500"
                                :loading="loading"
                                ref="address"
                                v-on:click="firstClick"
                                lazy-rules
                                :rules="[ val => val && val.length > 0 || 'Champ requis']"
                        />
                    </span>
        <div
                class="listAddress"
                v-if="entries != '' && !addressSelect && firstClickAdress"
        >
            <div class="loading" v-if="loading"></div>
            <span
                    class="address"
                    v-for="entry in entries"
                    @click="selectAddress(entry)"
            >
                            <span class="label">{{
                                entry.properties.label
                            }}</span>
                            <span class="context">{{
                                entry.properties.context
                            }}</span>
                            <span
                                    class="type"
                                    v-if="entry.properties.type == 'housenumber'"
                            ><i class="fal fa-home"></i
                            ></span>
                            <span
                                    class="type"
                                    v-if="entry.properties.type == 'street'"
                            ><i class="fal fa-road"></i
                            ></span>
                        </span>
        </div>
    </div>

</template>

<script>
    export default {
        name: "addressInput",
        props:["entrySelect"],
        data(){
            return{
                entries: "",
                address: "",
                addressSelect: false,
                addressSelectValide: false,
                firstClickAdress : false,
                loading : false,
                entrySelectModel :{

                }

            }
        },

        watch: {
            address() {
                if (!this.addressSelectValide) {
                    this.loadAPIAddress();
                    this.addressSelect = false;
                }
                if (this.address == "") {
                    this.entries = "";
                }
                this.addressSelectValide = false;
            },
            entrySelectModel(){
                if(this.entrySelectModel != null){
                    this.address = this.entrySelectModel.label
                }
            },
            entrySelect(){
                this.entrySelectModel = this.entrySelect
            }
        },
        beforeMount(){
            this.entrySelectModel = this.entrySelect
        },
        methods : {
            firstClick(){
                if(!this.firstClickAdress){
                    this.firstClickAdress = true
                }
            },
            loadAPIAddress() {
                this.loading = true;
                return fetch(
                    "https://api-adresse.data.gouv.fr/search/?q=" +
                    this.address,
                    { method: "get" }
                )
                    .then((res) => res.json())
                    .then((data) => {
                        this.entries = data.features;
                        this.loading = false;
                    })
                    .catch((err) =>{});
            },
            selectAddress(entry) {
                this.address = entry.properties.label;
                this.addressSelect = true;
                this.addressSelectValide = true;
                this.entrySelectModel = entry.properties
                delete this.entrySelectModel.id
                this.$emit('changeAddress',this.entrySelectModel)

            },
        }
    }
</script>

<style lang="scss">
    #addressInput{
        width: 100%;
        float: left ;
        span{
            width: 100%;
        }
    }
</style>
