import Vue from 'vue'
import VueRouter from 'vue-router'
import Store from '../store/index'
import config from '../utils/config'
import filters from '../utils/filters'
import routes from './routes'

Vue.use(VueRouter)

/*
 * If not building with SSR mode, you can
 * directly export the Router instantiation;
 *
 * The function below can be async too; either use
 * async/await or return a Promise which resolves
 * with the Router instance.
 */

export default function (/* { store, ssrContext } */) {
    const Router = new VueRouter({
        scrollBehavior: () => ({x: 0, y: 0}),
        routes,

        // Leave these as they are and change in quasar.conf.js instead!
        // quasar.conf.js -> build -> vueRouterMode
        // quasar.conf.js -> build -> publicPath
        mode: process.env.VUE_ROUTER_MODE,
        base: process.env.VUE_ROUTER_BASE
    })

    Router.beforeEach((to, from, next) => {
        // Loading sur la page pour le changement de route
        Store.state.authentification.values.isChangeRoute = true

        var jwtToken = localStorage.getItem('jwt')
        // Si l'utilisateur arrive sur l'URL de login est qu'il était déjà connecté, redirection vers l'espacce sécurisé si ça connexion est active
        if(from.name == null && to.name == 'Login' && jwtToken !== null && jwtToken != ''){
            return new Promise((resolve, reject) => {
                Vue.http.get(Vue.http.options.root + config.AUTHURL, {
                    headers: {
                        'Authorization': 'Bearer ' + jwtToken
                    }
                }).then(response => {
                    if (response.body.isAuthOk == 'false') {
                        localStorage.removeItem('jwt')
                        next()
                    } else {
                        localStorage.setItem('jwt', response.body.access_token)
                        next('/liste-de-mes-etudes')
                    }
                }, response => {
                })
            })
        } else {
            if (to.meta.requiresAuth) {
                if (jwtToken !== null & jwtToken != '') {
                    return new Promise((resolve, reject) => {
                        Vue.http.get(Vue.http.options.root + config.AUTHURL, {
                            headers: {
                                'Authorization': 'Bearer ' + jwtToken
                            }
                        }).then(response => {
                            if (response.body.isAuthOk == 'false') {
                                localStorage.removeItem('jwt')
                                next('/')
                            } else {
                                localStorage.setItem('jwt', response.body.access_token)
                                next()
                            }
                        }, response => {
                        })
                    })
                } else {
                    localStorage.removeItem('jwt')
                    next('/')
                }

            } else {
                next() // assurez vous de toujours appeler `next()` !
            }

        }

    })

    Router.afterEach((to,from) =>{

        Store.state.authentification.values.isChangeRoute = false
    })

    Router.beforeEach((to, from, next) => {
        let jwtToken = localStorage.getItem('jwt')

        // Si l'utilisateur arrive sur l'URL de login est qu'il était déjà connecté, redirection vers l'espacce sécurisé si sa connexion est active
        if (from.name == null && to.name == 'Login' && jwtToken !== null && jwtToken != '') {
            Vue.http.get(Vue.http.options.root + config.AUTHURL, {
                headers: {
                    'Authorization': 'Bearer ' + jwtToken
                }
            })
                .then(response => {
                    if (response.body.isAuthOk == 'false') {
                        localStorage.removeItem('jwt')
                        next()
                    } else {
                        localStorage.setItem('jwt', response.body.access_token)
                        next('/liste-de-mes-etudes')
                    }
                })
                .catch(error => {
                    localStorage.removeItem('jwt')
                    next()
                })
        } else {
            if (to.meta.requiresAuth) {
                if (jwtToken !== null && jwtToken != '') {
                    Vue.http.get(Vue.http.options.root + config.AUTHURL, {
                        headers: {
                            'Authorization': 'Bearer ' + jwtToken
                        }
                    }).then(response => {
                        if (response.body.isAuthOk == 'false') {
                            localStorage.removeItem('jwt')
                            next('/')
                        } else {
                            localStorage.setItem('jwt', response.body.access_token)
                            next()
                        }
                    })
                } else {
                    localStorage.removeItem('jwt')
                    next('/')
                }
            } else {
                next()
            }
        }
    })

    return Router

}
