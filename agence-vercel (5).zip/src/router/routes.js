import Login from 'pages/Login.vue'
import ListingStudies from 'pages/ListingStudies.vue'
import Study from 'pages/Study.vue'

const routes = [
    {
        path: '/',
        name: 'Login',
        meta: {
            layout: "Empty",
            requiresAuth : false
        },
        component: Login,
    }, {
        path : '/resetPassword/:code',
        name : 'ResetPassword',
        meta: {
            layout: "Empty",
            requiresAuth : false
        },
        component : () => import('pages/ResetPassword.vue')
    }, {
        path: '/tableau-de-bord',
        name: 'Dashboard',
        meta: {
            requiresAuth : true
        },
        component: () => import('pages/Dashboard.vue')
    }, {
        path: '/liste-de-mes-etudes',
        name: 'ListingStudies',
        meta: {
            layout: "Default",
            menu: 'study',
            requiresAuth : true
        },
        component: ListingStudies,
    }, {
        path : '/suivi-de-mon-etude/:id',
        name: 'Study',
        meta: {
            layout: "Default",
            menu: 'study',
            requiresAuth : true
        },
        component: Study
    }, {
        path: '/listingUsers',
        name: 'ListingUsers',
        meta: {
            requiresAuth : true
        },
        component: () => import('pages/ListingUsers.vue')
    }, {
        path: '/agencyManagement',
        name: 'AgencyManagement',
        meta: {
            requiresAuth : true
        },
        component: () => import('pages/AgencyManagement.vue')
    }, {
        path : '/ajout-nouvelle-etude',
        name : 'newProject',
        meta: {
            requiresAuth : true
        },
        component : () => import('pages/newProject.vue')
    }
]

// Always leave this as last one
if (process.env.MODE !== 'ssr') {
    routes.push({
        path: '*',
        component: () => import('pages/Error404.vue')
    })
}

export default routes
